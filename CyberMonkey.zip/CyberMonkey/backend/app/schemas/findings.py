"""Schemas for findings, indicators and threat-intelligence references."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from pydantic import Field

from app.core.constants import FindingStatus, ReferenceValidation, ValidationStatus
from app.schemas.common import ApiModel, StrictInput


class IndicatorLinkOut(ApiModel):
    id: uuid.UUID
    type: str
    value: str
    relation: str
    context: str


class ReferenceLinkOut(ApiModel):
    id: uuid.UUID
    ref_type: str
    external_id: str
    title: str
    url: str
    cvss_score: float | None
    severity: str | None
    source: str
    match_basis: str
    validation_status: str
    tactics: list[str] = Field(default_factory=list)


class FindingOut(ApiModel):
    id: uuid.UUID
    investigation_id: uuid.UUID
    investigation_reference: str
    workspace: str
    source_tool: str
    run_id: uuid.UUID | None
    origin: str
    rule_id: str | None
    finding_type: str
    title: str
    description: str
    severity: str
    confidence: str
    affected_asset: str
    observed_at: datetime | None
    status: str
    validation_status: str
    details: dict[str, Any]
    evidence_refs: list[dict[str, Any]]
    remediation: list[dict[str, Any]]
    indicators: list[IndicatorLinkOut]
    references: list[ReferenceLinkOut]
    created_at: datetime
    updated_at: datetime


class FindingTriage(StrictInput):
    status: FindingStatus | None = None
    validation_status: ValidationStatus | None = None
    note: str = Field(default="", max_length=5000)


class ReferenceValidationUpdate(StrictInput):
    validation_status: ReferenceValidation


class AnalystFindingCreate(StrictInput):
    workspace: str
    title: str = Field(min_length=3, max_length=300)
    description: str = Field(default="", max_length=20_000)
    severity: str = "info"
    affected_asset: str = Field(default="", max_length=255)
