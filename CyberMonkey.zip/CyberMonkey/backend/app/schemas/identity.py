"""Schemas for authentication, users, roles and permissions."""

from __future__ import annotations

import re
import uuid
from datetime import datetime
from typing import Annotated

from pydantic import AfterValidator, Field, field_validator

from app.core.security import password_policy_errors
from app.schemas.common import ApiModel, StrictInput

_EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]+\.[^@\s.]{2,}$")


def _email(value: str) -> str:
    # Deliberately permissive about domains: internal directories commonly use
    # reserved suffixes such as .local, .internal or .test that strict validators reject.
    value = value.strip().lower()
    if len(value) > 320 or not _EMAIL_RE.match(value):
        raise ValueError("Enter a valid email address")
    return value


Email = Annotated[str, AfterValidator(_email)]


class LoginRequest(StrictInput):
    email: Email
    password: str = Field(min_length=1, max_length=256)


class PermissionOut(ApiModel):
    id: int
    code: str
    scope: str
    action: str
    description: str


class RoleSummary(ApiModel):
    id: int
    slug: str
    name: str


class RoleOut(ApiModel):
    id: int
    slug: str
    name: str
    description: str
    is_system: bool
    permissions: list[str]
    user_count: int = 0


class UserOut(ApiModel):
    id: uuid.UUID
    email: str
    full_name: str
    is_active: bool
    last_login_at: datetime | None
    created_at: datetime
    roles: list[RoleSummary]
    direct_permissions: list[str]


class MeOut(UserOut):
    permissions: list[str]
    workspaces: list[str]


class LoginResponse(ApiModel):
    access_token: str
    token_type: str = "bearer"
    expires_at: datetime
    user: MeOut


def _check_password(value: str) -> str:
    errors = password_policy_errors(value)
    if errors:
        raise ValueError("Password " + "; ".join(errors))
    return value


class UserCreate(StrictInput):
    email: Email
    full_name: str = Field(min_length=1, max_length=200)
    password: str = Field(max_length=256)
    role_ids: list[int] = Field(default_factory=list)

    _pw = field_validator("password")(_check_password)


class UserUpdate(StrictInput):
    full_name: str | None = Field(default=None, min_length=1, max_length=200)
    is_active: bool | None = None


class UserRolesUpdate(StrictInput):
    role_ids: list[int]


class UserPermissionsUpdate(StrictInput):
    permission_codes: list[str]


class PasswordReset(StrictInput):
    new_password: str = Field(max_length=256)

    _pw = field_validator("new_password")(_check_password)


class PasswordChange(StrictInput):
    current_password: str = Field(max_length=256)
    new_password: str = Field(max_length=256)

    _pw = field_validator("new_password")(_check_password)


class RoleCreate(StrictInput):
    name: str = Field(min_length=2, max_length=128)
    description: str = Field(default="", max_length=1000)
    permission_codes: list[str] = Field(default_factory=list)


class RoleUpdate(StrictInput):
    name: str | None = Field(default=None, min_length=2, max_length=128)
    description: str | None = Field(default=None, max_length=1000)
    permission_codes: list[str] | None = None
