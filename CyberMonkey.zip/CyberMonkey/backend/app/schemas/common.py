"""Base schema configuration shared by request/response models."""

from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class ApiModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class StrictInput(BaseModel):
    """Request bodies reject unknown fields so typos and injected keys fail loudly."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class UserRef(ApiModel):
    id: uuid.UUID
    email: str
    full_name: str


class Message(ApiModel):
    message: str


class Timestamped(ApiModel):
    created_at: datetime
