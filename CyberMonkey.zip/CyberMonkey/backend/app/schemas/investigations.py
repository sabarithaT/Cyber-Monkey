"""Schemas for investigations, members, scope targets and notes."""

from __future__ import annotations

import ipaddress
import re
import uuid
from datetime import datetime
from typing import Literal

from pydantic import Field, model_validator

from app.core.constants import InvestigationStatus, Workspace
from app.schemas.common import ApiModel, StrictInput, UserRef

_HOSTNAME_RE = re.compile(r"^(?=.{1,253}$)(?!-)[a-z0-9-]{1,63}(?<!-)(\.(?!-)[a-z0-9-]{1,63}(?<!-))*$")


class InvestigationCreate(StrictInput):
    title: str = Field(min_length=3, max_length=200)
    description: str = Field(default="", max_length=10_000)
    primary_workspace: Workspace


class InvestigationUpdate(StrictInput):
    title: str | None = Field(default=None, min_length=3, max_length=200)
    description: str | None = Field(default=None, max_length=10_000)
    status: InvestigationStatus | None = None


class SeverityCounts(ApiModel):
    critical: int = 0
    high: int = 0
    medium: int = 0
    low: int = 0
    info: int = 0


class InvestigationSummary(ApiModel):
    id: uuid.UUID
    reference: str
    title: str
    primary_workspace: str
    status: str
    is_demo: bool
    owner: UserRef
    created_at: datetime
    updated_at: datetime
    finding_counts: SeverityCounts
    run_count: int
    evidence_count: int


class MemberOut(ApiModel):
    user: UserRef
    access_level: str
    added_at: datetime


class ScopeTargetOut(ApiModel):
    id: uuid.UUID
    target_type: str
    value: str
    authorization_reference: str
    authorized_by: UserRef
    valid_from: datetime
    valid_until: datetime | None
    notes: str
    created_at: datetime
    active: bool


class InvestigationDetail(InvestigationSummary):
    description: str
    closed_at: datetime | None
    members: list[MemberOut]
    scope_targets: list[ScopeTargetOut]
    my_access: Literal["owner", "contributor", "viewer", "manager"]


class MemberAdd(StrictInput):
    email: str = Field(min_length=3, max_length=320)
    access_level: Literal["viewer", "contributor"] = "contributor"


class ScopeTargetCreate(StrictInput):
    target_type: Literal["ip", "cidr", "hostname"]
    value: str = Field(min_length=1, max_length=255)
    authorization_reference: str = Field(
        min_length=5,
        max_length=2000,
        description="Who authorized testing of this target and where that authorization is recorded "
        "(e.g. 'Lab VM owned by the project team, rules of engagement v2 signed 2026-09-01').",
    )
    valid_until: datetime | None = None
    notes: str = Field(default="", max_length=2000)

    @model_validator(mode="after")
    def _validate_value(self) -> ScopeTargetCreate:
        value = self.value.strip().lower()
        try:
            if self.target_type == "ip":
                value = str(ipaddress.ip_address(value))
            elif self.target_type == "cidr":
                net = ipaddress.ip_network(value, strict=False)
                # A very large range is almost never what a lab assessment intends.
                if net.num_addresses > 65_536:
                    raise ValueError("CIDR ranges larger than /16 (IPv4) are not accepted as scope")
                value = str(net)
            else:
                if not _HOSTNAME_RE.match(value):
                    raise ValueError("Invalid hostname")
        except ValueError as exc:
            raise ValueError(f"Invalid {self.target_type}: {exc}") from exc
        self.value = value
        return self


class NoteCreate(StrictInput):
    body: str = Field(min_length=1, max_length=20_000)
    finding_id: uuid.UUID | None = None


class NoteOut(ApiModel):
    id: uuid.UUID
    body: str
    finding_id: uuid.UUID | None
    author: UserRef
    created_at: datetime


class TimelineEntry(ApiModel):
    at: datetime
    kind: str  # finding | log_event | run | evidence | note
    title: str
    detail: str
    severity: str | None = None
    workspace: str | None = None
    ref_id: str
