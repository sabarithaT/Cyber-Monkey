"""Management commands.

    python -m app.cli init                 # run migrations, seed permissions/roles/integrations
    python -m app.cli create-admin --email admin@example.org --name "Admin"
    python -m app.cli seed-demo            # optional, clearly labelled demo investigation

``create-admin`` reads the password from BOOTSTRAP_ADMIN_PASSWORD or prompts for it.
"""

from __future__ import annotations

import argparse
import getpass
import sys

from alembic import command
from alembic.config import Config
from sqlalchemy import select

from app.core.config import BACKEND_DIR, get_settings
from app.core.db import session_factory
from app.core.security import password_policy_errors
from app.models import Role


def migrate() -> None:
    cfg = Config(str(BACKEND_DIR / "alembic.ini"))
    cfg.set_main_option("script_location", str(BACKEND_DIR / "alembic"))
    command.upgrade(cfg, "head")


def seed_reference_data() -> None:
    from app.services.identity import ensure_rbac_seed
    from app.services.integrations import ensure_integration_rows

    with session_factory()() as db:
        ensure_rbac_seed(db)
        ensure_integration_rows(db)
        db.commit()


def cmd_init(_: argparse.Namespace) -> int:
    migrate()
    seed_reference_data()
    print("Database migrated and reference data seeded.")
    return 0


def cmd_create_admin(args: argparse.Namespace) -> int:
    from app.services import audit
    from app.services.identity import create_user, get_user_by_email

    settings = get_settings()
    email = args.email or settings.bootstrap_admin_email
    if not email:
        print("--email (or BOOTSTRAP_ADMIN_EMAIL) is required", file=sys.stderr)
        return 2
    password = settings.bootstrap_admin_password.get_secret_value() if settings.bootstrap_admin_password else ""
    if not password:
        password = getpass.getpass("Password for the new administrator: ")
    problems = password_policy_errors(password)
    if problems:
        print("Password " + "; ".join(problems), file=sys.stderr)
        return 2
    seed_reference_data()
    with session_factory()() as db:
        if get_user_by_email(db, email):
            print(f"User {email} already exists; nothing to do.")
            return 0
        admin_role = db.scalar(select(Role).where(Role.slug == "administrator"))
        assert admin_role is not None
        user = create_user(
            db, email=email, full_name=args.name, password=password, role_ids=[admin_role.id], actor=None
        )
        audit.record(
            db,
            action="user.create",
            actor_email="cli",
            resource_type="user",
            resource_id=user.id,
            details={"email": user.email, "via": "cli", "role": "administrator"},
        )
        db.commit()
    print(f"Administrator {email} created.")
    return 0


def cmd_seed_demo(args: argparse.Namespace) -> int:
    from app.services.demo import seed_demo

    seed_reference_data()
    with session_factory()() as db:
        message = seed_demo(db, owner_email=args.owner)
        db.commit()
    print(message)
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m app.cli")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("init", help="migrate and seed reference data").set_defaults(func=cmd_init)
    p = sub.add_parser("create-admin", help="create the first administrator")
    p.add_argument("--email")
    p.add_argument("--name", default="Administrator")
    p.set_defaults(func=cmd_create_admin)
    p = sub.add_parser("seed-demo", help="create a demo investigation from bundled sample files")
    p.add_argument("--owner", required=True, help="email of the user who will own the demo investigation")
    p.set_defaults(func=cmd_seed_demo)
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
