"""Provider-independent LLM interface.

The rest of the application calls ``get_provider()`` and uses ``generate_json`` /
``generate_text``. Gemini (REST) and Ollama (local) are implemented; when AI_PROVIDER is
``none`` or the provider is misconfigured, ``get_provider()`` returns ``None`` and callers
fall back to deterministic behaviour that is labelled as such. LLM output is always
treated as untrusted: JSON responses are schema-validated by the caller and never
executed."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any, Protocol

import httpx

from app.core.config import get_settings
from app.services.http import host_of

log = logging.getLogger("cybermonkey.ai")


class LLMError(Exception):
    pass


@dataclass(frozen=True)
class LLMInfo:
    provider: str
    model: str


class LLMProvider(Protocol):
    info: LLMInfo

    def generate_text(self, system: str, prompt: str, *, temperature: float = 0.2) -> str: ...

    def generate_json(
        self, system: str, prompt: str, schema: dict[str, Any], *, temperature: float = 0.0
    ) -> dict[str, Any]: ...


def _parse_json(text: str) -> dict[str, Any]:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        cleaned = cleaned[cleaned.find("{") :] if "{" in cleaned else cleaned
    start, end = cleaned.find("{"), cleaned.rfind("}")
    if start == -1 or end == -1:
        raise LLMError("Model did not return a JSON object")
    try:
        value = json.loads(cleaned[start : end + 1])
    except json.JSONDecodeError as exc:
        raise LLMError(f"Model returned invalid JSON: {exc.msg}") from exc
    if not isinstance(value, dict):
        raise LLMError("Model returned JSON that is not an object")
    return value


def _strip_schema(schema: dict[str, Any]) -> dict[str, Any]:
    """Gemini's responseSchema accepts an OpenAPI subset; drop unsupported keywords."""
    allowed = {"type", "properties", "items", "enum", "required", "description", "nullable", "format"}
    out: dict[str, Any] = {}
    for key, value in schema.items():
        if key not in allowed:
            continue
        if key == "properties":
            out[key] = {k: _strip_schema(v) for k, v in value.items()}
        elif key == "items":
            out[key] = _strip_schema(value)
        else:
            out[key] = value
    return out


class GeminiProvider:
    def __init__(self, api_key: str, model: str, base_url: str, timeout: float) -> None:
        self.info = LLMInfo("gemini", model)
        self._key, self._base, self._timeout = api_key, base_url.rstrip("/"), timeout

    def _call(self, system: str, prompt: str, generation: dict[str, Any]) -> str:
        url = f"{self._base}/models/{self.info.model}:generateContent"
        if not url.startswith("https://"):
            raise LLMError("Gemini base URL must use HTTPS")
        body = {
            "systemInstruction": {"parts": [{"text": system}]},
            "contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": generation,
        }
        try:
            with httpx.Client(timeout=self._timeout, follow_redirects=False) as client:
                response = client.post(url, json=body, headers={"x-goog-api-key": self._key})
        except httpx.HTTPError as exc:
            raise LLMError(f"Gemini request failed: {exc.__class__.__name__}") from exc
        if response.status_code != 200:
            raise LLMError(f"Gemini returned HTTP {response.status_code}")
        data = response.json()
        try:
            return "".join(p.get("text", "") for p in data["candidates"][0]["content"]["parts"])
        except (KeyError, IndexError, TypeError) as exc:
            reason = (data.get("promptFeedback") or {}).get("blockReason") or "no candidates"
            raise LLMError(f"Gemini returned no content ({reason})") from exc

    def generate_text(self, system: str, prompt: str, *, temperature: float = 0.2) -> str:
        return self._call(system, prompt, {"temperature": temperature})

    def generate_json(
        self, system: str, prompt: str, schema: dict[str, Any], *, temperature: float = 0.0
    ) -> dict[str, Any]:
        text = self._call(
            system,
            prompt,
            {
                "temperature": temperature,
                "responseMimeType": "application/json",
                "responseSchema": _strip_schema(schema),
            },
        )
        return _parse_json(text)


class OllamaProvider:
    def __init__(self, base_url: str, model: str, timeout: float) -> None:
        self.info = LLMInfo("ollama", model)
        self._base, self._timeout = base_url.rstrip("/"), timeout
        if (
            host_of(self._base) not in {"localhost", "127.0.0.1", "::1", "ollama"}
            and not get_settings().outbound_network_enabled
        ):
            raise LLMError("Remote Ollama host requires outbound network access")

    def _chat(self, system: str, prompt: str, *, fmt: Any, temperature: float) -> str:
        body: dict[str, Any] = {
            "model": self.info.model,
            "stream": False,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": prompt}],
            "options": {"temperature": temperature},
        }
        if fmt is not None:
            body["format"] = fmt
        try:
            with httpx.Client(timeout=self._timeout, follow_redirects=False) as client:
                response = client.post(f"{self._base}/api/chat", json=body)
        except httpx.HTTPError as exc:
            raise LLMError(f"Ollama is not reachable at {self._base} ({exc.__class__.__name__})") from exc
        if response.status_code != 200:
            raise LLMError(f"Ollama returned HTTP {response.status_code}: {response.text[:200]}")
        return response.json().get("message", {}).get("content", "")

    def generate_text(self, system: str, prompt: str, *, temperature: float = 0.2) -> str:
        return self._chat(system, prompt, fmt=None, temperature=temperature)

    def generate_json(
        self, system: str, prompt: str, schema: dict[str, Any], *, temperature: float = 0.0
    ) -> dict[str, Any]:
        return _parse_json(self._chat(system, prompt, fmt=schema, temperature=temperature))


_override: LLMProvider | None = None


def set_provider_override(provider: LLMProvider | None) -> None:
    """Testing hook: use a fake provider instead of the configured one."""
    global _override
    _override = provider


def get_provider() -> LLMProvider | None:
    if _override is not None:
        return _override
    settings = get_settings()
    try:
        if settings.ai_provider == "gemini":
            key = settings.gemini_api_key.get_secret_value() if settings.gemini_api_key else ""
            if not key:
                return None
            if not settings.outbound_network_enabled:
                return None
            return GeminiProvider(key, settings.gemini_model, settings.gemini_base_url, settings.ai_timeout_seconds)
        if settings.ai_provider == "ollama":
            return OllamaProvider(settings.ollama_base_url, settings.ollama_model, settings.ai_timeout_seconds)
    except LLMError as exc:
        log.warning("AI provider unavailable: %s", exc)
    return None


def provider_status() -> dict[str, Any]:
    provider = get_provider()
    settings = get_settings()
    if provider is None:
        return {
            "configured": False,
            "provider": settings.ai_provider,
            "model": None,
            "detail": "No LLM configured: routing uses deterministic rules and text uses templates.",
        }
    return {
        "configured": True,
        "provider": provider.info.provider,
        "model": provider.info.model,
        "detail": "LLM configured",
    }
