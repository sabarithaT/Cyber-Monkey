"""Integration status and (non-secret) configuration."""

from __future__ import annotations

from datetime import datetime
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Request
from sqlalchemy import select

from app.api.deps import CurrentUser, DbSession, require
from app.core.errors import NotFound
from app.models import IntegrationConfig, User
from app.schemas.common import ApiModel, StrictInput
from app.services import audit
from app.services.integrations import (
    CATALOG,
    SPECS,
    availability,
    ensure_integration_rows,
)

router = APIRouter(prefix="/integrations", tags=["Integrations"])


class IntegrationOut(ApiModel):
    key: str
    label: str
    category: str
    description: str
    configure: str
    enabled: bool
    available: bool
    status: str
    detail: str
    secret_env_var: str | None
    settings: dict[str, Any]
    last_checked_at: datetime | None


class IntegrationUpdate(StrictInput):
    enabled: bool


def _out(db, key: str) -> IntegrationOut:  # type: ignore[no-untyped-def]
    spec = SPECS[key]
    row = db.scalar(select(IntegrationConfig).where(IntegrationConfig.key == key))
    result = availability(db, key, record=True)
    return IntegrationOut(
        key=key,
        label=spec.label,
        category=spec.category,
        description=spec.description,
        configure=spec.configure,
        enabled=row.enabled if row else True,
        available=result.available,
        status=result.status,
        detail=result.detail,
        secret_env_var=spec.secret_env_var,
        settings=row.settings if row else {},
        last_checked_at=row.last_checked_at if row else None,
    )


@router.get("", response_model=list[IntegrationOut], summary="Status of every integration")
def list_integrations(_: CurrentUser, db: DbSession) -> list[IntegrationOut]:
    ensure_integration_rows(db)
    items = [_out(db, spec.key) for spec in CATALOG]
    db.commit()
    return items


@router.patch("/{key}", response_model=IntegrationOut, summary="Enable or disable an integration")
def update_integration(
    key: str,
    body: IntegrationUpdate,
    request: Request,
    actor: Annotated[User, Depends(require("integrations:manage"))],
    db: DbSession,
) -> IntegrationOut:
    if key not in SPECS:
        raise NotFound("Unknown integration")
    ensure_integration_rows(db)
    row = db.scalar(select(IntegrationConfig).where(IntegrationConfig.key == key))
    assert row is not None
    before = row.enabled
    row.enabled = body.enabled
    row.updated_by_id = actor.id
    audit.record(
        db,
        action="integration.update",
        actor=actor,
        resource_type="integration",
        resource_id=key,
        request=request,
        details={"enabled": {"before": before, "after": body.enabled}},
    )
    out = _out(db, key)
    db.commit()
    return out
