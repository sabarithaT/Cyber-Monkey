"""Authentication: login, logout, current user, password change."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi import APIRouter, Request, Response

from app.api.deps import CurrentUser, DbSession, current_claims
from app.core.config import get_settings
from app.core.errors import NotAuthenticated, ValidationFailed
from app.core.ratelimit import limiter
from app.core.security import (
    burn_password_check,
    create_access_token,
    hash_password,
    password_needs_rehash,
    verify_password,
)
from app.models import RevokedToken
from app.schemas.common import Message
from app.schemas.identity import LoginRequest, LoginResponse, MeOut, PasswordChange
from app.services import audit
from app.services.audit import client_ip
from app.services.identity import get_user_by_email, me_out

router = APIRouter(prefix="/auth", tags=["Authentication"])

_GENERIC_FAILURE = "Invalid email or password"


@router.post("/login", response_model=LoginResponse, summary="Log in and receive an access token")
def login(body: LoginRequest, request: Request, response: Response, db: DbSession) -> LoginResponse:
    settings = get_settings()
    limiter.hit(f"login-ip:{client_ip(request)}", settings.login_rate_limit_per_minute)
    limiter.hit(f"login-email:{body.email.lower()}", settings.login_rate_limit_per_minute)

    user = get_user_by_email(db, body.email)
    now = datetime.now(UTC)
    if user is None:
        burn_password_check(body.password)
        audit.record_independent(
            action="auth.login",
            result="failure",
            actor_email=body.email,
            request=request,
            details={"reason": "unknown_account"},
        )
        raise NotAuthenticated(_GENERIC_FAILURE)

    if not user.is_active or (user.locked_until and user.locked_until > now):
        burn_password_check(body.password)
        audit.record_independent(
            action="auth.login",
            result="failure",
            actor=user,
            request=request,
            details={"reason": "inactive" if not user.is_active else "locked"},
        )
        raise NotAuthenticated(_GENERIC_FAILURE)

    if not verify_password(body.password, user.password_hash):
        user.failed_login_count += 1
        locked = user.failed_login_count >= settings.login_max_failures
        if locked:
            user.locked_until = now + timedelta(minutes=settings.login_lockout_minutes)
            user.failed_login_count = 0
        db.commit()
        audit.record_independent(
            action="auth.login",
            result="failure",
            actor=user,
            request=request,
            details={"reason": "bad_password", "account_locked": locked},
        )
        raise NotAuthenticated(_GENERIC_FAILURE)

    user.failed_login_count = 0
    user.locked_until = None
    user.last_login_at = now
    if password_needs_rehash(user.password_hash):
        user.password_hash = hash_password(body.password)
    token, claims = create_access_token(user.id, user.token_version)
    audit.record(db, action="auth.login", actor=user, resource_type="user", resource_id=user.id, request=request)
    db.commit()

    response.set_cookie(
        settings.cookie_name,
        token,
        max_age=settings.access_token_ttl_minutes * 60,
        httponly=True,
        secure=settings.cookie_secure,
        samesite="strict",
        path="/api",
    )
    return LoginResponse(access_token=token, expires_at=claims.expires_at, user=me_out(user))


@router.post("/logout", response_model=Message, summary="Revoke the current token")
def logout(request: Request, response: Response, user: CurrentUser, db: DbSession) -> Message:
    claims = current_claims(request)
    db.merge(RevokedToken(jti=claims.jti, user_id=user.id, expires_at=claims.expires_at))
    audit.record(db, action="auth.logout", actor=user, resource_type="user", resource_id=user.id, request=request)
    db.commit()
    response.delete_cookie(get_settings().cookie_name, path="/api")
    return Message(message="Logged out")


@router.get("/me", response_model=MeOut, summary="Current user, effective permissions and workspaces")
def me(user: CurrentUser) -> MeOut:
    return me_out(user)


@router.post("/change-password", response_model=Message, summary="Change your own password")
def change_password(
    body: PasswordChange, request: Request, response: Response, user: CurrentUser, db: DbSession
) -> Message:
    if not verify_password(body.current_password, user.password_hash):
        audit.record_independent(
            action="auth.change_password",
            result="failure",
            actor=user,
            request=request,
            details={"reason": "bad_current_password"},
        )
        raise ValidationFailed("Current password is incorrect")
    user.password_hash = hash_password(body.new_password)
    user.token_version += 1  # every existing session must log in again
    audit.record(
        db, action="auth.change_password", actor=user, resource_type="user", resource_id=user.id, request=request
    )
    db.commit()
    response.delete_cookie(get_settings().cookie_name, path="/api")
    return Message(message="Password changed; please log in again")
