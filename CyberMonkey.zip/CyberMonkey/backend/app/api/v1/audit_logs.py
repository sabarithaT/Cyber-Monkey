"""Read-only access to the audit log."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select

from app.api.deps import DbSession, require
from app.core.pagination import Page, PageParams, page_params, paginate
from app.models import AuditLog, User
from app.schemas.common import ApiModel

router = APIRouter(prefix="/audit-logs", tags=["Audit"])


class AuditLogOut(ApiModel):
    id: int
    occurred_at: datetime
    actor_id: uuid.UUID | None
    actor_email: str
    action: str
    resource_type: str
    resource_id: str
    result: str
    ip_address: str
    user_agent: str
    details: dict[str, Any]


@router.get("", response_model=Page[AuditLogOut], summary="Search the audit log")
def list_audit_logs(
    _: Annotated[User, Depends(require("audit:view"))],
    db: DbSession,
    params: Annotated[PageParams, Depends(page_params)],
    action: str | None = Query(None, max_length=64, description="Exact action or prefix ending in '.' e.g. 'auth.'"),
    result: str | None = Query(None, pattern="^(success|failure|denied)$"),
    actor_id: uuid.UUID | None = None,
    resource_type: str | None = Query(None, max_length=64),
    resource_id: str | None = Query(None, max_length=64),
    since: datetime | None = None,
    until: datetime | None = None,
) -> Page[AuditLogOut]:
    stmt = select(AuditLog).order_by(AuditLog.occurred_at.desc(), AuditLog.id.desc())
    if action:
        stmt = stmt.where(AuditLog.action.startswith(action) if action.endswith(".") else AuditLog.action == action)
    if result:
        stmt = stmt.where(AuditLog.result == result)
    if actor_id:
        stmt = stmt.where(AuditLog.actor_id == actor_id)
    if resource_type:
        stmt = stmt.where(AuditLog.resource_type == resource_type)
    if resource_id:
        stmt = stmt.where(AuditLog.resource_id == resource_id)
    if since:
        stmt = stmt.where(AuditLog.occurred_at >= since)
    if until:
        stmt = stmt.where(AuditLog.occurred_at <= until)
    rows, total = paginate(db, stmt, params)
    return Page(
        items=[AuditLogOut.model_validate(r) for r in rows], total=total, page=params.page, page_size=params.page_size
    )
