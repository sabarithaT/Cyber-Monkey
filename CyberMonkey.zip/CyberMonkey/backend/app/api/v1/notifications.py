"""Notifications derived from live data (nothing is stored separately): tool runs waiting
for the user's approval, the user's recently finished runs, and reports awaiting review."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi import APIRouter
from sqlalchemy import select

from app.api.deps import CurrentUser, DbSession
from app.core.constants import TERMINAL_RUN_STATUSES, ReportStatus, RunStatus
from app.models import Investigation, Report, ToolRun
from app.schemas.common import ApiModel
from app.services import authz

router = APIRouter(prefix="/notifications", tags=["Notifications"])


class NotificationOut(ApiModel):
    kind: str
    title: str
    detail: str
    link: str
    occurred_at: datetime


@router.get("", response_model=list[NotificationOut], summary="Actionable items for the current user")
def list_notifications(user: CurrentUser, db: DbSession) -> list[NotificationOut]:
    items: list[NotificationOut] = []
    if not authz.has_permission(user, "investigations:view"):
        return items
    visible = authz.investigation_visibility_clause(user)

    pending = db.execute(
        select(ToolRun, Investigation.reference)
        .join(Investigation, Investigation.id == ToolRun.investigation_id)
        .where(visible, ToolRun.status == RunStatus.PENDING_APPROVAL, ToolRun.requested_by_id == user.id)
        .order_by(ToolRun.created_at.desc())
        .limit(10)
    ).all()
    for run, ref in pending:
        items.append(
            NotificationOut(
                kind="approval_required",
                title=f"Approval required: {run.tool_name}",
                detail=f"{ref} · waiting for your confirmation before it runs",
                link=f"/investigations/{run.investigation_id}?tab=runs&run={run.id}",
                occurred_at=run.created_at,
            )
        )

    since = datetime.now(UTC) - timedelta(hours=24)
    finished = db.execute(
        select(ToolRun, Investigation.reference)
        .join(Investigation, Investigation.id == ToolRun.investigation_id)
        .where(
            visible,
            ToolRun.requested_by_id == user.id,
            ToolRun.status.in_([s.value for s in TERMINAL_RUN_STATUSES if s != RunStatus.REJECTED]),
            ToolRun.finished_at >= since,
        )
        .order_by(ToolRun.finished_at.desc())
        .limit(10)
    ).all()
    for run, ref in finished:
        items.append(
            NotificationOut(
                kind=f"run_{run.status}",
                title=f"{run.tool_name} {run.status.replace('_', ' ')}",
                detail=f"{ref} · {run.error_message[:120] if run.error_message else 'results recorded'}",
                link=f"/investigations/{run.investigation_id}?tab=runs&run={run.id}",
                occurred_at=run.finished_at or run.updated_at,
            )
        )

    if authz.has_permission(user, "reports:review"):
        reviews = db.execute(
            select(Report, Investigation.reference)
            .join(Investigation, Investigation.id == Report.investigation_id)
            .where(visible, Report.status == ReportStatus.IN_REVIEW)
            .order_by(Report.submitted_at.desc())
            .limit(10)
        ).all()
        for report, ref in reviews:
            if report.generated_by_id == user.id:
                continue
            items.append(
                NotificationOut(
                    kind="review_requested",
                    title=f"Report awaiting review: {report.title}",
                    detail=f"{ref} · version {report.version}",
                    link=f"/reports/{report.id}",
                    occurred_at=report.submitted_at or report.updated_at,
                )
            )

    items.sort(key=lambda n: n.occurred_at, reverse=True)
    return items[:20]
