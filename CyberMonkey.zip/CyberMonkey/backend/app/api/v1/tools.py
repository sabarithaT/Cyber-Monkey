"""Tool registry and tool runs (scans, imports, analyses)."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query, Request
from pydantic import Field
from sqlalchemy import select

from app.api.deps import CurrentUser, DbSession
from app.core.constants import RunStatus, Workspace
from app.core.pagination import Page, PageParams, page_params, paginate
from app.models import Investigation, ToolRun
from app.schemas.common import ApiModel, StrictInput, UserRef
from app.services import authz
from app.services import runs as run_svc
from app.tools.base import all_tools

router = APIRouter(tags=["Tools & runs"])


class ToolOut(ApiModel):
    name: str
    workspace: str
    title: str
    purpose: str
    permissions: list[str]
    permitted: bool
    requires_approval: str  # always | never | conditional
    timeout_seconds: int
    output_format: str
    side_effects: str
    available: bool
    availability_detail: str
    integrations: list[str]
    arguments_schema: dict[str, Any]
    example_requests: list[str]


class RunCreate(StrictInput):
    investigation_id: uuid.UUID
    tool: str = Field(min_length=1, max_length=64)
    arguments: dict[str, Any] = Field(default_factory=dict)


class RunDecision(StrictInput):
    note: str = Field(default="", max_length=2000)


class RunOut(ApiModel):
    id: uuid.UUID
    investigation_id: uuid.UUID
    investigation_reference: str
    workspace: str
    tool_name: str
    arguments: dict[str, Any]
    status: str
    origin: str
    requires_approval: bool
    requested_by: UserRef
    approved_by: UserRef | None
    approval_decided_at: datetime | None
    approval_note: str
    timeout_seconds: int
    started_at: datetime | None
    finished_at: datetime | None
    exit_code: int | None
    error_message: str
    output_summary: dict[str, Any]
    raw_output_evidence_id: uuid.UUID | None
    execution_log: list[dict[str, Any]]
    conversation_id: uuid.UUID | None
    created_at: datetime


def run_out(db, run: ToolRun) -> RunOut:  # type: ignore[no-untyped-def]
    inv = db.get(Investigation, run.investigation_id)
    return RunOut(
        id=run.id,
        investigation_id=run.investigation_id,
        investigation_reference=inv.reference if inv else "",
        workspace=run.workspace,
        tool_name=run.tool_name,
        arguments=run.arguments,
        status=run.status,
        origin=run.origin,
        requires_approval=run.requires_approval,
        requested_by=UserRef.model_validate(run.requested_by),
        approved_by=UserRef.model_validate(run.approved_by) if run.approved_by else None,
        approval_decided_at=run.approval_decided_at,
        approval_note=run.approval_note,
        timeout_seconds=run.timeout_seconds,
        started_at=run.started_at,
        finished_at=run.finished_at,
        exit_code=run.exit_code,
        error_message=run.error_message,
        output_summary=run.output_summary,
        raw_output_evidence_id=run.raw_output_evidence_id,
        execution_log=run.execution_log,
        conversation_id=run.conversation_id,
        created_at=run.created_at,
    )


@router.get("/tools", response_model=list[ToolOut], summary="Registered tools with availability and argument schemas")
def list_tools(user: CurrentUser, db: DbSession, workspace: Workspace | None = None) -> list[ToolOut]:
    out = []
    for spec in all_tools():
        if workspace and spec.workspace != workspace:
            continue
        if not authz.has_permission(user, f"{spec.workspace.value}:view"):
            continue
        available, detail = run_svc.tool_availability(db, spec)
        approval = (
            "conditional" if callable(spec.requires_approval) else ("always" if spec.requires_approval else "never")
        )
        out.append(
            ToolOut(
                name=spec.name,
                workspace=spec.workspace.value,
                title=spec.title,
                purpose=spec.purpose,
                permissions=list(spec.permissions),
                permitted=all(authz.has_permission(user, p) for p in spec.permissions),
                requires_approval=approval,
                timeout_seconds=spec.timeout_seconds,
                output_format=spec.output_format,
                side_effects=spec.side_effects,
                available=available,
                availability_detail=detail,
                integrations=[*spec.integrations_all, *spec.integrations_any],
                arguments_schema=spec.json_schema(),
                example_requests=list(spec.example_requests),
            )
        )
    return out


@router.post(
    "/tool-runs", response_model=RunOut, status_code=201, summary="Request a tool run (scan, import, analysis)"
)
def create_run(body: RunCreate, request: Request, user: CurrentUser, db: DbSession) -> RunOut:
    inv = authz.get_investigation(db, body.investigation_id, user, write=True, request=request)
    run = run_svc.request_run(
        db, user=user, investigation=inv, tool_name=body.tool, raw_args=body.arguments, request=request
    )
    db.commit()
    if run.status == RunStatus.QUEUED:
        run_svc.dispatch(run.id)
        db.refresh(run)
    return run_out(db, run)


# The specification's suggested scan endpoints map onto the generic run endpoints.
router.add_api_route(
    "/scans",
    create_run,
    methods=["POST"],
    response_model=RunOut,
    status_code=201,
    summary="Alias of POST /tool-runs",
    include_in_schema=True,
)


@router.get("/tool-runs", response_model=Page[RunOut], summary="List tool runs")
def list_runs(
    user: CurrentUser,
    db: DbSession,
    params: Annotated[PageParams, Depends(page_params)],
    investigation_id: uuid.UUID | None = None,
    workspace: Workspace | None = None,
    status: RunStatus | None = None,
    tool: str | None = Query(None, max_length=64),
) -> Page[RunOut]:
    authz.ensure_permission(user, "investigations:view")
    stmt = (
        select(ToolRun)
        .join(Investigation, Investigation.id == ToolRun.investigation_id)
        .where(authz.investigation_visibility_clause(user))
        .order_by(ToolRun.created_at.desc())
    )
    visible_ws = [ws.value for ws in authz.permitted_workspaces(user)]
    stmt = stmt.where(ToolRun.workspace.in_(visible_ws))
    if investigation_id:
        stmt = stmt.where(ToolRun.investigation_id == investigation_id)
    if workspace:
        stmt = stmt.where(ToolRun.workspace == workspace)
    if status:
        stmt = stmt.where(ToolRun.status == status)
    if tool:
        stmt = stmt.where(ToolRun.tool_name == tool)
    rows, total = paginate(db, stmt, params)
    return Page(items=[run_out(db, r) for r in rows], total=total, page=params.page, page_size=params.page_size)


@router.get("/tool-runs/{run_id}", response_model=RunOut, summary="Tool run status and output summary")
def get_run(run_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession) -> RunOut:
    run = run_svc.get_run(db, run_id, user, request=request)
    run_svc.ensure_can_view_run_output(user, run, request)
    return run_out(db, run)


router.add_api_route(
    "/scans/{run_id}", get_run, methods=["GET"], response_model=RunOut, summary="Alias of GET /tool-runs/{id}"
)


@router.post("/tool-runs/{run_id}/approve", response_model=RunOut, summary="Confirm a run that requires approval")
def approve_run(run_id: uuid.UUID, body: RunDecision, request: Request, user: CurrentUser, db: DbSession) -> RunOut:
    run = run_svc.get_run(db, run_id, user, write=True, request=request)
    run = run_svc.decide(db, run=run, user=user, approve=True, note=body.note, request=request)
    db.commit()
    run_svc.dispatch(run.id)
    db.refresh(run)
    return run_out(db, run)


@router.post("/tool-runs/{run_id}/reject", response_model=RunOut, summary="Decline a run that requires approval")
def reject_run(run_id: uuid.UUID, body: RunDecision, request: Request, user: CurrentUser, db: DbSession) -> RunOut:
    run = run_svc.get_run(db, run_id, user, write=True, request=request)
    run = run_svc.decide(db, run=run, user=user, approve=False, note=body.note, request=request)
    db.commit()
    run_svc.notify_finished(run.id)
    db.refresh(run)
    return run_out(db, run)
