"""AI assistant: conversations and natural-language requests to the orchestrator."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter, Request
from pydantic import Field
from sqlalchemy import select

from app.ai.provider import provider_status
from app.api.deps import CurrentUser, DbSession
from app.core.config import get_settings
from app.core.errors import NotFound
from app.core.ratelimit import limiter
from app.models import AssistantConversation, AssistantMessage, Evidence
from app.schemas.common import ApiModel, Message, StrictInput
from app.services import audit, authz, orchestrator
from app.services import runs as run_svc

router = APIRouter(prefix="/assistant", tags=["AI assistant"])


class ChatRequest(StrictInput):
    message: str = Field(min_length=1, max_length=4000)
    conversation_id: uuid.UUID | None = None
    investigation_id: uuid.UUID | None = None
    evidence_id: uuid.UUID | None = None


class MessageOut(ApiModel):
    id: uuid.UUID
    role: str
    content: str
    orchestration: dict[str, Any]
    created_at: datetime


class ConversationSummary(ApiModel):
    id: uuid.UUID
    title: str
    investigation_id: uuid.UUID | None
    created_at: datetime
    updated_at: datetime


class ConversationOut(ConversationSummary):
    messages: list[MessageOut]


class ChatResponse(ApiModel):
    conversation: ConversationSummary
    user_message: MessageOut
    assistant_message: MessageOut


def _conversation(db, conversation_id: uuid.UUID, user) -> AssistantConversation:  # type: ignore[no-untyped-def]
    conv = db.get(AssistantConversation, conversation_id)
    if conv is None or conv.user_id != user.id:
        raise NotFound("Conversation not found")
    return conv


@router.get("/status", summary="LLM configuration and what the assistant can do for you")
def status(request: Request, user: CurrentUser, db: DbSession) -> dict[str, Any]:
    authz.ensure_permission(user, "assistant:use", request, resource="assistant")
    return {"llm": provider_status(), "capabilities": orchestrator.capabilities(db, user)}


@router.post("/chat", response_model=ChatResponse, summary="Send a request to the AI orchestrator")
def chat(body: ChatRequest, request: Request, user: CurrentUser, db: DbSession) -> ChatResponse:
    authz.ensure_permission(user, "assistant:use", request, resource="assistant")
    limiter.hit(f"assistant:{user.id}", get_settings().assistant_rate_limit_per_minute)
    investigation = (
        authz.get_investigation(db, body.investigation_id, user, request=request) if body.investigation_id else None
    )
    if body.evidence_id:
        evidence = db.get(Evidence, body.evidence_id)
        if evidence is None or investigation is None or evidence.investigation_id != investigation.id:
            raise NotFound("Evidence not found in the selected investigation")
    if body.conversation_id:
        conversation = _conversation(db, body.conversation_id, user)
        if investigation is not None:
            conversation.investigation_id = investigation.id
    else:
        conversation = AssistantConversation(
            user_id=user.id, investigation_id=investigation.id if investigation else None, title=body.message[:80]
        )
        db.add(conversation)
        db.flush()
    user_message = AssistantMessage(
        conversation_id=conversation.id, role="user", content=body.message, orchestration={}
    )
    db.add(user_message)
    db.flush()
    reply = orchestrator.handle_message(
        db,
        user=user,
        text=body.message,
        conversation=conversation,
        investigation=investigation,
        evidence_id=str(body.evidence_id) if body.evidence_id else None,
        request=request,
    )
    conversation.updated_at = datetime.now(UTC)
    db.commit()
    db.refresh(reply)
    for step in reply.orchestration.get("plan", []):
        if step.get("status") == "queued" and step.get("run_id"):
            run_svc.dispatch(uuid.UUID(step["run_id"]))
    db.refresh(conversation)
    return ChatResponse(
        conversation=ConversationSummary.model_validate(conversation),
        user_message=MessageOut.model_validate(user_message),
        assistant_message=MessageOut.model_validate(reply),
    )


@router.get("/conversations", response_model=list[ConversationSummary], summary="Your conversations")
def list_conversations(request: Request, user: CurrentUser, db: DbSession) -> list[AssistantConversation]:
    authz.ensure_permission(user, "assistant:use", request, resource="assistant")
    return list(
        db.scalars(
            select(AssistantConversation)
            .where(AssistantConversation.user_id == user.id)
            .order_by(AssistantConversation.updated_at.desc())
            .limit(100)
        )
    )


@router.get(
    "/conversations/{conversation_id}", response_model=ConversationOut, summary="A conversation with its messages"
)
def get_conversation(conversation_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession) -> ConversationOut:
    authz.ensure_permission(user, "assistant:use", request, resource="assistant")
    conv = _conversation(db, conversation_id, user)
    return ConversationOut(
        **ConversationSummary.model_validate(conv).model_dump(),
        messages=[MessageOut.model_validate(m) for m in conv.messages],
    )


@router.delete("/conversations/{conversation_id}", response_model=Message, summary="Delete one of your conversations")
def delete_conversation(conversation_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession) -> Message:
    authz.ensure_permission(user, "assistant:use", request, resource="assistant")
    conv = _conversation(db, conversation_id, user)
    audit.record(
        db,
        action="assistant.conversation_deleted",
        actor=user,
        resource_type="assistant",
        resource_id=conv.id,
        request=request,
    )
    db.delete(conv)
    db.commit()
    return Message(message="Conversation deleted")
