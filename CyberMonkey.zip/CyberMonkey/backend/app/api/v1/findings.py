"""Findings: list, detail, triage (status / validation) and reference validation."""

from __future__ import annotations

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import case, or_, select
from sqlalchemy.orm import Session

from app.api.deps import CurrentUser, DbSession
from app.core.constants import SEVERITY_ORDER, FindingStatus, Severity, ValidationStatus, Workspace
from app.core.errors import NotFound
from app.core.pagination import Page, PageParams, page_params, paginate
from app.models import Finding, FindingIndicator, FindingReference, Indicator, Investigation, Note, User
from app.schemas.findings import (
    FindingOut,
    FindingTriage,
    IndicatorLinkOut,
    ReferenceLinkOut,
    ReferenceValidationUpdate,
)
from app.services import audit, authz

router = APIRouter(prefix="/findings", tags=["Findings"])

SEVERITY_RANK = case({s.value: SEVERITY_ORDER[s] for s in Severity}, value=Finding.severity)


def finding_out(db: Session, f: Finding) -> FindingOut:
    inv = db.get(Investigation, f.investigation_id)
    return FindingOut(
        id=f.id,
        investigation_id=f.investigation_id,
        investigation_reference=inv.reference if inv else "",
        workspace=f.workspace,
        source_tool=f.source_tool,
        run_id=f.run_id,
        origin=f.origin,
        rule_id=f.rule_id,
        finding_type=f.finding_type,
        title=f.title,
        description=f.description,
        severity=f.severity,
        confidence=f.confidence,
        affected_asset=f.affected_asset,
        observed_at=f.observed_at,
        status=f.status,
        validation_status=f.validation_status,
        details=f.details,
        evidence_refs=f.evidence_refs,
        remediation=f.remediation,
        indicators=[
            IndicatorLinkOut(
                id=link.indicator.id,
                type=link.indicator.type,
                value=link.indicator.value,
                relation=link.relation,
                context=link.context,
            )
            for link in f.indicator_links
        ],
        references=[
            ReferenceLinkOut(
                id=link.reference.id,
                ref_type=link.reference.ref_type,
                external_id=link.reference.external_id,
                title=link.reference.title,
                url=link.reference.url,
                cvss_score=link.reference.cvss_score,
                severity=link.reference.severity,
                source=link.reference.source,
                match_basis=link.match_basis,
                validation_status=link.validation_status,
                tactics=list(link.reference.data.get("tactic_names", [])) if link.reference.data else [],
            )
            for link in f.reference_links
        ],
        created_at=f.created_at,
        updated_at=f.updated_at,
    )


def visible_findings_stmt(user: User):  # type: ignore[no-untyped-def]
    workspaces = [ws.value for ws in authz.permitted_workspaces(user)]
    return (
        select(Finding)
        .join(Investigation, Investigation.id == Finding.investigation_id)
        .where(authz.investigation_visibility_clause(user), Finding.workspace.in_(workspaces))
    )


def get_finding(db: Session, finding_id: uuid.UUID, user: User, request: Request, *, write: bool = False) -> Finding:
    finding = db.get(Finding, finding_id)
    if finding is None:
        raise NotFound("Finding not found")
    authz.get_investigation(db, finding.investigation_id, user, write=write, request=request)
    authz.ensure_workspace(user, finding.workspace, "view", request)
    return finding


@router.get("", response_model=Page[FindingOut], summary="Search findings across accessible investigations")
def list_findings(
    request: Request,
    user: CurrentUser,
    db: DbSession,
    params: Annotated[PageParams, Depends(page_params)],
    investigation_id: uuid.UUID | None = None,
    workspace: Workspace | None = None,
    severity: list[Severity] | None = Query(None),
    status: FindingStatus | None = None,
    validation_status: ValidationStatus | None = None,
    finding_type: str | None = Query(None, max_length=64),
    run_id: uuid.UUID | None = None,
    search: str | None = Query(None, max_length=200),
    sort: str = Query("severity", pattern="^(severity|newest|observed)$"),
) -> Page[FindingOut]:
    authz.ensure_permission(user, "investigations:view", request)
    stmt = visible_findings_stmt(user)
    if investigation_id:
        stmt = stmt.where(Finding.investigation_id == investigation_id)
    if workspace:
        stmt = stmt.where(Finding.workspace == workspace)
    if severity:
        stmt = stmt.where(Finding.severity.in_([s.value for s in severity]))
    if status:
        stmt = stmt.where(Finding.status == status)
    if validation_status:
        stmt = stmt.where(Finding.validation_status == validation_status)
    if finding_type:
        stmt = stmt.where(Finding.finding_type == finding_type)
    if run_id:
        stmt = stmt.where(Finding.run_id == run_id)
    if search:
        like = f"%{search}%"
        stmt = stmt.where(
            or_(Finding.title.ilike(like), Finding.description.ilike(like), Finding.affected_asset.ilike(like))
        )
    if sort == "severity":
        stmt = stmt.order_by(SEVERITY_RANK.desc(), Finding.created_at.desc())
    elif sort == "observed":
        stmt = stmt.order_by(Finding.observed_at.desc().nulls_last(), Finding.created_at.desc())
    else:
        stmt = stmt.order_by(Finding.created_at.desc())
    rows, total = paginate(db, stmt, params)
    return Page(items=[finding_out(db, f) for f in rows], total=total, page=params.page, page_size=params.page_size)


@router.get("/{finding_id}", response_model=FindingOut, summary="Finding detail with evidence and references")
def get_finding_endpoint(finding_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession) -> FindingOut:
    return finding_out(db, get_finding(db, finding_id, user, request))


@router.patch("/{finding_id}", response_model=FindingOut, summary="Triage: change status or validation status")
def triage_finding(
    finding_id: uuid.UUID, body: FindingTriage, request: Request, user: CurrentUser, db: DbSession
) -> FindingOut:
    finding = get_finding(db, finding_id, user, request, write=True)
    authz.ensure_permission(user, "findings:triage", request, resource="finding")
    changes: dict[str, object] = {}
    if body.status and body.status != finding.status:
        changes["status"] = {"before": finding.status, "after": body.status}
        finding.status = body.status
    if body.validation_status and body.validation_status != finding.validation_status:
        changes["validation_status"] = {"before": finding.validation_status, "after": body.validation_status}
        finding.validation_status = body.validation_status
    if body.note:
        db.add(
            Note(investigation_id=finding.investigation_id, finding_id=finding.id, author_id=user.id, body=body.note)
        )
    audit.record(
        db,
        action="finding.triage",
        actor=user,
        resource_type="finding",
        resource_id=finding.id,
        request=request,
        details={**changes, "note_added": bool(body.note)},
    )
    db.commit()
    db.refresh(finding)
    return finding_out(db, finding)


@router.patch(
    "/{finding_id}/references/{reference_id}",
    response_model=FindingOut,
    summary="Confirm or reject a CVE / ATT&CK reference on a finding",
)
def validate_reference(
    finding_id: uuid.UUID,
    reference_id: uuid.UUID,
    body: ReferenceValidationUpdate,
    request: Request,
    user: CurrentUser,
    db: DbSession,
) -> FindingOut:
    finding = get_finding(db, finding_id, user, request, write=True)
    authz.ensure_permission(user, "findings:triage", request, resource="finding")
    link = db.get(FindingReference, (finding.id, reference_id))
    if link is None:
        raise NotFound("Reference is not attached to this finding")
    before = link.validation_status
    link.validation_status = body.validation_status
    audit.record(
        db,
        action="finding.reference_validated",
        actor=user,
        resource_type="finding",
        resource_id=finding.id,
        request=request,
        details={"reference": link.reference.external_id, "before": before, "after": body.validation_status},
    )
    db.commit()
    db.refresh(finding)
    return finding_out(db, finding)


def findings_for_indicator(db: Session, indicator: Indicator, user: User) -> list[Finding]:
    stmt = (
        visible_findings_stmt(user)
        .join(FindingIndicator, FindingIndicator.finding_id == Finding.id)
        .where(FindingIndicator.indicator_id == indicator.id)
        .order_by(Finding.created_at.desc())
    )
    return list(db.scalars(stmt.limit(200)))
