"""Overview dashboard. Every number is computed from the database over the data the
current user may see; nothing is hard-coded."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime, timedelta
from typing import Any

from fastapi import APIRouter, Request
from sqlalchemy import func, select

from app.api.deps import CurrentUser, DbSession
from app.core.constants import InvestigationStatus, Severity
from app.models import (
    AuditLog,
    Finding,
    FindingIndicator,
    Indicator,
    Investigation,
    Report,
    ToolRun,
)
from app.schemas.common import ApiModel
from app.services import authz

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


class DashboardSummary(ApiModel):
    generated_at: datetime
    has_demo_data: bool
    investigations: dict[str, int]
    findings_by_severity: dict[str, int]
    open_findings: int
    runs_by_status: dict[str, int]
    recent_runs: list[dict[str, Any]]
    recent_alerts: list[dict[str, Any]]
    recent_iocs: list[dict[str, Any]]
    latest_reports: list[dict[str, Any]]
    recent_activity: list[dict[str, Any]]
    activity_scope: str
    workspace_activity: list[dict[str, Any]]


@router.get("/summary", response_model=DashboardSummary, summary="Database-backed overview metrics")
def summary(request: Request, user: CurrentUser, db: DbSession) -> DashboardSummary:
    authz.ensure_permission(user, "dashboard:view", request)
    visible_inv = select(Investigation.id).where(authz.investigation_visibility_clause(user))
    workspaces = [ws.value for ws in authz.permitted_workspaces(user)]
    can_see_cases = authz.has_permission(user, "investigations:view")
    if not can_see_cases:
        visible_inv = visible_inv.where(Investigation.id.is_(None))

    inv_rows = dict(
        db.execute(
            select(Investigation.status, func.count())
            .where(Investigation.id.in_(visible_inv))
            .group_by(Investigation.status)
        ).all()
    )
    has_demo = bool(
        db.scalar(select(func.count()).where(Investigation.id.in_(visible_inv), Investigation.is_demo.is_(True)))
    )
    finding_scope = (
        Finding.investigation_id.in_(visible_inv),
        Finding.workspace.in_(workspaces),
        Finding.status != "false_positive",
    )
    sev_rows = dict(
        db.execute(select(Finding.severity, func.count()).where(*finding_scope).group_by(Finding.severity)).all()
    )
    open_findings = (
        db.scalar(select(func.count()).where(*finding_scope, Finding.status.in_(["open", "investigating"]))) or 0
    )

    run_scope = (ToolRun.investigation_id.in_(visible_inv), ToolRun.workspace.in_(workspaces))
    runs_by_status = dict(
        db.execute(select(ToolRun.status, func.count()).where(*run_scope).group_by(ToolRun.status)).all()
    )
    refs = dict(
        db.execute(select(Investigation.id, Investigation.reference).where(Investigation.id.in_(visible_inv))).all()
    )

    def ref(inv_id: uuid.UUID) -> str:
        return refs.get(inv_id, "")

    recent_runs = [
        {
            "id": str(r.id),
            "tool": r.tool_name,
            "workspace": r.workspace,
            "status": r.status,
            "investigation_id": str(r.investigation_id),
            "investigation_reference": ref(r.investigation_id),
            "requested_by": r.requested_by.email,
            "created_at": r.created_at,
            "finished_at": r.finished_at,
        }
        for r in db.scalars(select(ToolRun).where(*run_scope).order_by(ToolRun.created_at.desc()).limit(8))
    ]
    recent_alerts = [
        {
            "id": str(f.id),
            "title": f.title,
            "severity": f.severity,
            "workspace": f.workspace,
            "source_tool": f.source_tool,
            "investigation_id": str(f.investigation_id),
            "investigation_reference": ref(f.investigation_id),
            "observed_at": f.observed_at or f.created_at,
            "status": f.status,
        }
        for f in db.scalars(
            select(Finding)
            .where(*finding_scope, Finding.severity.in_([Severity.MEDIUM, Severity.HIGH, Severity.CRITICAL]))
            .order_by(Finding.created_at.desc())
            .limit(8)
        )
    ]
    ioc_rows = db.execute(
        select(Indicator, func.max(Finding.created_at).label("seen"), func.count(func.distinct(Finding.id)))
        .join(FindingIndicator, FindingIndicator.indicator_id == Indicator.id)
        .join(Finding, Finding.id == FindingIndicator.finding_id)
        .where(*finding_scope)
        .group_by(Indicator.id)
        .order_by(func.max(Finding.created_at).desc())
        .limit(8)
    ).all()
    recent_iocs = [
        {"id": str(i.id), "type": i.type, "value": i.value, "last_seen": seen, "finding_count": n}
        for i, seen, n in ioc_rows
    ]
    latest_reports = []
    if authz.has_permission(user, "reports:view"):
        latest_reports = [
            {
                "id": str(r.id),
                "title": r.title,
                "status": r.status,
                "version": r.version,
                "investigation_reference": ref(r.investigation_id),
                "created_at": r.created_at,
            }
            for r in db.scalars(
                select(Report)
                .where(Report.investigation_id.in_(visible_inv))
                .order_by(Report.created_at.desc())
                .limit(5)
            )
        ]
    if authz.has_permission(user, "audit:view"):
        activity_stmt, scope = select(AuditLog), "all"
    else:
        activity_stmt, scope = select(AuditLog).where(AuditLog.actor_id == user.id), "own"
    recent_activity = [
        {"id": a.id, "occurred_at": a.occurred_at, "actor": a.actor_email, "action": a.action, "result": a.result}
        for a in db.scalars(activity_stmt.order_by(AuditLog.occurred_at.desc()).limit(10))
    ]
    since = datetime.now(UTC) - timedelta(days=30)
    run_counts = dict(
        db.execute(
            select(ToolRun.workspace, func.count())
            .where(*run_scope, ToolRun.created_at >= since)
            .group_by(ToolRun.workspace)
        ).all()
    )
    finding_counts = dict(
        db.execute(
            select(Finding.workspace, func.count())
            .where(*finding_scope, Finding.created_at >= since)
            .group_by(Finding.workspace)
        ).all()
    )
    workspace_activity = [
        {"workspace": ws, "runs_30d": run_counts.get(ws, 0), "findings_30d": finding_counts.get(ws, 0)}
        for ws in workspaces
    ]
    return DashboardSummary(
        generated_at=datetime.now(UTC),
        has_demo_data=has_demo,
        investigations={
            "total": sum(inv_rows.values()),
            "open": inv_rows.get(InvestigationStatus.OPEN, 0) + inv_rows.get(InvestigationStatus.IN_PROGRESS, 0),
            "closed": inv_rows.get(InvestigationStatus.CLOSED, 0),
        },
        findings_by_severity={s.value: sev_rows.get(s.value, 0) for s in Severity},
        open_findings=open_findings,
        runs_by_status=runs_by_status,
        recent_runs=recent_runs,
        recent_alerts=recent_alerts,
        recent_iocs=recent_iocs,
        latest_reports=latest_reports,
        recent_activity=recent_activity,
        activity_scope=scope,
        workspace_activity=workspace_activity,
    )
