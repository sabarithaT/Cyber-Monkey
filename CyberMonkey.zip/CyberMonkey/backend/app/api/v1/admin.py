"""User, role and permission administration."""

from __future__ import annotations

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import func, or_, select

from app.api.deps import CurrentUser, DbSession, require
from app.core.errors import Conflict, ValidationFailed
from app.core.pagination import Page, PageParams, page_params, paginate
from app.core.security import hash_password
from app.models import Permission, Role, User, UserRole
from app.schemas.common import Message
from app.schemas.identity import (
    PasswordReset,
    PermissionOut,
    RoleCreate,
    RoleOut,
    RoleUpdate,
    UserCreate,
    UserOut,
    UserPermissionsUpdate,
    UserRolesUpdate,
    UserUpdate,
)
from app.services import audit, authz
from app.services.identity import (
    bump_role_members,
    create_role,
    create_user,
    get_role,
    get_user,
    resolve_permissions,
    role_out,
    set_user_direct_permissions,
    set_user_roles,
    user_out,
)

router = APIRouter(tags=["Administration"])

UsersAdmin = Annotated[User, Depends(require("users:manage"))]
RolesAdmin = Annotated[User, Depends(require("roles:manage"))]


# --- Users ----------------------------------------------------------------------------


@router.get("/users", response_model=Page[UserOut], summary="List users")
def list_users(
    _: UsersAdmin,
    db: DbSession,
    params: Annotated[PageParams, Depends(page_params)],
    search: str | None = Query(None, max_length=100),
) -> Page[UserOut]:
    stmt = select(User).order_by(User.created_at.desc())
    if search:
        like = f"%{search.lower()}%"
        stmt = stmt.where(or_(func.lower(User.email).like(like), func.lower(User.full_name).like(like)))
    rows, total = paginate(db, stmt, params)
    return Page(items=[user_out(u) for u in rows], total=total, page=params.page, page_size=params.page_size)


@router.post("/users", response_model=UserOut, status_code=201, summary="Create a user")
def create_user_endpoint(body: UserCreate, request: Request, actor: UsersAdmin, db: DbSession) -> UserOut:
    user = create_user(
        db, email=body.email, full_name=body.full_name, password=body.password, role_ids=body.role_ids, actor=actor
    )
    audit.record(
        db,
        action="user.create",
        actor=actor,
        resource_type="user",
        resource_id=user.id,
        request=request,
        details={"email": user.email, "role_ids": body.role_ids},
    )
    db.commit()
    return user_out(user)


@router.get("/users/{user_id}", response_model=UserOut, summary="Get a user")
def get_user_endpoint(user_id: uuid.UUID, _: UsersAdmin, db: DbSession) -> UserOut:
    return user_out(get_user(db, user_id))


@router.patch("/users/{user_id}", response_model=UserOut, summary="Update name or active status")
def update_user(user_id: uuid.UUID, body: UserUpdate, request: Request, actor: UsersAdmin, db: DbSession) -> UserOut:
    user = get_user(db, user_id)
    changes = body.model_dump(exclude_none=True)
    if body.is_active is False and user.id == actor.id:
        raise ValidationFailed("You cannot deactivate your own account")
    if "full_name" in changes:
        user.full_name = changes["full_name"]
    if "is_active" in changes and changes["is_active"] != user.is_active:
        user.is_active = changes["is_active"]
        user.token_version += 1
    audit.record(
        db,
        action="user.update",
        actor=actor,
        resource_type="user",
        resource_id=user.id,
        request=request,
        details=changes,
    )
    db.commit()
    return user_out(user)


@router.put("/users/{user_id}/roles", response_model=UserOut, summary="Replace a user's roles")
def update_user_roles(
    user_id: uuid.UUID, body: UserRolesUpdate, request: Request, actor: UsersAdmin, db: DbSession
) -> UserOut:
    user = get_user(db, user_id)
    before = sorted(r.slug for r in user.roles)
    set_user_roles(db, user, body.role_ids, actor)
    after = sorted(r.slug for r in user.roles)
    if user.id == actor.id and "users:manage" not in user.effective_permissions():
        raise ValidationFailed("You cannot remove your own user-management access")
    audit.record(
        db,
        action="user.roles_changed",
        actor=actor,
        resource_type="user",
        resource_id=user.id,
        request=request,
        details={"before": before, "after": after},
    )
    db.commit()
    return user_out(user)


@router.put("/users/{user_id}/permissions", response_model=UserOut, summary="Replace a user's direct permissions")
def update_user_permissions(
    user_id: uuid.UUID, body: UserPermissionsUpdate, request: Request, actor: UsersAdmin, db: DbSession
) -> UserOut:
    user = get_user(db, user_id)
    before = sorted(link.permission.code for link in user.permission_links)
    set_user_direct_permissions(db, user, body.permission_codes, actor)
    audit.record(
        db,
        action="user.permissions_changed",
        actor=actor,
        resource_type="user",
        resource_id=user.id,
        request=request,
        details={"before": before, "after": sorted(body.permission_codes)},
    )
    db.commit()
    return user_out(user)


@router.post("/users/{user_id}/reset-password", response_model=Message, summary="Set a new password for a user")
def reset_password(
    user_id: uuid.UUID, body: PasswordReset, request: Request, actor: UsersAdmin, db: DbSession
) -> Message:
    user = get_user(db, user_id)
    user.password_hash = hash_password(body.new_password)
    user.token_version += 1
    user.failed_login_count = 0
    user.locked_until = None
    audit.record(
        db, action="user.password_reset", actor=actor, resource_type="user", resource_id=user.id, request=request
    )
    db.commit()
    return Message(message="Password reset; existing sessions were signed out")


# --- Roles and permissions --------------------------------------------------------------


@router.get("/permissions", response_model=list[PermissionOut], summary="List all permission codes")
def list_permissions(request: Request, user: CurrentUser, db: DbSession) -> list[Permission]:
    # Needed both to edit roles and to grant direct permissions to users.
    if not (authz.has_permission(user, "roles:manage") or authz.has_permission(user, "users:manage")):
        authz.ensure_permission(user, "roles:manage", request)
    return list(db.scalars(select(Permission).order_by(Permission.scope, Permission.action)))


@router.get("/roles", response_model=list[RoleOut], summary="List roles with their permissions")
def list_roles(_: Annotated[User, Depends(require("users:manage"))], db: DbSession) -> list[RoleOut]:
    return [role_out(db, r) for r in db.scalars(select(Role).order_by(Role.name))]


@router.post("/roles", response_model=RoleOut, status_code=201, summary="Create a custom role")
def create_role_endpoint(body: RoleCreate, request: Request, actor: RolesAdmin, db: DbSession) -> RoleOut:
    role = create_role(db, name=body.name, description=body.description, codes=body.permission_codes)
    audit.record(
        db,
        action="role.create",
        actor=actor,
        resource_type="role",
        resource_id=str(role.id),
        request=request,
        details={"name": role.name, "permissions": body.permission_codes},
    )
    db.commit()
    return role_out(db, role)


@router.patch("/roles/{role_id}", response_model=RoleOut, summary="Update a role and its permissions")
def update_role(role_id: int, body: RoleUpdate, request: Request, actor: RolesAdmin, db: DbSession) -> RoleOut:
    role = get_role(db, role_id)
    details: dict[str, object] = {}
    if body.name is not None and body.name != role.name:
        if db.scalar(select(Role).where(func.lower(Role.name) == body.name.lower(), Role.id != role.id)):
            raise Conflict("A role with this name already exists")
        details["name"] = {"before": role.name, "after": body.name}
        role.name = body.name
    if body.description is not None:
        role.description = body.description
    if body.permission_codes is not None:
        if role.slug == "administrator":
            raise ValidationFailed("The Administrator role's permissions cannot be changed")
        before = [p.code for p in role.permissions]
        role.permissions = resolve_permissions(db, body.permission_codes)
        details["permissions"] = {"before": before, "after": sorted(body.permission_codes)}
        bump_role_members(db, role)
    audit.record(
        db,
        action="role.update",
        actor=actor,
        resource_type="role",
        resource_id=str(role.id),
        request=request,
        details=details,
    )
    db.commit()
    return role_out(db, role)


@router.delete("/roles/{role_id}", response_model=Message, summary="Delete a custom role")
def delete_role(role_id: int, request: Request, actor: RolesAdmin, db: DbSession) -> Message:
    role = get_role(db, role_id)
    if role.is_system:
        raise ValidationFailed("System roles cannot be deleted")
    in_use = db.scalar(select(func.count()).select_from(UserRole).where(UserRole.role_id == role.id)) or 0
    if in_use:
        raise Conflict(f"Role is assigned to {in_use} user(s); reassign them first")
    audit.record(
        db,
        action="role.delete",
        actor=actor,
        resource_type="role",
        resource_id=str(role.id),
        request=request,
        details={"name": role.name},
    )
    db.delete(role)
    db.commit()
    return Message(message="Role deleted")
