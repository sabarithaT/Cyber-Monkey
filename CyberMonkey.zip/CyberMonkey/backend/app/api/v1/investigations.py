"""Investigations: the case container shared by every workspace."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Annotated

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import or_, select

from app.api.deps import CurrentUser, DbSession
from app.core.constants import InvestigationStatus, Workspace
from app.core.errors import Conflict, NotFound, PermissionDenied, ValidationFailed
from app.core.pagination import Page, PageParams, page_params, paginate
from app.models import (
    Evidence,
    Finding,
    Investigation,
    InvestigationMember,
    LogEvent,
    Note,
    ScopeTarget,
    ToolRun,
)
from app.schemas.common import Message, UserRef
from app.schemas.investigations import (
    InvestigationCreate,
    InvestigationDetail,
    InvestigationSummary,
    InvestigationUpdate,
    MemberAdd,
    NoteCreate,
    NoteOut,
    ScopeTargetCreate,
    ScopeTargetOut,
    TimelineEntry,
)
from app.services import audit, authz
from app.services import investigations as svc
from app.services.identity import get_user_by_email

router = APIRouter(prefix="/investigations", tags=["Investigations"])


@router.post("", response_model=InvestigationDetail, status_code=201, summary="Create an investigation")
def create_investigation(
    body: InvestigationCreate, request: Request, user: CurrentUser, db: DbSession
) -> InvestigationDetail:
    authz.ensure_permission(user, "investigations:create", request, resource="investigation")
    authz.ensure_workspace(user, body.primary_workspace, "view", request)
    inv = Investigation(
        reference=svc.next_reference(db),
        title=body.title,
        description=body.description,
        primary_workspace=body.primary_workspace,
        owner_id=user.id,
    )
    db.add(inv)
    db.flush()
    audit.record(
        db,
        action="investigation.create",
        actor=user,
        resource_type="investigation",
        resource_id=inv.id,
        request=request,
        details={"reference": inv.reference, "workspace": inv.primary_workspace},
    )
    db.commit()
    db.refresh(inv)
    return svc.detail(db, inv, user)


@router.get("", response_model=Page[InvestigationSummary], summary="List investigations you can access")
def list_investigations(
    request: Request,
    user: CurrentUser,
    db: DbSession,
    params: Annotated[PageParams, Depends(page_params)],
    status: InvestigationStatus | None = None,
    workspace: Workspace | None = None,
    search: str | None = Query(None, max_length=100),
    mine: bool = False,
) -> Page[InvestigationSummary]:
    authz.ensure_permission(user, "investigations:view", request)
    stmt = (
        select(Investigation)
        .where(authz.investigation_visibility_clause(user))
        .order_by(Investigation.updated_at.desc())
    )
    if status:
        stmt = stmt.where(Investigation.status == status)
    if workspace:
        stmt = stmt.where(Investigation.primary_workspace == workspace)
    if mine:
        stmt = stmt.where(Investigation.owner_id == user.id)
    if search:
        like = f"%{search}%"
        stmt = stmt.where(or_(Investigation.title.ilike(like), Investigation.reference.ilike(like)))
    rows, total = paginate(db, stmt, params)
    return Page(items=svc.summaries(db, rows), total=total, page=params.page, page_size=params.page_size)


@router.get("/{investigation_id}", response_model=InvestigationDetail, summary="Investigation detail")
def get_investigation(
    investigation_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession
) -> InvestigationDetail:
    inv = authz.get_investigation(db, investigation_id, user, request=request)
    return svc.detail(db, inv, user)


@router.patch("/{investigation_id}", response_model=InvestigationDetail, summary="Update title, description or status")
def update_investigation(
    investigation_id: uuid.UUID, body: InvestigationUpdate, request: Request, user: CurrentUser, db: DbSession
) -> InvestigationDetail:
    inv = authz.get_investigation(db, investigation_id, user, write=True, request=request)
    changes = body.model_dump(exclude_none=True)
    for key, value in changes.items():
        setattr(inv, key, value)
    if body.status == InvestigationStatus.CLOSED and inv.closed_at is None:
        inv.closed_at = datetime.now(UTC)
    elif body.status and body.status != InvestigationStatus.CLOSED:
        inv.closed_at = None
    audit.record(
        db,
        action="investigation.update",
        actor=user,
        resource_type="investigation",
        resource_id=inv.id,
        request=request,
        details=changes,
    )
    db.commit()
    db.refresh(inv)
    return svc.detail(db, inv, user)


# --- Members --------------------------------------------------------------------------


def _ensure_owner(inv: Investigation, user, request: Request) -> None:  # type: ignore[no-untyped-def]
    if inv.owner_id != user.id and not authz.has_permission(user, "investigations:manage_all"):
        raise PermissionDenied("Only the investigation owner can manage members")


@router.post("/{investigation_id}/members", response_model=InvestigationDetail, summary="Add a member")
def add_member(
    investigation_id: uuid.UUID, body: MemberAdd, request: Request, user: CurrentUser, db: DbSession
) -> InvestigationDetail:
    inv = authz.get_investigation(db, investigation_id, user, write=True, request=request)
    _ensure_owner(inv, user, request)
    member = get_user_by_email(db, body.email)
    if member is None or not member.is_active:
        raise NotFound("No active user with that email")
    if member.id == inv.owner_id:
        raise ValidationFailed("The owner is already part of the investigation")
    existing = db.get(InvestigationMember, (inv.id, member.id))
    if existing:
        existing.access_level = body.access_level
    else:
        db.add(
            InvestigationMember(
                investigation_id=inv.id, user_id=member.id, access_level=body.access_level, added_by_id=user.id
            )
        )
    audit.record(
        db,
        action="investigation.member_added",
        actor=user,
        resource_type="investigation",
        resource_id=inv.id,
        request=request,
        details={"member": member.email, "access_level": body.access_level},
    )
    db.commit()
    db.refresh(inv)
    return svc.detail(db, inv, user)


@router.delete("/{investigation_id}/members/{user_id}", response_model=InvestigationDetail, summary="Remove a member")
def remove_member(
    investigation_id: uuid.UUID, user_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession
) -> InvestigationDetail:
    inv = authz.get_investigation(db, investigation_id, user, write=True, request=request)
    _ensure_owner(inv, user, request)
    existing = db.get(InvestigationMember, (inv.id, user_id))
    if existing is None:
        raise NotFound("Not a member")
    db.delete(existing)
    audit.record(
        db,
        action="investigation.member_removed",
        actor=user,
        resource_type="investigation",
        resource_id=inv.id,
        request=request,
        details={"member_id": str(user_id)},
    )
    db.commit()
    db.refresh(inv)
    return svc.detail(db, inv, user)


# --- Authorized scope ------------------------------------------------------------------


@router.post(
    "/{investigation_id}/scope", response_model=ScopeTargetOut, status_code=201, summary="Register an authorized target"
)
def add_scope_target(
    investigation_id: uuid.UUID, body: ScopeTargetCreate, request: Request, user: CurrentUser, db: DbSession
) -> ScopeTargetOut:
    inv = authz.get_investigation(db, investigation_id, user, write=True, request=request)
    authz.ensure_workspace(user, Workspace.PENTEST, "operate", request)
    if body.valid_until and body.valid_until <= datetime.now(UTC):
        raise ValidationFailed("valid_until must be in the future")
    exists = db.scalar(
        select(ScopeTarget).where(
            ScopeTarget.investigation_id == inv.id,
            ScopeTarget.target_type == body.target_type,
            ScopeTarget.value == body.value,
        )
    )
    if exists:
        raise Conflict("This target is already registered for the investigation")
    target = ScopeTarget(
        investigation_id=inv.id,
        target_type=body.target_type,
        value=body.value,
        authorization_reference=body.authorization_reference,
        authorized_by_id=user.id,
        valid_until=body.valid_until,
        notes=body.notes,
    )
    db.add(target)
    db.flush()
    audit.record(
        db,
        action="investigation.scope_added",
        actor=user,
        resource_type="investigation",
        resource_id=inv.id,
        request=request,
        details={"target": f"{body.target_type}:{body.value}", "authorization_reference": body.authorization_reference},
    )
    db.commit()
    db.refresh(target)
    return ScopeTargetOut(
        id=target.id,
        target_type=target.target_type,
        value=target.value,
        authorization_reference=target.authorization_reference,
        authorized_by=UserRef.model_validate(target.authorized_by),
        valid_from=target.valid_from,
        valid_until=target.valid_until,
        notes=target.notes,
        created_at=target.created_at,
        active=svc.scope_target_active(target),
    )


@router.delete("/{investigation_id}/scope/{target_id}", response_model=Message, summary="Remove an authorized target")
def remove_scope_target(
    investigation_id: uuid.UUID, target_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession
) -> Message:
    inv = authz.get_investigation(db, investigation_id, user, write=True, request=request)
    authz.ensure_workspace(user, Workspace.PENTEST, "operate", request)
    target = db.get(ScopeTarget, target_id)
    if target is None or target.investigation_id != inv.id:
        raise NotFound("Scope target not found")
    audit.record(
        db,
        action="investigation.scope_removed",
        actor=user,
        resource_type="investigation",
        resource_id=inv.id,
        request=request,
        details={"target": f"{target.target_type}:{target.value}"},
    )
    db.delete(target)
    db.commit()
    return Message(message="Scope target removed")


# --- Notes -----------------------------------------------------------------------------


@router.get("/{investigation_id}/notes", response_model=list[NoteOut], summary="Investigation notes")
def list_notes(
    investigation_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession, finding_id: uuid.UUID | None = None
) -> list[Note]:
    inv = authz.get_investigation(db, investigation_id, user, request=request)
    stmt = select(Note).where(Note.investigation_id == inv.id).order_by(Note.created_at.desc())
    if finding_id:
        stmt = stmt.where(Note.finding_id == finding_id)
    return list(db.scalars(stmt.limit(500)))


@router.post("/{investigation_id}/notes", response_model=NoteOut, status_code=201, summary="Add a note")
def add_note(investigation_id: uuid.UUID, body: NoteCreate, request: Request, user: CurrentUser, db: DbSession) -> Note:
    inv = authz.get_investigation(db, investigation_id, user, write=True, request=request)
    if body.finding_id:
        finding = db.get(Finding, body.finding_id)
        if finding is None or finding.investigation_id != inv.id:
            raise NotFound("Finding not found in this investigation")
    note = Note(investigation_id=inv.id, finding_id=body.finding_id, author_id=user.id, body=body.body)
    db.add(note)
    db.flush()
    audit.record(
        db,
        action="investigation.note_added",
        actor=user,
        resource_type="investigation",
        resource_id=inv.id,
        request=request,
        details={"note_id": str(note.id), "finding_id": str(body.finding_id) if body.finding_id else None},
    )
    db.commit()
    db.refresh(note)
    return note


# --- Timeline --------------------------------------------------------------------------


@router.get(
    "/{investigation_id}/timeline", response_model=list[TimelineEntry], summary="Chronological view of activity"
)
def timeline(
    investigation_id: uuid.UUID,
    request: Request,
    user: CurrentUser,
    db: DbSession,
    limit: int = Query(300, ge=1, le=1000),
) -> list[TimelineEntry]:
    inv = authz.get_investigation(db, investigation_id, user, request=request)
    entries: list[TimelineEntry] = []
    for f in db.scalars(
        select(Finding).where(Finding.investigation_id == inv.id).order_by(Finding.created_at.desc()).limit(limit)
    ):
        entries.append(
            TimelineEntry(
                at=f.observed_at or f.created_at,
                kind="finding",
                title=f.title,
                detail=f"{f.source_tool} · {f.affected_asset}".strip(" ·"),
                severity=f.severity,
                workspace=f.workspace,
                ref_id=str(f.id),
            )
        )
    events = db.scalars(
        select(LogEvent)
        .where(
            LogEvent.investigation_id == inv.id,
            LogEvent.event_time.is_not(None),
            LogEvent.severity.in_(["medium", "high", "critical"]),
        )
        .order_by(LogEvent.event_time.desc())
        .limit(limit)
    )
    for e in events:
        entries.append(
            TimelineEntry(
                at=e.event_time,
                kind="log_event",
                title=e.event_type or "log event",
                detail=e.message[:200],  # type: ignore[arg-type]
                severity=e.severity,
                workspace="soc",
                ref_id=str(e.id),
            )
        )
    for r in db.scalars(
        select(ToolRun).where(ToolRun.investigation_id == inv.id).order_by(ToolRun.created_at.desc()).limit(limit)
    ):
        entries.append(
            TimelineEntry(
                at=r.finished_at or r.started_at or r.created_at,
                kind="run",
                title=f"{r.tool_name} ({r.status.replace('_', ' ')})",
                detail=f"requested by {r.requested_by.email}",
                workspace=r.workspace,
                ref_id=str(r.id),
            )
        )
    for ev in db.scalars(
        select(Evidence).where(Evidence.investigation_id == inv.id).order_by(Evidence.created_at.desc()).limit(limit)
    ):
        entries.append(
            TimelineEntry(
                at=ev.acquired_at or ev.created_at,
                kind="evidence",
                title=f"Evidence: {ev.original_filename}",
                detail=f"{ev.kind} · sha256 {ev.sha256[:16]}…",
                ref_id=str(ev.id),
            )
        )
    for n in db.scalars(
        select(Note).where(Note.investigation_id == inv.id).order_by(Note.created_at.desc()).limit(limit)
    ):
        entries.append(
            TimelineEntry(
                at=n.created_at,
                kind="note",
                title=f"Note by {n.author.full_name}",
                detail=n.body[:200],
                ref_id=str(n.id),
            )
        )
    entries.sort(key=lambda e: e.at, reverse=True)
    return entries[:limit]
