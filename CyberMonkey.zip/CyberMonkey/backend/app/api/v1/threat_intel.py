"""Threat Intelligence Engine API: indicators, correlation, references, enrichment, risk."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import func, or_, select

from app.api.deps import CurrentUser, DbSession
from app.api.v1.findings import finding_out, findings_for_indicator, visible_findings_stmt
from app.core.constants import IndicatorType
from app.core.errors import NotFound
from app.core.pagination import Page, PageParams, page_params
from app.models import Finding, FindingIndicator, FindingReference, Indicator, RiskAssessment, ThreatIntelReference
from app.schemas.common import ApiModel, StrictInput
from app.schemas.findings import FindingOut
from app.services import attack, audit, authz, nvd, risk
from app.services import indicators as ioc
from app.services.correlation import investigation_correlations
from app.services.integrations import availability
from app.services.runs import _executor

router = APIRouter(prefix="/threat-intelligence", tags=["Threat intelligence"])


class IndicatorOut(ApiModel):
    id: uuid.UUID
    type: str
    value: str
    is_internal: bool
    first_seen: datetime
    last_seen: datetime
    finding_count: int
    investigation_count: int
    workspaces: list[str]
    reputation: dict[str, Any]


class IndicatorDetail(IndicatorOut):
    findings: list[FindingOut]


class CorrelationOut(ApiModel):
    indicator_id: uuid.UUID
    type: str
    value: str
    is_internal: bool
    workspaces: list[str]
    finding_ids: list[uuid.UUID]
    other_investigations: list[dict[str, str]]
    correlated: bool
    reasons: list[str]


class ReferenceOut(ApiModel):
    id: uuid.UUID
    ref_type: str
    external_id: str
    title: str
    description: str
    cvss_score: float | None
    cvss_vector: str | None
    severity: str | None
    url: str
    source: str
    fetched_at: datetime
    finding_count: int
    data: dict[str, Any]


class RiskOut(ApiModel):
    id: uuid.UUID
    investigation_id: uuid.UUID
    score: float | None
    lower_bound: float
    upper_bound: float
    coverage: float
    finding_count: int
    weights: dict[str, Any]
    components: dict[str, Any]
    computed_at: datetime


class EnrichRequest(StrictInput):
    investigation_id: uuid.UUID


def _view(user, request) -> None:  # type: ignore[no-untyped-def]
    authz.ensure_permission(user, "threat_intel:view", request, resource="threat_intel")


@router.get("/iocs", response_model=Page[IndicatorOut], summary="Indicators seen in findings you can access")
def list_iocs(
    request: Request,
    user: CurrentUser,
    db: DbSession,
    params: Annotated[PageParams, Depends(page_params)],
    type: IndicatorType | None = None,
    search: str | None = Query(None, max_length=200),
    investigation_id: uuid.UUID | None = None,
    correlated_only: bool = False,
) -> Page[IndicatorOut]:
    _view(user, request)
    visible = (
        visible_findings_stmt(user)
        .with_only_columns(Finding.id, Finding.investigation_id, Finding.workspace)
        .subquery()
    )
    stats = (
        select(
            FindingIndicator.indicator_id.label("indicator_id"),
            func.count(func.distinct(visible.c.id)).label("finding_count"),
            func.count(func.distinct(visible.c.investigation_id)).label("investigation_count"),
            func.array_agg(func.distinct(visible.c.workspace)).label("workspaces"),
        )
        .join(visible, visible.c.id == FindingIndicator.finding_id)
        .group_by(FindingIndicator.indicator_id)
    )
    if investigation_id:
        in_case = (
            select(FindingIndicator.indicator_id)
            .join(Finding, Finding.id == FindingIndicator.finding_id)
            .where(Finding.investigation_id == investigation_id)
        )
        stats = stats.where(FindingIndicator.indicator_id.in_(in_case))
    stats_sq = stats.subquery()
    stmt = select(Indicator, stats_sq.c.finding_count, stats_sq.c.investigation_count, stats_sq.c.workspaces).join(
        stats_sq, stats_sq.c.indicator_id == Indicator.id
    )
    if type:
        stmt = stmt.where(Indicator.type == type)
    if search:
        stmt = stmt.where(Indicator.value.ilike(f"%{search.strip().lower()}%"))
    if correlated_only:
        stmt = stmt.where(or_(stats_sq.c.investigation_count > 1, func.cardinality(stats_sq.c.workspaces) > 1))
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = db.execute(
        stmt.order_by(
            stats_sq.c.investigation_count.desc(), stats_sq.c.finding_count.desc(), Indicator.last_seen.desc()
        )
        .offset(params.offset)
        .limit(params.page_size)
    ).all()
    items = []
    for indicator, finding_count, investigation_count, workspaces in rows:
        normalized = ioc.normalize(indicator.type, indicator.value)
        items.append(
            IndicatorOut(
                id=indicator.id,
                type=indicator.type,
                value=indicator.value,
                is_internal=bool(normalized and normalized.is_internal),
                first_seen=indicator.first_seen,
                last_seen=indicator.last_seen,
                finding_count=finding_count,
                investigation_count=investigation_count,
                workspaces=sorted(w for w in workspaces if w),
                reputation=indicator.reputation,
            )
        )
    return Page(items=items, total=total, page=params.page, page_size=params.page_size)


@router.get(
    "/iocs/{indicator_id}", response_model=IndicatorDetail, summary="Indicator with every finding that references it"
)
def get_ioc(indicator_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession) -> IndicatorDetail:
    _view(user, request)
    indicator = db.get(Indicator, indicator_id)
    findings = findings_for_indicator(db, indicator, user) if indicator else []
    if indicator is None or not findings:
        raise NotFound("Indicator not found")
    normalized = ioc.normalize(indicator.type, indicator.value)
    return IndicatorDetail(
        id=indicator.id,
        type=indicator.type,
        value=indicator.value,
        is_internal=bool(normalized and normalized.is_internal),
        first_seen=indicator.first_seen,
        last_seen=indicator.last_seen,
        finding_count=len(findings),
        investigation_count=len({f.investigation_id for f in findings}),
        workspaces=sorted({f.workspace for f in findings}),
        reputation=indicator.reputation,
        findings=[finding_out(db, f) for f in findings],
    )


@router.get("/correlations", response_model=list[CorrelationOut], summary="Indicator correlation for an investigation")
def correlations(
    investigation_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession
) -> list[CorrelationOut]:
    _view(user, request)
    inv = authz.get_investigation(db, investigation_id, user, request=request)
    return [
        CorrelationOut(
            indicator_id=c.indicator_id,
            type=c.type,
            value=c.value,
            is_internal=c.is_internal,
            workspaces=c.workspaces,
            finding_ids=c.finding_ids,
            other_investigations=c.other_investigations,
            correlated=c.correlated,
            reasons=c.reasons(),
        )
        for c in investigation_correlations(db, inv, user)
    ]


@router.get(
    "/references", response_model=Page[ReferenceOut], summary="CVE and ATT&CK references linked to your findings"
)
def list_references(
    request: Request,
    user: CurrentUser,
    db: DbSession,
    params: Annotated[PageParams, Depends(page_params)],
    ref_type: str | None = Query(None, pattern="^(cve|attack_technique)$"),
    investigation_id: uuid.UUID | None = None,
    search: str | None = Query(None, max_length=100),
) -> Page[ReferenceOut]:
    _view(user, request)
    visible = (
        visible_findings_stmt(user)
        .with_only_columns(Finding.id)
        .where(*([Finding.investigation_id == investigation_id] if investigation_id else []))
    )
    counts = (
        select(FindingReference.reference_id, func.count().label("n"))
        .where(FindingReference.finding_id.in_(visible))
        .group_by(FindingReference.reference_id)
        .subquery()
    )
    stmt = select(ThreatIntelReference, counts.c.n).join(counts, counts.c.reference_id == ThreatIntelReference.id)
    if ref_type:
        stmt = stmt.where(ThreatIntelReference.ref_type == ref_type)
    if search:
        like = f"%{search}%"
        stmt = stmt.where(or_(ThreatIntelReference.external_id.ilike(like), ThreatIntelReference.title.ilike(like)))
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = db.execute(
        stmt.order_by(ThreatIntelReference.cvss_score.desc().nulls_last(), counts.c.n.desc())
        .offset(params.offset)
        .limit(params.page_size)
    ).all()
    items = [
        ReferenceOut(
            id=r.id,
            ref_type=r.ref_type,
            external_id=r.external_id,
            title=r.title,
            description=r.description,
            cvss_score=r.cvss_score,
            cvss_vector=r.cvss_vector,
            severity=r.severity,
            url=r.url,
            source=r.source,
            fetched_at=r.fetched_at,
            finding_count=n,
            data=r.data,
        )
        for r, n in rows
    ]
    return Page(items=items, total=total, page=params.page, page_size=params.page_size)


@router.get("/attack/techniques", summary="Search the ATT&CK technique catalogue")
def search_techniques(request: Request, user: CurrentUser, q: str = Query("", max_length=100)) -> dict[str, Any]:
    _view(user, request)
    cat = attack.catalog()
    query = q.strip().lower()
    matches = [
        {"id": t.id, "name": t.name, "tactics": [cat.tactic_names.get(x, x) for x in t.tactics], "url": t.url}
        for t in cat.techniques.values()
        if not query or query in t.id.lower() or query in t.name.lower()
    ]
    return {"source": cat.source, "total": len(matches), "items": sorted(matches, key=lambda m: m["id"])[:100]}


@router.post("/enrich-cves", status_code=202, summary="Fetch CVE details from NVD for an investigation")
def enrich_cves(body: EnrichRequest, request: Request, user: CurrentUser, db: DbSession) -> dict[str, Any]:
    authz.ensure_permission(user, "threat_intel:enrich", request, resource="threat_intel")
    inv = authz.get_investigation(db, body.investigation_id, user, write=True, request=request)
    state = availability(db, "nvd")
    if not state.available:
        return {"queued": 0, "status": state.status, "detail": state.detail}
    pending = list(
        db.scalars(
            select(ThreatIntelReference.external_id)
            .join(FindingReference, FindingReference.reference_id == ThreatIntelReference.id)
            .join(Finding, Finding.id == FindingReference.finding_id)
            .where(
                Finding.investigation_id == inv.id,
                ThreatIntelReference.ref_type == "cve",
                ThreatIntelReference.source != "nvd",
            )
            .distinct()
        )
    )[:50]
    audit.record(
        db,
        action="threat_intel.enrich_cves",
        actor=user,
        resource_type="investigation",
        resource_id=inv.id,
        request=request,
        details={"cves": pending},
    )
    db.commit()
    if pending:
        _executor.submit(nvd.enrich, pending)
    return {
        "queued": len(pending),
        "status": "queued" if pending else "nothing_to_enrich",
        "detail": "CVE details are fetched from NVD in the background; the public rate limit allows about one request every 6 seconds without an API key.",
        "cves": pending,
    }


def _risk_out(a: RiskAssessment) -> RiskOut:
    return RiskOut.model_validate(a)


@router.post(
    "/risk/{investigation_id}", response_model=RiskOut, status_code=201, summary="Compute and store the risk score"
)
def compute_risk(investigation_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession) -> RiskOut:
    _view(user, request)
    inv = authz.get_investigation(db, investigation_id, user, request=request)
    assessment = risk.compute(db, inv, user)
    audit.record(
        db,
        action="threat_intel.risk_computed",
        actor=user,
        resource_type="investigation",
        resource_id=inv.id,
        request=request,
        details={
            "score": assessment.score,
            "coverage": assessment.coverage,
            "missing": assessment.components["missing"],
        },
    )
    db.commit()
    db.refresh(assessment)
    return _risk_out(assessment)


@router.get("/risk/{investigation_id}", response_model=list[RiskOut], summary="Risk score history (newest first)")
def risk_history(investigation_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession) -> list[RiskOut]:
    _view(user, request)
    inv = authz.get_investigation(db, investigation_id, user, request=request)
    rows = db.scalars(
        select(RiskAssessment)
        .where(RiskAssessment.investigation_id == inv.id)
        .order_by(RiskAssessment.computed_at.desc())
        .limit(50)
    )
    return [_risk_out(a) for a in rows]
