"""Evidence upload, listing, custody history, hash verification and download."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Annotated, Any

from fastapi import APIRouter, File, Form, Query, Request, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy import select

from app.api.deps import CurrentUser, DbSession
from app.core.constants import EvidenceKind
from app.core.errors import NotFound, PermissionDenied
from app.models import Evidence, EvidenceEvent
from app.schemas.common import ApiModel, UserRef
from app.services import audit, authz
from app.services import evidence as svc

router = APIRouter(tags=["Evidence"])


class EvidenceOut(ApiModel):
    id: uuid.UUID
    investigation_id: uuid.UUID
    kind: str
    original_filename: str
    size_bytes: int
    md5: str
    sha1: str
    sha256: str
    detected_type: str
    source_description: str
    acquired_at: datetime | None
    uploaded_by: UserRef | None
    is_original: bool
    parent_evidence_id: uuid.UUID | None
    produced_by_run_id: uuid.UUID | None
    notes: str
    metadata: dict[str, Any]
    created_at: datetime
    downloadable: bool


class EvidenceEventOut(ApiModel):
    id: uuid.UUID
    action: str
    actor: UserRef | None
    run_id: uuid.UUID | None
    details: dict[str, Any]
    created_at: datetime


class EvidenceDetail(EvidenceOut):
    events: list[EvidenceEventOut]


def evidence_out(e: Evidence) -> EvidenceOut:
    return EvidenceOut(
        id=e.id,
        investigation_id=e.investigation_id,
        kind=e.kind,
        original_filename=e.original_filename,
        size_bytes=e.size_bytes,
        md5=e.md5,
        sha1=e.sha1,
        sha256=e.sha256,
        detected_type=e.detected_type,
        source_description=e.source_description,
        acquired_at=e.acquired_at,
        uploaded_by=UserRef.model_validate(e.uploaded_by) if e.uploaded_by else None,
        is_original=e.is_original,
        parent_evidence_id=e.parent_evidence_id,
        produced_by_run_id=e.produced_by_run_id,
        notes=e.notes,
        metadata=e.metadata_json,
        created_at=e.created_at,
        downloadable=bool(e.stored_path) and EvidenceKind(e.kind) not in svc.NO_DOWNLOAD_KINDS,
    )


def _get_evidence(db, evidence_id: uuid.UUID, user, request: Request, *, write: bool = False) -> Evidence:  # type: ignore[no-untyped-def]
    evidence = db.get(Evidence, evidence_id)
    if evidence is None:
        raise NotFound("Evidence not found")
    authz.get_investigation(db, evidence.investigation_id, user, write=write, request=request)
    return evidence


@router.post(
    "/investigations/{investigation_id}/evidence",
    response_model=EvidenceOut,
    status_code=201,
    summary="Upload an evidence file",
)
def upload_evidence(
    investigation_id: uuid.UUID,
    request: Request,
    user: CurrentUser,
    db: DbSession,
    file: Annotated[UploadFile, File(description="The evidence file")],
    kind: Annotated[EvidenceKind, Form()],
    source_description: Annotated[str, Form(max_length=2000)] = "",
    acquired_at: Annotated[datetime | None, Form()] = None,
    notes: Annotated[str, Form(max_length=5000)] = "",
) -> EvidenceOut:
    if kind == EvidenceKind.TOOL_OUTPUT:
        raise PermissionDenied("Tool output evidence is captured by the platform and cannot be uploaded")
    inv = authz.get_investigation(db, investigation_id, user, write=True, request=request)
    authz.ensure_permission(user, "evidence:upload", request, resource="evidence")
    authz.ensure_workspace(user, svc.KIND_WORKSPACE[kind], "operate", request)
    evidence = svc.store_upload(
        db,
        investigation_id=inv.id,
        kind=kind,
        stream=file.file,
        filename=file.filename,
        uploaded_by=user,
        source_description=source_description,
        acquired_at=acquired_at,
        notes=notes,
    )
    audit.record(
        db,
        action="evidence.upload",
        actor=user,
        resource_type="evidence",
        resource_id=evidence.id,
        request=request,
        details={
            "investigation": inv.reference,
            "kind": kind.value,
            "filename": evidence.original_filename,
            "sha256": evidence.sha256,
            "size_bytes": evidence.size_bytes,
            "detected_type": evidence.detected_type,
        },
    )
    db.commit()
    db.refresh(evidence)
    return evidence_out(evidence)


@router.get("/investigations/{investigation_id}/evidence", response_model=list[EvidenceOut], summary="List evidence")
def list_evidence(
    investigation_id: uuid.UUID,
    request: Request,
    user: CurrentUser,
    db: DbSession,
    kind: EvidenceKind | None = None,
    include_derived: bool = Query(True, description="Include tool output captured by the platform"),
) -> list[EvidenceOut]:
    inv = authz.get_investigation(db, investigation_id, user, request=request)
    stmt = select(Evidence).where(Evidence.investigation_id == inv.id).order_by(Evidence.created_at.desc())
    if kind:
        stmt = stmt.where(Evidence.kind == kind.value)
    if not include_derived:
        stmt = stmt.where(Evidence.is_original.is_(True))
    return [evidence_out(e) for e in db.scalars(stmt.limit(1000))]


@router.get("/evidence/{evidence_id}", response_model=EvidenceDetail, summary="Evidence detail with custody history")
def get_evidence(evidence_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession) -> EvidenceDetail:
    evidence = _get_evidence(db, evidence_id, user, request)
    events = db.scalars(
        select(EvidenceEvent).where(EvidenceEvent.evidence_id == evidence.id).order_by(EvidenceEvent.created_at)
    )
    svc.add_event(db, evidence, "metadata_viewed", user)
    db.commit()
    return EvidenceDetail(
        **evidence_out(evidence).model_dump(),
        events=[
            EvidenceEventOut(
                id=ev.id,
                action=ev.action,
                actor=UserRef.model_validate(ev.actor) if ev.actor else None,
                run_id=ev.run_id,
                details=ev.details,
                created_at=ev.created_at,
            )
            for ev in events
        ],
    )


@router.post("/evidence/{evidence_id}/verify", response_model=dict[str, Any], summary="Re-hash the stored file")
def verify_evidence(evidence_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession) -> dict[str, Any]:
    evidence = _get_evidence(db, evidence_id, user, request)
    result = svc.verify_hash(evidence)
    svc.add_event(db, evidence, "hash_verified", user, details=result)
    audit.record(
        db,
        action="evidence.verify",
        actor=user,
        resource_type="evidence",
        resource_id=evidence.id,
        request=request,
        result="success" if result["match"] else "failure",
        details=result,
    )
    db.commit()
    return result


@router.get("/evidence/{evidence_id}/download", summary="Download the stored evidence file")
def download_evidence(evidence_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession) -> FileResponse:
    evidence = _get_evidence(db, evidence_id, user, request)
    authz.ensure_permission(user, "evidence:download", request, resource="evidence")
    if EvidenceKind(evidence.kind) in svc.NO_DOWNLOAD_KINDS:
        audit.record_independent(
            action="evidence.download",
            result="denied",
            actor=user,
            resource_type="evidence",
            resource_id=evidence.id,
            request=request,
            details={"reason": "kind not downloadable", "kind": evidence.kind},
        )
        raise PermissionDenied("Malware samples cannot be downloaded through the web application")
    path = svc.absolute_path(evidence)
    if not path.is_file():
        raise NotFound("The stored file is missing")
    svc.add_event(db, evidence, "downloaded", user)
    audit.record(
        db,
        action="evidence.download",
        actor=user,
        resource_type="evidence",
        resource_id=evidence.id,
        request=request,
        details={"sha256": evidence.sha256},
    )
    db.commit()
    return FileResponse(
        path,
        media_type="application/octet-stream",
        filename=evidence.original_filename,
        headers={"X-Content-Type-Options": "nosniff"},
    )
