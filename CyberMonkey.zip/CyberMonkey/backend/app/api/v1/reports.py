"""Reports: generation, history, review workflow and PDF export."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Request
from fastapi.responses import Response
from pydantic import Field
from sqlalchemy import select

from app.api.deps import CurrentUser, DbSession
from app.core.config import get_settings
from app.core.constants import ReportStatus
from app.core.errors import NotFound, PermissionDenied, ValidationFailed
from app.core.pagination import Page, PageParams, page_params, paginate
from app.models import Investigation, Report
from app.schemas.common import ApiModel, StrictInput, UserRef
from app.services import audit, authz, pdf
from app.services import reports as svc

router = APIRouter(prefix="/reports", tags=["Reports"])


class ReportCreate(StrictInput):
    investigation_id: uuid.UUID
    title: str | None = Field(default=None, max_length=300)


class ReportUpdate(StrictInput):
    analyst_notes: str = Field(max_length=20_000)


class ReviewDecision(StrictInput):
    comment: str = Field(default="", max_length=5000)


class ReportSummary(ApiModel):
    id: uuid.UUID
    investigation_id: uuid.UUID
    investigation_reference: str
    version: int
    title: str
    status: str
    generation_mode: str
    llm_provider: str | None
    llm_model: str | None
    generated_by: UserRef
    reviewed_by: UserRef | None
    created_at: datetime
    reviewed_at: datetime | None
    risk_score: float | None
    finding_count: int
    citation_issue_count: int
    is_demo: bool


class ReportDetail(ReportSummary):
    content: dict[str, Any]
    narrative: dict[str, Any]
    analyst_notes: str
    submitted_at: datetime | None
    review_comment: str


def _summary(db, r: Report) -> dict[str, Any]:  # type: ignore[no-untyped-def]
    inv = db.get(Investigation, r.investigation_id)
    return dict(
        id=r.id,
        investigation_id=r.investigation_id,
        investigation_reference=inv.reference if inv else "",
        version=r.version,
        title=r.title,
        status=r.status,
        generation_mode=r.generation_mode,
        llm_provider=r.llm_provider,
        llm_model=r.llm_model,
        generated_by=UserRef.model_validate(r.generated_by),
        reviewed_by=UserRef.model_validate(r.reviewed_by) if r.reviewed_by else None,
        created_at=r.created_at,
        reviewed_at=r.reviewed_at,
        risk_score=r.content.get("risk", {}).get("score"),
        finding_count=len(r.content.get("findings", [])),
        citation_issue_count=len(r.narrative.get("citation_issues", [])),
        is_demo=bool(r.content.get("investigation", {}).get("is_demo")),
    )


def _detail(db, r: Report) -> ReportDetail:  # type: ignore[no-untyped-def]
    return ReportDetail(
        **_summary(db, r),
        content=r.content,
        narrative=r.narrative,
        analyst_notes=r.analyst_notes,
        submitted_at=r.submitted_at,
        review_comment=r.review_comment,
    )


def _get(db, report_id: uuid.UUID, user, request: Request, *, write: bool = False) -> Report:  # type: ignore[no-untyped-def]
    authz.ensure_permission(user, "reports:view", request, resource="report")
    report = db.get(Report, report_id)
    if report is None:
        raise NotFound("Report not found")
    authz.get_investigation(db, report.investigation_id, user, write=write, request=request)
    return report


def _create(db, inv: Investigation, user, request: Request, title: str | None) -> Report:  # type: ignore[no-untyped-def]
    return svc.create_report(db, inv, user, title=title, request=request)


@router.post(
    "", response_model=ReportDetail, status_code=201, summary="Generate a report from current investigation data"
)
def create_report(body: ReportCreate, request: Request, user: CurrentUser, db: DbSession) -> ReportDetail:
    authz.ensure_permission(user, "reports:generate", request, resource="report")
    inv = authz.get_investigation(db, body.investigation_id, user, write=True, request=request)
    report = _create(db, inv, user, request, body.title)
    db.commit()
    db.refresh(report)
    return _detail(db, report)


@router.get("", response_model=Page[ReportSummary], summary="Report history")
def list_reports(
    request: Request,
    user: CurrentUser,
    db: DbSession,
    params: Annotated[PageParams, Depends(page_params)],
    investigation_id: uuid.UUID | None = None,
    status: ReportStatus | None = None,
) -> Page[ReportSummary]:
    authz.ensure_permission(user, "reports:view", request, resource="report")
    stmt = (
        select(Report)
        .join(Investigation, Investigation.id == Report.investigation_id)
        .where(authz.investigation_visibility_clause(user))
        .order_by(Report.created_at.desc())
    )
    if investigation_id:
        stmt = stmt.where(Report.investigation_id == investigation_id)
    if status:
        stmt = stmt.where(Report.status == status)
    rows, total = paginate(db, stmt, params)
    return Page(
        items=[ReportSummary(**_summary(db, r)) for r in rows],
        total=total,
        page=params.page,
        page_size=params.page_size,
    )


@router.get("/{report_id}", response_model=ReportDetail, summary="Report preview")
def get_report(report_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession) -> ReportDetail:
    return _detail(db, _get(db, report_id, user, request))


@router.patch("/{report_id}", response_model=ReportDetail, summary="Edit analyst notes on a draft")
def update_report(
    report_id: uuid.UUID, body: ReportUpdate, request: Request, user: CurrentUser, db: DbSession
) -> ReportDetail:
    report = _get(db, report_id, user, request, write=True)
    if report.status not in (ReportStatus.DRAFT, ReportStatus.CHANGES_REQUESTED):
        raise ValidationFailed("Only drafts can be edited; regenerate to create a new version")
    report.analyst_notes = body.analyst_notes
    audit.record(db, action="report.update", actor=user, resource_type="report", resource_id=report.id, request=request)
    db.commit()
    db.refresh(report)
    return _detail(db, report)


@router.post(
    "/{report_id}/regenerate",
    response_model=ReportDetail,
    status_code=201,
    summary="Create a new version from current data",
)
def regenerate(report_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession) -> ReportDetail:
    authz.ensure_permission(user, "reports:generate", request, resource="report")
    old = _get(db, report_id, user, request, write=True)
    inv = db.get(Investigation, old.investigation_id)
    assert inv is not None
    report = _create(db, inv, user, request, old.title)
    report.analyst_notes = old.analyst_notes
    db.commit()
    db.refresh(report)
    return _detail(db, report)


@router.post("/{report_id}/submit", response_model=ReportDetail, summary="Submit a draft for review")
def submit(report_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession) -> ReportDetail:
    report = _get(db, report_id, user, request, write=True)
    if report.status not in (ReportStatus.DRAFT, ReportStatus.CHANGES_REQUESTED):
        raise ValidationFailed(f"Report is {report.status}; only drafts can be submitted")
    report.status = ReportStatus.IN_REVIEW
    report.submitted_at = datetime.now(UTC)
    audit.record(db, action="report.submit", actor=user, resource_type="report", resource_id=report.id, request=request)
    db.commit()
    db.refresh(report)
    return _detail(db, report)


def _decide(report_id: uuid.UUID, body: ReviewDecision, request: Request, user, db, approve: bool) -> ReportDetail:  # type: ignore[no-untyped-def]
    report = _get(db, report_id, user, request)
    authz.ensure_permission(user, "reports:review", request, resource="report")
    if report.status != ReportStatus.IN_REVIEW:
        raise ValidationFailed(f"Report is {report.status}; only reports in review can be decided")
    if get_settings().report_review_requires_different_user and report.generated_by_id == user.id:
        raise PermissionDenied("A report must be reviewed by someone other than the person who generated it")
    if not approve and not body.comment:
        raise ValidationFailed("Explain the changes you are requesting")
    report.status = ReportStatus.APPROVED if approve else ReportStatus.CHANGES_REQUESTED
    report.reviewed_by_id = user.id
    report.reviewed_at = datetime.now(UTC)
    report.review_comment = body.comment
    audit.record(
        db,
        action="report.approve" if approve else "report.request_changes",
        actor=user,
        resource_type="report",
        resource_id=report.id,
        request=request,
        details={"comment": body.comment},
    )
    db.commit()
    db.refresh(report)
    return _detail(db, report)


@router.post("/{report_id}/approve", response_model=ReportDetail, summary="Approve a report in review")
def approve(
    report_id: uuid.UUID, body: ReviewDecision, request: Request, user: CurrentUser, db: DbSession
) -> ReportDetail:
    return _decide(report_id, body, request, user, db, True)


@router.post("/{report_id}/request-changes", response_model=ReportDetail, summary="Send a report back with comments")
def request_changes(
    report_id: uuid.UUID, body: ReviewDecision, request: Request, user: CurrentUser, db: DbSession
) -> ReportDetail:
    return _decide(report_id, body, request, user, db, False)


@router.get("/{report_id}/pdf", summary="Export the report as PDF", response_class=Response)
def export_pdf(report_id: uuid.UUID, request: Request, user: CurrentUser, db: DbSession) -> Response:
    report = _get(db, report_id, user, request)
    data = pdf.render(report)
    audit.record(
        db,
        action="report.export_pdf",
        actor=user,
        resource_type="report",
        resource_id=report.id,
        request=request,
        details={"status": report.status, "bytes": len(data)},
    )
    db.commit()
    inv = db.get(Investigation, report.investigation_id)
    filename = f"{inv.reference if inv else 'report'}-v{report.version}-{report.status}.pdf"
    return Response(
        data, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )
