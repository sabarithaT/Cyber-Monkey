"""FastAPI dependencies for authentication and permission checks."""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime
from typing import Annotated

from fastapi import Depends, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.db import get_db
from app.core.errors import NotAuthenticated
from app.core.security import InvalidToken, TokenClaims, decode_access_token
from app.models import RevokedToken, User
from app.services import authz

_bearer = HTTPBearer(auto_error=False, description="JWT access token from POST /api/v1/auth/login")

# Browsers authenticate with an HttpOnly cookie. Because cookies are sent automatically,
# state-changing cookie-authenticated requests must also carry this header; a cross-site
# page cannot add it without passing the CORS preflight, which only allows our origins.
CSRF_HEADER = "x-cm-client"
_SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}

DbSession = Annotated[Session, Depends(get_db)]


def _extract_token(request: Request, credentials: HTTPAuthorizationCredentials | None) -> str:
    if credentials and credentials.scheme.lower() == "bearer" and credentials.credentials:
        return credentials.credentials
    cookie = request.cookies.get(get_settings().cookie_name)
    if cookie:
        if request.method not in _SAFE_METHODS and request.headers.get(CSRF_HEADER) != "web":
            raise NotAuthenticated("Missing anti-CSRF header for cookie-authenticated request")
        return cookie
    raise NotAuthenticated("Authentication required")


def get_current_user(
    request: Request,
    db: DbSession,
    credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(_bearer)],
) -> User:
    token = _extract_token(request, credentials)
    try:
        claims = decode_access_token(token)
    except InvalidToken as exc:
        raise NotAuthenticated("Invalid or expired token") from exc
    if db.get(RevokedToken, claims.jti) is not None:
        raise NotAuthenticated("Token has been revoked")
    user = db.get(User, claims.user_id)
    if user is None or not user.is_active or user.token_version != claims.token_version:
        raise NotAuthenticated("Invalid or expired token")
    if user.locked_until and user.locked_until > datetime.now(UTC):
        raise NotAuthenticated("Account is temporarily locked")
    request.state.claims = claims
    request.state.user = user
    return user


CurrentUser = Annotated[User, Depends(get_current_user)]


def current_claims(request: Request) -> TokenClaims:
    return request.state.claims


def require(*codes: str) -> Callable[..., User]:
    """Dependency requiring every listed permission code."""

    def _dependency(request: Request, user: CurrentUser) -> User:
        for code in codes:
            authz.ensure_permission(user, code, request)
        return user

    _dependency.__name__ = "require_" + "_".join(c.replace(":", "_") for c in codes)
    return _dependency
