"""Evidence records and their custody history.

Files live in controlled storage (``settings.storage_dir``) under content-addressed
names; the database keeps the metadata, hashes and the provenance trail. Original
evidence is never modified: analysis reads it and writes derived records instead."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    String,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.constants import EvidenceKind
from app.core.db import Base
from app.models._types import enum_check, uuid_pk
from app.models.identity import User


class Evidence(Base):
    __tablename__ = "evidence"
    __table_args__ = (
        enum_check("kind", EvidenceKind),
        Index("ix_evidence_investigation_created", "investigation_id", "created_at"),
    )

    id: Mapped[uuid.UUID] = uuid_pk()
    investigation_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("investigations.id", ondelete="CASCADE"), nullable=False
    )
    kind: Mapped[str] = mapped_column(String(32), nullable=False)
    original_filename: Mapped[str] = mapped_column(String(255), nullable=False)
    stored_path: Mapped[str] = mapped_column(String(512), nullable=False)
    size_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False)
    sha256: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    sha1: Mapped[str] = mapped_column(String(40), nullable=False)
    md5: Mapped[str] = mapped_column(String(32), nullable=False)
    detected_type: Mapped[str] = mapped_column(String(128), nullable=False, default="unknown")
    source_description: Mapped[str] = mapped_column(Text, nullable=False, default="")
    acquired_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    uploaded_by_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    # True for evidence supplied from outside the platform. Derived records (tool output
    # captured by Cyber Monkey) set this to False and point at their parent.
    is_original: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    parent_evidence_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("evidence.id", ondelete="SET NULL"), nullable=True
    )
    produced_by_run_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("tool_runs.id", ondelete="SET NULL", use_alter=True), nullable=True
    )
    notes: Mapped[str] = mapped_column(Text, nullable=False, default="")
    metadata_json: Mapped[dict[str, Any]] = mapped_column("metadata", JSONB, nullable=False, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    uploaded_by: Mapped[User | None] = relationship(lazy="joined")


class EvidenceEvent(Base):
    """Append-only custody/provenance trail for one evidence item."""

    __tablename__ = "evidence_events"
    __table_args__ = (Index("ix_evidence_events_evidence_created", "evidence_id", "created_at"),)

    id: Mapped[uuid.UUID] = uuid_pk()
    evidence_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("evidence.id", ondelete="CASCADE"), nullable=False)
    action: Mapped[str] = mapped_column(String(32), nullable=False)
    actor_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    run_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("tool_runs.id", ondelete="SET NULL", use_alter=True), nullable=True
    )
    details: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    actor: Mapped[User | None] = relationship(lazy="joined")
