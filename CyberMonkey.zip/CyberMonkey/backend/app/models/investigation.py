"""Investigations (the case container shared by every workspace), membership,
authorized assessment scope and analyst notes."""

from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.constants import InvestigationStatus, Workspace
from app.core.db import Base, TimestampMixin
from app.models._types import enum_check, uuid_pk
from app.models.identity import User


class Investigation(TimestampMixin, Base):
    __tablename__ = "investigations"
    __table_args__ = (
        enum_check("status", InvestigationStatus),
        enum_check("primary_workspace", Workspace),
        Index("ix_investigations_owner_created", "owner_id", "created_at"),
    )

    id: Mapped[uuid.UUID] = uuid_pk()
    reference: Mapped[str] = mapped_column(String(32), unique=True, nullable=False)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False, default="")
    primary_workspace: Mapped[str] = mapped_column(String(16), nullable=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default=InvestigationStatus.OPEN)
    owner_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    # Demo investigations are created by the seed command from bundled sample files and
    # are labelled as demo data everywhere they are displayed.
    is_demo: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    owner: Mapped[User] = relationship(lazy="joined")
    members: Mapped[list[InvestigationMember]] = relationship(
        back_populates="investigation", lazy="selectin", cascade="all, delete-orphan"
    )
    scope_targets: Mapped[list[ScopeTarget]] = relationship(
        back_populates="investigation", lazy="selectin", cascade="all, delete-orphan"
    )


class InvestigationMember(Base):
    __tablename__ = "investigation_members"
    __table_args__ = (CheckConstraint("access_level IN ('viewer', 'contributor')", name="access_level_valid"),)

    investigation_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("investigations.id", ondelete="CASCADE"), primary_key=True
    )
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    access_level: Mapped[str] = mapped_column(String(16), nullable=False, default="contributor")
    added_by_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    added_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    investigation: Mapped[Investigation] = relationship(back_populates="members")
    user: Mapped[User] = relationship(foreign_keys=[user_id], lazy="joined")


class ScopeTarget(Base):
    """A target the investigation is explicitly authorized to assess. Active tools
    (e.g. Nmap) refuse any target that is not covered by an active scope entry."""

    __tablename__ = "scope_targets"
    __table_args__ = (
        UniqueConstraint("investigation_id", "target_type", "value"),
        CheckConstraint("target_type IN ('ip', 'cidr', 'hostname')", name="target_type_valid"),
    )

    id: Mapped[uuid.UUID] = uuid_pk()
    investigation_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("investigations.id", ondelete="CASCADE"), nullable=False, index=True
    )
    target_type: Mapped[str] = mapped_column(String(16), nullable=False)  # ip | cidr | hostname
    value: Mapped[str] = mapped_column(String(255), nullable=False)
    authorization_reference: Mapped[str] = mapped_column(Text, nullable=False)
    authorized_by_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    valid_from: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    valid_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    notes: Mapped[str] = mapped_column(Text, nullable=False, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    investigation: Mapped[Investigation] = relationship(back_populates="scope_targets")
    authorized_by: Mapped[User] = relationship(lazy="joined")


class Note(TimestampMixin, Base):
    __tablename__ = "notes"
    __table_args__ = (Index("ix_notes_investigation_created", "investigation_id", "created_at"),)

    id: Mapped[uuid.UUID] = uuid_pk()
    investigation_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("investigations.id", ondelete="CASCADE"), nullable=False
    )
    finding_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("findings.id", ondelete="CASCADE"), nullable=True, index=True
    )
    author_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    body: Mapped[str] = mapped_column(Text, nullable=False)

    author: Mapped[User] = relationship(lazy="joined")
