"""ORM models. Importing this package registers every table on ``Base.metadata``."""

from app.models.evidence import Evidence, EvidenceEvent
from app.models.findings import (
    Finding,
    FindingIndicator,
    FindingReference,
    Indicator,
    RiskAssessment,
    ThreatIntelReference,
)
from app.models.identity import (
    Permission,
    RevokedToken,
    Role,
    User,
    UserPermission,
    UserRole,
)
from app.models.investigation import (
    Investigation,
    InvestigationMember,
    Note,
    ScopeTarget,
)
from app.models.observations import LogEvent, NetworkFlow
from app.models.platform import (
    AssistantConversation,
    AssistantMessage,
    AuditLog,
    IntegrationConfig,
    Report,
)
from app.models.runs import ToolRun

__all__ = [
    "AssistantConversation",
    "AssistantMessage",
    "AuditLog",
    "Evidence",
    "EvidenceEvent",
    "Finding",
    "FindingIndicator",
    "FindingReference",
    "Indicator",
    "IntegrationConfig",
    "Investigation",
    "InvestigationMember",
    "LogEvent",
    "NetworkFlow",
    "Note",
    "Permission",
    "Report",
    "RevokedToken",
    "RiskAssessment",
    "Role",
    "ScopeTarget",
    "ThreatIntelReference",
    "ToolRun",
    "User",
    "UserPermission",
    "UserRole",
]
