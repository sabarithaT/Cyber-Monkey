"""Tool executions ("workspace runs"). Every request to run a registered tool creates a
row here, whether it came from the AI assistant or from a workspace screen, so the
approval decision, arguments, outcome and timing are always recorded."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import Boolean, DateTime, ForeignKey, Index, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.constants import RunStatus, Workspace
from app.core.db import Base, TimestampMixin
from app.models._types import enum_check, uuid_pk
from app.models.identity import User


class ToolRun(TimestampMixin, Base):
    __tablename__ = "tool_runs"
    __table_args__ = (
        enum_check("status", RunStatus),
        enum_check("workspace", Workspace),
        Index("ix_tool_runs_investigation_created", "investigation_id", "created_at"),
        Index("ix_tool_runs_status", "status"),
    )

    id: Mapped[uuid.UUID] = uuid_pk()
    investigation_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("investigations.id", ondelete="CASCADE"), nullable=False
    )
    workspace: Mapped[str] = mapped_column(String(16), nullable=False)
    tool_name: Mapped[str] = mapped_column(String(64), nullable=False)
    arguments: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False, default=dict)
    status: Mapped[str] = mapped_column(String(24), nullable=False)
    origin: Mapped[str] = mapped_column(String(16), nullable=False, default="workspace")  # workspace | assistant
    requires_approval: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    requested_by_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    approved_by_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    approval_decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    approval_note: Mapped[str] = mapped_column(Text, nullable=False, default="")
    timeout_seconds: Mapped[int] = mapped_column(Integer, nullable=False)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    exit_code: Mapped[int | None] = mapped_column(Integer, nullable=True)
    error_message: Mapped[str] = mapped_column(Text, nullable=False, default="")
    # Structured, size-bounded summary of what the tool produced (counts, parsed hosts...).
    output_summary: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False, default=dict)
    # Full raw tool output is preserved as a derived evidence record.
    raw_output_evidence_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("evidence.id", ondelete="SET NULL"), nullable=True
    )
    execution_log: Mapped[list[dict[str, Any]]] = mapped_column(JSONB, nullable=False, default=list)
    # Set when the AI assistant requested the run, so the result can be explained in the
    # same conversation once the tool finishes.
    conversation_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("assistant_conversations.id", ondelete="SET NULL"), nullable=True, index=True
    )

    requested_by: Mapped[User] = relationship(foreign_keys=[requested_by_id], lazy="joined")
    approved_by: Mapped[User | None] = relationship(foreign_keys=[approved_by_id], lazy="joined")
