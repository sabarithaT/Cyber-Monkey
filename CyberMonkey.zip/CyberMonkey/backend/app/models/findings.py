"""Normalized findings, indicators of compromise, threat-intelligence references and
risk assessments — the data the Threat Intelligence Engine works on."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import (
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.constants import (
    Confidence,
    FindingOrigin,
    FindingStatus,
    IndicatorType,
    ReferenceValidation,
    Severity,
    ValidationStatus,
    Workspace,
)
from app.core.db import Base, TimestampMixin
from app.models._types import enum_check, uuid_pk


class Finding(TimestampMixin, Base):
    __tablename__ = "findings"
    __table_args__ = (
        enum_check("workspace", Workspace),
        enum_check("severity", Severity),
        enum_check("confidence", Confidence),
        enum_check("status", FindingStatus),
        enum_check("validation_status", ValidationStatus),
        enum_check("origin", FindingOrigin),
        # The fingerprint de-duplicates the same observation re-imported or re-scanned.
        UniqueConstraint("investigation_id", "fingerprint"),
        Index("ix_findings_investigation_severity", "investigation_id", "severity"),
        Index("ix_findings_workspace_created", "workspace", "created_at"),
    )

    id: Mapped[uuid.UUID] = uuid_pk()
    investigation_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("investigations.id", ondelete="CASCADE"), nullable=False
    )
    workspace: Mapped[str] = mapped_column(String(16), nullable=False)
    source_tool: Mapped[str] = mapped_column(String(64), nullable=False)
    run_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("tool_runs.id", ondelete="SET NULL"), nullable=True)
    origin: Mapped[str] = mapped_column(String(16), nullable=False, default=FindingOrigin.TOOL)
    rule_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    finding_type: Mapped[str] = mapped_column(String(64), nullable=False)
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False, default="")
    severity: Mapped[str] = mapped_column(String(16), nullable=False, default=Severity.INFO)
    confidence: Mapped[str] = mapped_column(String(16), nullable=False, default=Confidence.MEDIUM)
    affected_asset: Mapped[str] = mapped_column(String(255), nullable=False, default="")
    observed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default=FindingStatus.OPEN)
    validation_status: Mapped[str] = mapped_column(String(16), nullable=False, default=ValidationStatus.UNVERIFIED)
    fingerprint: Mapped[str] = mapped_column(String(64), nullable=False)
    # Tool-specific structured details (port/service, rule match, metadata...).
    details: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False, default=dict)
    # [{"evidence_id": ..., "locator": "line 42" | "packet 17" | "xpath", "excerpt": "..."}]
    evidence_refs: Mapped[list[dict[str, Any]]] = mapped_column(JSONB, nullable=False, default=list)
    # [{"text": ..., "source": "rule:<id>" | "cve:<id>" | "attack:<id>" | "analyst"}]
    remediation: Mapped[list[dict[str, Any]]] = mapped_column(JSONB, nullable=False, default=list)

    indicator_links: Mapped[list[FindingIndicator]] = relationship(
        back_populates="finding", lazy="selectin", cascade="all, delete-orphan"
    )
    reference_links: Mapped[list[FindingReference]] = relationship(
        back_populates="finding", lazy="selectin", cascade="all, delete-orphan"
    )


class Indicator(Base):
    __tablename__ = "indicators"
    __table_args__ = (
        enum_check("type", IndicatorType),
        UniqueConstraint("type", "value"),
    )

    id: Mapped[uuid.UUID] = uuid_pk()
    type: Mapped[str] = mapped_column(String(16), nullable=False)
    value: Mapped[str] = mapped_column(String(2048), nullable=False)
    first_seen: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    last_seen: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    # External reputation lookups, each keyed by source with the fetch time. Reputation is
    # informational; the platform never labels an indicator malicious on its own.
    reputation: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False, default=dict)


class FindingIndicator(Base):
    __tablename__ = "finding_indicators"

    finding_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("findings.id", ondelete="CASCADE"), primary_key=True)
    indicator_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("indicators.id", ondelete="CASCADE"), primary_key=True, index=True
    )
    relation: Mapped[str] = mapped_column(String(32), nullable=False, default="observed")
    context: Mapped[str] = mapped_column(Text, nullable=False, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    finding: Mapped[Finding] = relationship(back_populates="indicator_links")
    indicator: Mapped[Indicator] = relationship(lazy="joined")


class ThreatIntelReference(Base):
    """A CVE record or ATT&CK technique, cached locally with its source and fetch time."""

    __tablename__ = "threat_intel_references"
    __table_args__ = (UniqueConstraint("ref_type", "external_id"),)

    id: Mapped[uuid.UUID] = uuid_pk()
    ref_type: Mapped[str] = mapped_column(String(32), nullable=False)  # cve | attack_technique
    external_id: Mapped[str] = mapped_column(String(32), nullable=False)
    title: Mapped[str] = mapped_column(String(500), nullable=False, default="")
    description: Mapped[str] = mapped_column(Text, nullable=False, default="")
    cvss_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    cvss_vector: Mapped[str | None] = mapped_column(String(200), nullable=True)
    severity: Mapped[str | None] = mapped_column(String(16), nullable=True)
    url: Mapped[str] = mapped_column(String(500), nullable=False, default="")
    source: Mapped[str] = mapped_column(String(64), nullable=False)
    data: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False, default=dict)
    fetched_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)


class FindingReference(Base):
    __tablename__ = "finding_references"
    __table_args__ = (enum_check("validation_status", ReferenceValidation),)

    finding_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("findings.id", ondelete="CASCADE"), primary_key=True)
    reference_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("threat_intel_references.id", ondelete="CASCADE"), primary_key=True, index=True
    )
    # Why this reference was attached, e.g. "CVE identifier present in scanner output".
    match_basis: Mapped[str] = mapped_column(Text, nullable=False)
    validation_status: Mapped[str] = mapped_column(String(16), nullable=False, default=ReferenceValidation.CANDIDATE)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    finding: Mapped[Finding] = relationship(back_populates="reference_links")
    reference: Mapped[ThreatIntelReference] = relationship(lazy="joined")


class RiskAssessment(Base):
    """A computed risk score with every component that produced it (history is kept)."""

    __tablename__ = "risk_assessments"
    __table_args__ = (Index("ix_risk_assessments_investigation_computed", "investigation_id", "computed_at"),)

    id: Mapped[uuid.UUID] = uuid_pk()
    investigation_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("investigations.id", ondelete="CASCADE"), nullable=False
    )
    score: Mapped[float | None] = mapped_column(Float, nullable=True)
    lower_bound: Mapped[float] = mapped_column(Float, nullable=False)
    upper_bound: Mapped[float] = mapped_column(Float, nullable=False)
    coverage: Mapped[float] = mapped_column(Float, nullable=False)
    finding_count: Mapped[int] = mapped_column(Integer, nullable=False)
    weights: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False)
    components: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False)
    computed_by_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    computed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
