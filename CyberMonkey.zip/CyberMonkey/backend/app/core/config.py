"""Application configuration.

All settings come from environment variables (or a local ``.env`` file). Secrets are
held as ``SecretStr`` so they are never printed in logs or reprs. Nothing secret has a
usable default: a missing secret disables the integration that needs it.
"""

from __future__ import annotations

import secrets
from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_DIR = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(BACKEND_DIR / ".env", BACKEND_DIR.parent / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    app_name: str = "Cyber Monkey"
    environment: Literal["development", "test", "production"] = "development"

    # --- Database -------------------------------------------------------------------
    database_url: str = "postgresql+psycopg://cybermonkey:cybermonkey@localhost:5432/cybermonkey"
    db_echo: bool = False

    # --- Authentication -------------------------------------------------------------
    # In development a random secret is generated per process if none is configured,
    # which means tokens do not survive restarts. Production refuses to start without one.
    jwt_secret: SecretStr | None = None
    jwt_algorithm: str = "HS256"
    access_token_ttl_minutes: int = 60
    cookie_name: str = "cm_session"
    cookie_secure: bool = False
    login_max_failures: int = 5
    login_lockout_minutes: int = 15
    login_rate_limit_per_minute: int = 10
    report_review_requires_different_user: bool = True

    # --- HTTP -----------------------------------------------------------------------
    cors_origins: list[str] = Field(default_factory=lambda: ["http://localhost:5173"])

    # --- Storage --------------------------------------------------------------------
    storage_dir: Path = BACKEND_DIR.parent / "storage"
    max_upload_mb_log: int = 50
    max_upload_mb_pcap: int = 200
    max_upload_mb_sample: int = 50
    max_upload_mb_evidence: int = 2048
    max_upload_mb_report: int = 50

    # --- AI providers ---------------------------------------------------------------
    ai_provider: Literal["none", "gemini", "ollama"] = "none"
    gemini_api_key: SecretStr | None = None
    gemini_model: str = "gemini-2.5-flash"
    gemini_base_url: str = "https://generativelanguage.googleapis.com/v1beta"
    ollama_base_url: str = "http://localhost:11434"
    ollama_model: str = "llama3.1:8b"
    ai_timeout_seconds: float = 60.0
    assistant_rate_limit_per_minute: int = 20

    # --- Tool execution ---------------------------------------------------------------
    # "thread": runs execute on a background worker pool (default). "inline": runs execute
    # synchronously in the request (used by the test suite for determinism).
    tool_execution_mode: Literal["thread", "inline"] = "thread"

    # --- External intelligence / OSINT ----------------------------------------------
    outbound_network_enabled: bool = True
    nvd_api_key: SecretStr | None = None
    nvd_base_url: str = "https://services.nvd.nist.gov/rest/json/cves/2.0"
    http_timeout_seconds: float = 20.0
    attack_dataset_path: Path = BACKEND_DIR / "data" / "enterprise-attack.json"

    # --- Bootstrap ------------------------------------------------------------------
    bootstrap_admin_email: str = ""
    bootstrap_admin_password: SecretStr | None = None

    @field_validator("cors_origins", mode="before")
    @classmethod
    def _split_origins(cls, value: object) -> object:
        if isinstance(value, str):
            return [v.strip() for v in value.split(",") if v.strip()]
        return value

    def resolved_jwt_secret(self) -> str:
        if self.jwt_secret is not None and self.jwt_secret.get_secret_value():
            return self.jwt_secret.get_secret_value()
        if self.environment == "production":
            raise RuntimeError("JWT_SECRET must be set in production")
        return _ephemeral_secret()

    def max_upload_bytes(self, kind: str) -> int:
        mb = {
            "log": self.max_upload_mb_log,
            "pcap": self.max_upload_mb_pcap,
            "malware_sample": self.max_upload_mb_sample,
            "sandbox_report": self.max_upload_mb_report,
            "forensic_report": self.max_upload_mb_report,
            "ids_alerts": self.max_upload_mb_log,
        }.get(kind, self.max_upload_mb_evidence)
        return mb * 1024 * 1024


@lru_cache
def _ephemeral_secret() -> str:
    return secrets.token_urlsafe(48)


@lru_cache
def get_settings() -> Settings:
    return Settings()
