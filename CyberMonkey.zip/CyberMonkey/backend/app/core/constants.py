"""Domain vocabulary shared across the backend: workspaces, permissions, default roles,
severities and statuses. Authorization checks always use permission codes, never role names."""

from __future__ import annotations

from enum import StrEnum


class Workspace(StrEnum):
    SOC = "soc"
    PENTEST = "pentest"
    OSINT = "osint"
    MALWARE = "malware"
    FORENSICS = "forensics"
    NETWORK = "network"


WORKSPACE_LABELS: dict[Workspace, str] = {
    Workspace.SOC: "SOC Monitoring",
    Workspace.PENTEST: "Penetration Testing",
    Workspace.OSINT: "OSINT Investigation",
    Workspace.MALWARE: "Malware Analysis",
    Workspace.FORENSICS: "Digital Forensics",
    Workspace.NETWORK: "Network Monitoring",
}

WORKSPACE_DESCRIPTIONS: dict[Workspace, str] = {
    Workspace.SOC: "Import authorized security logs, triage alerts and track incidents.",
    Workspace.PENTEST: "Run scoped, authorized reconnaissance against registered targets.",
    Workspace.OSINT: "Collect public-source information about domains and usernames.",
    Workspace.MALWARE: "Static analysis of suspicious files and import of sandbox reports.",
    Workspace.FORENSICS: "Register evidence, preserve provenance and import forensic tool output.",
    Workspace.NETWORK: "Analyze packet captures, flows and IDS alerts.",
}


class Severity(StrEnum):
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


SEVERITY_ORDER = {s: i for i, s in enumerate(Severity)}


class Confidence(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class FindingStatus(StrEnum):
    OPEN = "open"
    INVESTIGATING = "investigating"
    RESOLVED = "resolved"
    FALSE_POSITIVE = "false_positive"


class ValidationStatus(StrEnum):
    """Analyst validation of a finding. Tool output starts as ``unverified``."""

    UNVERIFIED = "unverified"
    SUPPORTED = "supported"
    CONFIRMED = "confirmed"
    REJECTED = "rejected"


class FindingOrigin(StrEnum):
    TOOL = "tool"  # parsed directly from a tool's output
    RULE = "rule"  # produced by a documented detection rule over tool output
    IMPORT = "import"  # imported from an external system's report (sandbox, IDS, SIEM)
    ANALYST = "analyst"  # entered by a human


class ReferenceValidation(StrEnum):
    CANDIDATE = "candidate"  # plausible match that needs analyst confirmation
    SUPPORTED = "supported"  # evidence directly names the reference
    CONFIRMED = "confirmed"  # analyst confirmed
    REJECTED = "rejected"


class RunStatus(StrEnum):
    PENDING_APPROVAL = "pending_approval"
    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    TIMED_OUT = "timed_out"
    REJECTED = "rejected"
    UNAVAILABLE = "unavailable"  # the integration is not installed/configured


TERMINAL_RUN_STATUSES = {
    RunStatus.SUCCEEDED,
    RunStatus.FAILED,
    RunStatus.TIMED_OUT,
    RunStatus.REJECTED,
    RunStatus.UNAVAILABLE,
}


class InvestigationStatus(StrEnum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    CLOSED = "closed"


class ReportStatus(StrEnum):
    DRAFT = "draft"
    IN_REVIEW = "in_review"
    CHANGES_REQUESTED = "changes_requested"
    APPROVED = "approved"


class EvidenceKind(StrEnum):
    LOG = "log"
    PCAP = "pcap"
    IDS_ALERTS = "ids_alerts"
    MALWARE_SAMPLE = "malware_sample"
    SANDBOX_REPORT = "sandbox_report"
    DISK_IMAGE = "disk_image"
    MEMORY_IMAGE = "memory_image"
    FORENSIC_REPORT = "forensic_report"
    TOOL_OUTPUT = "tool_output"
    OSINT_RECORD = "osint_record"
    SCAN_REPORT = "scan_report"
    OTHER = "other"


class IndicatorType(StrEnum):
    IPV4 = "ipv4"
    IPV6 = "ipv6"
    DOMAIN = "domain"
    URL = "url"
    EMAIL = "email"
    MD5 = "md5"
    SHA1 = "sha1"
    SHA256 = "sha256"


# --------------------------------------------------------------------------------------
# Permissions
# --------------------------------------------------------------------------------------

WORKSPACE_ACTIONS = {
    "view": "View the {label} workspace and its data",
    "operate": "Create items, import data and add notes in {label}",
    "execute": "Request and run tools in {label}",
}

PLATFORM_PERMISSIONS: dict[str, str] = {
    "dashboard:view": "View the overview dashboard",
    "assistant:use": "Use the AI assistant",
    "investigations:view": "View investigations the user owns or is a member of",
    "investigations:create": "Create investigations",
    "investigations:manage_all": "View and manage every investigation regardless of ownership",
    "findings:triage": "Change finding status and validation status",
    "evidence:upload": "Upload evidence files",
    "evidence:download": "Download stored evidence files",
    "threat_intel:view": "View indicators, CVE and ATT&CK references and risk scores",
    "threat_intel:enrich": "Run CVE enrichment, ATT&CK mapping and external reputation lookups",
    "reports:view": "View reports",
    "reports:generate": "Generate and regenerate reports",
    "reports:review": "Approve or request changes on reports",
    "audit:view": "View audit logs",
    "users:manage": "Create users, activate/deactivate and assign roles",
    "roles:manage": "Create roles and change role permissions",
    "integrations:manage": "Change integration configuration",
}


def workspace_permission(workspace: Workspace | str, action: str) -> str:
    return f"{Workspace(workspace).value}:{action}"


def all_permissions() -> dict[str, str]:
    perms: dict[str, str] = {}
    for ws in Workspace:
        for action, template in WORKSPACE_ACTIONS.items():
            perms[workspace_permission(ws, action)] = template.format(label=WORKSPACE_LABELS[ws])
    perms.update(PLATFORM_PERMISSIONS)
    return perms


_ANALYST_BASE = [
    "dashboard:view",
    "assistant:use",
    "investigations:view",
    "investigations:create",
    "findings:triage",
    "evidence:upload",
    "evidence:download",
    "threat_intel:view",
    "threat_intel:enrich",
    "reports:view",
    "reports:generate",
]


def _ws(workspace: Workspace, *actions: str) -> list[str]:
    return [workspace_permission(workspace, a) for a in actions]


FULL = ("view", "operate", "execute")

DEFAULT_ROLES: dict[str, dict[str, object]] = {
    "administrator": {
        "name": "Administrator",
        "description": "Full platform administration, including users, roles, integrations and report review.",
        "permissions": list(all_permissions()),
    },
    "soc_analyst": {
        "name": "SOC Analyst",
        "description": "Monitors security events, triages alerts and handles incidents.",
        "permissions": _ANALYST_BASE + _ws(Workspace.SOC, *FULL) + _ws(Workspace.NETWORK, "view"),
    },
    "penetration_tester": {
        "name": "Penetration Tester",
        "description": "Runs authorized, scoped security assessments.",
        "permissions": _ANALYST_BASE + _ws(Workspace.PENTEST, *FULL),
    },
    "osint_investigator": {
        "name": "OSINT Investigator",
        "description": "Collects and correlates public-source intelligence.",
        "permissions": _ANALYST_BASE + _ws(Workspace.OSINT, *FULL),
    },
    "malware_analyst": {
        "name": "Malware Analyst",
        "description": "Examines suspicious files using static analysis and sandbox reports.",
        "permissions": _ANALYST_BASE + _ws(Workspace.MALWARE, *FULL),
    },
    "forensics_analyst": {
        "name": "Digital Forensics Analyst",
        "description": "Manages forensic cases, evidence provenance and artifact analysis.",
        "permissions": _ANALYST_BASE + _ws(Workspace.FORENSICS, *FULL),
    },
    "network_analyst": {
        "name": "Network Analyst",
        "description": "Analyzes traffic captures, flows and IDS alerts.",
        "permissions": _ANALYST_BASE + _ws(Workspace.NETWORK, *FULL) + _ws(Workspace.SOC, "view"),
    },
}
