"""Tool registry primitives.

A tool is the only way the platform (or the AI orchestrator) can cause an effect: run a
scanner, parse evidence, query intelligence. Each tool declares its purpose, a strict
argument schema, the permissions it needs, whether a human must confirm it, its timeout,
its output format, the integrations it depends on, and a scope validator. Nothing else
is executable: the LLM can only *propose* a registered tool with arguments, which are
then validated here exactly as if a person had submitted them."""

from __future__ import annotations

import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict
from sqlalchemy.orm import Session

from app.core.constants import Confidence, FindingOrigin, Severity, Workspace
from app.models import Investigation, ToolRun, User


class ToolArgs(BaseModel):
    """Base for tool argument schemas: unknown fields are rejected."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class ToolTimeout(Exception):
    pass


class ToolUnavailable(Exception):
    """Raised when an integration disappears between request and execution."""


class ScopeError(Exception):
    """Arguments are well-formed but fall outside what this investigation authorizes."""


@dataclass
class IndicatorRef:
    type: str
    value: str
    relation: str = "observed"
    context: str = ""


@dataclass
class ReferenceRef:
    ref_type: str  # cve | attack_technique
    external_id: str
    match_basis: str
    validation: str = "supported"


@dataclass
class NormalizedFinding:
    """Common finding structure every tool produces (see docs/ARCHITECTURE.md)."""

    finding_type: str
    title: str
    description: str
    severity: Severity = Severity.INFO
    confidence: Confidence = Confidence.MEDIUM
    affected_asset: str = ""
    observed_at: datetime | None = None
    origin: FindingOrigin = FindingOrigin.TOOL
    rule_id: str | None = None
    details: dict[str, Any] = field(default_factory=dict)
    evidence_refs: list[dict[str, Any]] = field(default_factory=list)
    remediation: list[dict[str, str]] = field(default_factory=list)
    indicators: list[IndicatorRef] = field(default_factory=list)
    references: list[ReferenceRef] = field(default_factory=list)
    # Values that identify "the same observation" for de-duplication.
    fingerprint_parts: tuple[str, ...] = ()


@dataclass
class ToolResult:
    summary: dict[str, Any]
    findings: list[NormalizedFinding] = field(default_factory=list)
    raw_output: bytes | None = None
    raw_output_name: str = "output.txt"
    raw_output_parent_id: uuid.UUID | None = None
    exit_code: int | None = None
    notes: list[str] = field(default_factory=list)


@dataclass
class ToolContext:
    db: Session
    run: ToolRun
    investigation: Investigation
    user: User
    args: Any
    deadline: float
    log_lines: list[dict[str, Any]] = field(default_factory=list)

    def log(self, message: str) -> None:
        self.log_lines.append({"at": time.time(), "message": message[:500]})

    def remaining(self) -> float:
        return self.deadline - time.monotonic()

    def check_deadline(self) -> None:
        if time.monotonic() > self.deadline:
            raise ToolTimeout(f"Exceeded the {self.run.timeout_seconds}s time limit")


ScopeValidator = Callable[[Session, Investigation, Any], None]


@dataclass(frozen=True)
class ToolSpec:
    name: str
    workspace: Workspace
    title: str
    purpose: str
    args_model: type[ToolArgs]
    executor: Callable[[ToolContext], ToolResult]
    timeout_seconds: int
    output_format: str
    requires_approval: bool | Callable[[Any], bool] = False
    extra_permissions: tuple[str, ...] = ()
    # Every listed integration must be available...
    integrations_all: tuple[str, ...] = ()
    # ...and at least one of these, when given (any one alternative is enough).
    integrations_any: tuple[str, ...] = ()
    scope_validator: ScopeValidator | None = None
    side_effects: str = "none"  # none | reads_evidence | network_active | network_passive_lookup
    example_requests: tuple[str, ...] = ()

    @property
    def permissions(self) -> tuple[str, ...]:
        return (f"{self.workspace.value}:execute", *self.extra_permissions)

    def approval_needed(self, args: Any) -> bool:
        if callable(self.requires_approval):
            return bool(self.requires_approval(args))
        return bool(self.requires_approval)

    def json_schema(self) -> dict[str, Any]:
        return self.args_model.model_json_schema()


_REGISTRY: dict[str, ToolSpec] = {}


def register(spec: ToolSpec) -> ToolSpec:
    if spec.name in _REGISTRY:
        raise ValueError(f"Tool {spec.name} registered twice")
    _REGISTRY[spec.name] = spec
    return spec


def get_tool(name: str) -> ToolSpec | None:
    _load()
    return _REGISTRY.get(name)


def all_tools() -> list[ToolSpec]:
    _load()
    return sorted(_REGISTRY.values(), key=lambda s: (s.workspace.value, s.name))


_loaded = False


def _load() -> None:
    global _loaded
    if not _loaded:
        _loaded = True
        import app.tools.catalog  # noqa: F401  (registers every tool)
