"""Structured findings import — one tool per workspace.

Brings results produced by external, already-authorized tooling (e.g. a lab scanner,
an IDS, a sandbox or a forensic suite run by the team) into Cyber Monkey so they flow
through the same normalization, correlation and reporting pipeline. The input is a JSON
document in the documented ``cybermonkey-findings/v1`` format (docs/FINDINGS_IMPORT.md).

Imported findings keep their origin (``import``), the name of the tool that produced
them, and a locator pointing at the exact entry in the uploaded file. Indicators that do
not validate are dropped and counted rather than stored."""

from __future__ import annotations

import json
import uuid
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from app.core.config import get_settings
from app.core.constants import Confidence, EvidenceKind, FindingOrigin, Severity, Workspace
from app.core.errors import ValidationFailed
from app.services import attack
from app.services import evidence as evidence_svc
from app.services import indicators as ioc
from app.services.threat_intel import TECHNIQUE_RE, normalize_cve
from app.tools.base import (
    IndicatorRef,
    NormalizedFinding,
    ReferenceRef,
    ToolArgs,
    ToolContext,
    ToolResult,
    ToolSpec,
    register,
)
from app.tools.common import evidence_in_investigation

FORMAT_ID = "cybermonkey-findings/v1"
MAX_FINDINGS = 5000

WORKSPACE_KIND: dict[Workspace, EvidenceKind] = {
    Workspace.SOC: EvidenceKind.LOG,
    Workspace.PENTEST: EvidenceKind.SCAN_REPORT,
    Workspace.OSINT: EvidenceKind.OSINT_RECORD,
    Workspace.MALWARE: EvidenceKind.SANDBOX_REPORT,
    Workspace.FORENSICS: EvidenceKind.FORENSIC_REPORT,
    Workspace.NETWORK: EvidenceKind.IDS_ALERTS,
}


class ImportArgs(ToolArgs):
    evidence_id: uuid.UUID


class _Indicator(BaseModel):
    model_config = ConfigDict(extra="ignore")
    type: str
    value: str
    context: str = ""


class _Entry(BaseModel):
    model_config = ConfigDict(extra="ignore")
    type: str = Field(min_length=1, max_length=64)
    title: str = Field(min_length=1, max_length=300)
    description: str = Field(default="", max_length=20_000)
    severity: Severity = Severity.INFO
    confidence: Confidence = Confidence.MEDIUM
    asset: str = Field(default="", max_length=255)
    observed_at: str | None = None
    indicators: list[_Indicator] = Field(default_factory=list, max_length=200)
    cve: list[str] = Field(default_factory=list, max_length=50)
    attack: list[str] = Field(default_factory=list, max_length=50)
    remediation: list[str] = Field(default_factory=list, max_length=20)
    details: dict[str, Any] = Field(default_factory=dict)
    id: str | None = Field(default=None, max_length=200)


class _Document(BaseModel):
    model_config = ConfigDict(extra="ignore")
    format: str
    source_tool: str = Field(min_length=1, max_length=120)
    generated_at: str | None = None
    findings: list[dict[str, Any]]


def _parse_time(value: str | None):  # type: ignore[no-untyped-def]
    if not value:
        return None
    from datetime import UTC, datetime

    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)


def _import(ctx: ToolContext) -> ToolResult:
    workspace = Workspace(ctx.run.workspace)
    evidence = evidence_in_investigation(ctx.db, ctx.investigation, ctx.args.evidence_id, {WORKSPACE_KIND[workspace]})
    raw = evidence_svc.read_json(evidence, get_settings().max_upload_bytes(evidence.kind))
    if not isinstance(raw, dict):
        raise ValidationFailed(f"Expected a JSON object in {FORMAT_ID} format")
    try:
        document = _Document.model_validate(raw)
    except ValidationError as exc:
        raise ValidationFailed(f"Not a valid {FORMAT_ID} document: {exc.errors()[0].get('msg')}") from exc
    if document.format != FORMAT_ID:
        raise ValidationFailed(f"Unsupported format '{document.format}'; expected '{FORMAT_ID}'")
    if len(document.findings) > MAX_FINDINGS:
        raise ValidationFailed(f"Too many findings in one file (limit {MAX_FINDINGS})")

    source_tool = document.source_tool.strip()
    findings: list[NormalizedFinding] = []
    rejected_entries: list[dict[str, Any]] = []
    dropped = {"indicators": 0, "cve": 0, "attack": 0}
    for index, item in enumerate(document.findings):
        ctx.check_deadline()
        locator = f"findings[{index}]"
        try:
            entry = _Entry.model_validate(item)
        except ValidationError as exc:
            if len(rejected_entries) < 50:
                rejected_entries.append({"locator": locator, "error": exc.errors()[0].get("msg", "invalid")})
            continue
        indicators = []
        for ind in entry.indicators:
            normalized = ioc.normalize(ind.type.lower(), ind.value)
            if normalized is None:
                dropped["indicators"] += 1
                continue
            indicators.append(IndicatorRef(normalized.type.value, normalized.value, "reported", ind.context[:500]))
        references = []
        for cve in entry.cve:
            cve_id = normalize_cve(cve)
            if cve_id is None:
                dropped["cve"] += 1
                continue
            references.append(ReferenceRef("cve", cve_id, f"Named by {source_tool} in the imported report ({locator})"))
        for technique in entry.attack:
            tid = technique.strip().upper()
            # Unknown IDs are dropped, never stored: the catalogue is the source of truth.
            if not TECHNIQUE_RE.match(tid) or attack.lookup(tid) is None:
                dropped["attack"] += 1
                continue
            references.append(
                ReferenceRef("attack_technique", tid, f"Mapped by {source_tool} in the imported report ({locator})")
            )
        excerpt = json.dumps(item, default=str)[:400]
        findings.append(
            NormalizedFinding(
                finding_type=entry.type,
                title=entry.title,
                description=entry.description,
                severity=entry.severity,
                confidence=entry.confidence,
                affected_asset=entry.asset,
                observed_at=_parse_time(entry.observed_at),
                origin=FindingOrigin.IMPORT,
                details={**entry.details, "reported_by": source_tool, "source_entry_id": entry.id},
                evidence_refs=[{"evidence_id": str(evidence.id), "locator": locator, "excerpt": excerpt}],
                remediation=[{"text": text, "source": f"import:{source_tool}"} for text in entry.remediation],
                indicators=indicators,
                references=references,
                fingerprint_parts=(source_tool, entry.id or "", entry.type, entry.asset, entry.title),
            )
        )
    evidence_svc.add_event(
        ctx.db,
        evidence,
        "analyzed",
        ctx.user,
        run_id=ctx.run.id,
        details={"tool": ctx.run.tool_name, "imported": len(findings), "rejected": len(rejected_entries)},
    )
    ctx.log(f"Imported {len(findings)} finding(s) reported by {source_tool}")
    notes = []
    if rejected_entries:
        notes.append(f"{len(rejected_entries)} entr(y/ies) failed validation and were not imported")
    if any(dropped.values()):
        notes.append(f"Invalid values dropped: {dropped}")
    return ToolResult(
        summary={
            "evidence_id": str(evidence.id),
            "source_tool": source_tool,
            "generated_at": document.generated_at,
            "entries": len(document.findings),
            "imported": len(findings),
            "rejected_entries": rejected_entries,
            "dropped_values": dropped,
        },
        findings=findings,
        notes=notes,
    )


def _scope(workspace: Workspace):  # type: ignore[no-untyped-def]
    def validator(db, investigation, args):  # type: ignore[no-untyped-def]
        evidence_in_investigation(db, investigation, args.evidence_id, {WORKSPACE_KIND[workspace]})

    return validator


_LABELS = {
    Workspace.SOC: "SIEM / log-analysis results",
    Workspace.PENTEST: "scanner results from an authorized assessment",
    Workspace.OSINT: "OSINT collection results",
    Workspace.MALWARE: "sandbox or analysis-tool results",
    Workspace.FORENSICS: "forensic-suite results",
    Workspace.NETWORK: "IDS or traffic-analysis results",
}

for _ws in Workspace:
    register(
        ToolSpec(
            name=f"{_ws.value}_findings_import",
            workspace=_ws,
            title="Import structured findings",
            purpose=(
                f"Import {_LABELS[_ws]} exported in the {FORMAT_ID} JSON format "
                f"(uploaded as '{WORKSPACE_KIND[_ws].value}' evidence) into the normalized findings pipeline."
            ),
            args_model=ImportArgs,
            executor=_import,
            timeout_seconds=300,
            output_format=f"Normalized findings with indicators and CVE/ATT&CK references ({FORMAT_ID})",
            scope_validator=_scope(_ws),
            side_effects="reads_evidence",
            example_requests=(f"Import the {_LABELS[_ws]} file I uploaded",),
        )
    )
