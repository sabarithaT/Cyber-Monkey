"""Helpers shared by tool implementations."""

from __future__ import annotations

import uuid

from sqlalchemy.orm import Session

from app.core.constants import EvidenceKind
from app.models import Evidence, Investigation
from app.tools.base import ScopeError


def evidence_in_investigation(
    db: Session, investigation: Investigation, evidence_id: uuid.UUID, kinds: set[EvidenceKind] | None
) -> Evidence:
    """Scope rule for evidence-reading tools: the evidence must belong to this
    investigation, have a stored file and be of an accepted kind."""
    evidence = db.get(Evidence, evidence_id)
    if evidence is None or evidence.investigation_id != investigation.id:
        raise ScopeError("The evidence item does not belong to this investigation")
    if not evidence.stored_path:
        raise ScopeError("The evidence item has no stored file to analyze")
    if kinds is not None and EvidenceKind(evidence.kind) not in kinds:
        accepted = ", ".join(sorted(k.value for k in kinds))
        raise ScopeError(f"This tool accepts {accepted} evidence; the selected item is '{evidence.kind}'")
    return evidence
