"""Evidence profile: re-verify integrity and describe a stored file without executing it.

Computes SHA-256 again and compares it with the value recorded at upload, and reports
size, detected content type and byte entropy. Entropy is reported as an observation
only: high entropy is consistent with compressed or encrypted content and is not, on its
own, evidence of anything malicious."""

from __future__ import annotations

import hashlib
import json
import math
import uuid
from collections import Counter

from app.core.constants import Confidence, EvidenceKind, FindingOrigin, IndicatorType, Severity, Workspace
from app.services import evidence as evidence_svc
from app.tools.base import IndicatorRef, NormalizedFinding, ToolArgs, ToolContext, ToolResult, ToolSpec, register
from app.tools.common import evidence_in_investigation

CHUNK = 1024 * 1024


class EvidenceProfileArgs(ToolArgs):
    evidence_id: uuid.UUID


def _profile(ctx: ToolContext) -> ToolResult:
    evidence = evidence_in_investigation(
        ctx.db, ctx.investigation, ctx.args.evidence_id, _accepted_kinds(ctx.run.workspace)
    )
    counts: Counter[int] = Counter()
    sha256 = hashlib.sha256()
    total = 0
    with evidence_svc.open_for_read(evidence) as fh:
        for chunk in iter(lambda: fh.read(CHUNK), b""):
            ctx.check_deadline()
            sha256.update(chunk)
            total += len(chunk)
            counts.update(chunk)  # C-accelerated byte histogram
    entropy = 0.0
    if total:
        for c in counts.values():
            if c:
                p = c / total
                entropy -= p * math.log2(p)
    entropy = round(entropy, 3)
    computed = sha256.hexdigest()
    intact = computed == evidence.sha256
    evidence_svc.add_event(
        ctx.db,
        evidence,
        "analyzed",
        ctx.user,
        run_id=ctx.run.id,
        details={"tool": ctx.run.tool_name, "sha256_match": intact},
    )
    ctx.log(f"Hashed {total} bytes; integrity {'verified' if intact else 'MISMATCH'}")

    ref = {"evidence_id": str(evidence.id), "locator": "whole file", "excerpt": f"sha256={computed}"}
    hashes = [
        IndicatorRef(IndicatorType.MD5, evidence.md5, "file_hash", evidence.original_filename),
        IndicatorRef(IndicatorType.SHA1, evidence.sha1, "file_hash", evidence.original_filename),
        IndicatorRef(IndicatorType.SHA256, evidence.sha256, "file_hash", evidence.original_filename),
    ]
    findings = [
        NormalizedFinding(
            finding_type="file_profile",
            title=f"File profile: {evidence.original_filename}",
            description=(
                f"{total:,} bytes, detected type '{evidence.detected_type}', byte entropy {entropy} bits/byte "
                "(0 = uniform, 8 = maximum). Hashes recorded as indicators for cross-investigation correlation."
            ),
            severity=Severity.INFO,
            confidence=Confidence.HIGH,
            affected_asset=evidence.original_filename,
            origin=FindingOrigin.TOOL,
            details={
                "size_bytes": total,
                "detected_type": evidence.detected_type,
                "entropy": entropy,
                "md5": evidence.md5,
                "sha1": evidence.sha1,
                "sha256": evidence.sha256,
                "evidence_kind": evidence.kind,
            },
            evidence_refs=[ref],
            indicators=hashes,
            fingerprint_parts=("profile", evidence.sha256),
        )
    ]
    if not intact:
        findings.append(
            NormalizedFinding(
                finding_type="evidence_integrity",
                title=f"Stored evidence hash mismatch: {evidence.original_filename}",
                description=(
                    f"SHA-256 recorded at registration was {evidence.sha256} but the stored file now hashes to "
                    f"{computed}. The stored copy can no longer be relied upon as the original evidence."
                ),
                severity=Severity.HIGH,
                confidence=Confidence.HIGH,
                affected_asset=evidence.original_filename,
                details={"expected_sha256": evidence.sha256, "computed_sha256": computed},
                evidence_refs=[ref],
                remediation=[
                    {
                        "text": "Re-acquire the evidence from its source and investigate access to storage.",
                        "source": "tool:evidence_profile",
                    }
                ],
                fingerprint_parts=("integrity", evidence.sha256, computed),
            )
        )
    summary = {
        "evidence_id": str(evidence.id),
        "filename": evidence.original_filename,
        "size_bytes": total,
        "detected_type": evidence.detected_type,
        "entropy": entropy,
        "sha256_recorded": evidence.sha256,
        "sha256_computed": computed,
        "integrity_verified": intact,
    }
    return ToolResult(
        summary=summary,
        findings=findings,
        raw_output=json.dumps(summary, indent=2).encode(),
        raw_output_name=f"profile-{evidence.sha256[:12]}.json",
        raw_output_parent_id=evidence.id,
    )


_KINDS = {
    Workspace.FORENSICS: {k for k in EvidenceKind if k != EvidenceKind.TOOL_OUTPUT},
    Workspace.MALWARE: {EvidenceKind.MALWARE_SAMPLE},
}


def _accepted_kinds(workspace: str) -> set[EvidenceKind]:
    return _KINDS[Workspace(workspace)]


def _scope(workspace: Workspace):  # type: ignore[no-untyped-def]
    def validator(db, investigation, args):  # type: ignore[no-untyped-def]
        evidence_in_investigation(db, investigation, args.evidence_id, _KINDS[workspace])

    return validator


register(
    ToolSpec(
        name="forensics_evidence_profile",
        workspace=Workspace.FORENSICS,
        title="Evidence integrity & profile",
        purpose="Re-hash a stored evidence item to verify integrity and record its size, type, entropy and hashes.",
        args_model=EvidenceProfileArgs,
        executor=_profile,
        timeout_seconds=600,
        output_format="JSON profile; findings: file_profile, evidence_integrity",
        scope_validator=_scope(Workspace.FORENSICS),
        side_effects="reads_evidence",
        example_requests=("Verify the integrity of the disk image evidence", "Profile the uploaded evidence file"),
    )
)

register(
    ToolSpec(
        name="malware_file_profile",
        workspace=Workspace.MALWARE,
        title="Static file profile",
        purpose="Hash and profile a malware sample without executing it: size, detected type, entropy, MD5/SHA-1/SHA-256.",
        args_model=EvidenceProfileArgs,
        executor=_profile,
        timeout_seconds=300,
        output_format="JSON profile; findings: file_profile",
        scope_validator=_scope(Workspace.MALWARE),
        side_effects="reads_evidence",
        example_requests=("Profile the suspicious sample", "Calculate hashes for the uploaded sample"),
    )
)
