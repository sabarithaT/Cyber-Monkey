"""FastAPI application factory."""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import APIRouter, FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text

from app import __version__
from app.api.deps import CSRF_HEADER
from app.api.v1 import (
    admin,
    assistant,
    audit_logs,
    auth,
    dashboard,
    evidence,
    findings,
    integrations,
    investigations,
    notifications,
    reports,
    threat_intel,
    tools,
)
from app.core.config import get_settings
from app.core.db import session_factory
from app.core.errors import install_error_handlers

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

API_PREFIX = "/api/v1"

TAGS = [
    {"name": "Authentication", "description": "Login, logout and the current user."},
    {"name": "Administration", "description": "Users, roles and permissions."},
    {"name": "Audit", "description": "Security-relevant activity log."},
    {"name": "Dashboard", "description": "Database-backed overview metrics."},
    {"name": "Investigations", "description": "Cases shared by every workspace, members, authorized scope, notes."},
    {"name": "Evidence", "description": "Controlled evidence storage with hashes and custody history."},
    {"name": "Tools & runs", "description": "Tool registry and approval-gated, time-bounded tool execution."},
    {"name": "Findings", "description": "Normalized findings with evidence, indicators and references."},
    {"name": "Threat intelligence", "description": "Indicators, correlation, CVE/ATT&CK references and risk scoring."},
    {"name": "Reports", "description": "Evidence-based reports, analyst review and PDF export."},
    {"name": "AI assistant", "description": "Natural-language requests routed through the AI Orchestrator."},
    {"name": "Notifications", "description": "Actionable items derived from live data."},
    {"name": "Integrations", "description": "Tool, intelligence and AI provider availability."},
    {"name": "System", "description": "Health and version."},
]


@asynccontextmanager
async def lifespan(_: FastAPI) -> AsyncIterator[None]:
    from app.services.runs import recover_interrupted_runs

    try:
        recovered = recover_interrupted_runs()
        if recovered:
            logging.getLogger("cybermonkey").warning("Marked %d interrupted tool run(s) as failed", recovered)
    except Exception:  # database may not be migrated yet; health endpoint reports it
        logging.getLogger("cybermonkey").exception("Could not check for interrupted runs")
    yield


def create_app() -> FastAPI:
    settings = get_settings()
    settings.resolved_jwt_secret()  # fail fast in production if the secret is missing

    app = FastAPI(
        title="Cyber Monkey API",
        version=__version__,
        description=(
            "Role-based, AI-orchestrated cybersecurity operations platform. Every endpoint "
            "enforces permissions on the server; investigation-scoped data additionally "
            "enforces ownership or membership."
        ),
        openapi_tags=TAGS,
        docs_url="/api/docs",
        redoc_url="/api/redoc",
        openapi_url="/api/openapi.json",
        lifespan=lifespan,
    )
    install_error_handlers(app)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
        allow_headers=["Authorization", "Content-Type", CSRF_HEADER],
    )

    @app.middleware("http")
    async def security_headers(request: Request, call_next):  # type: ignore[no-untyped-def]
        response: Response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        if not request.url.path.startswith(("/api/docs", "/api/redoc")):
            response.headers.setdefault("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'")
        response.headers.setdefault("Cache-Control", "no-store")
        return response

    api = APIRouter(prefix=API_PREFIX)
    api.include_router(auth.router)
    api.include_router(admin.router)
    api.include_router(audit_logs.router)
    api.include_router(notifications.router)
    api.include_router(integrations.router)
    api.include_router(dashboard.router)
    api.include_router(investigations.router)
    api.include_router(evidence.router)
    api.include_router(tools.router)
    api.include_router(findings.router)
    api.include_router(threat_intel.router)
    api.include_router(reports.router)
    api.include_router(assistant.router)

    @api.get("/health", tags=["System"], summary="Liveness and database connectivity")
    def health() -> dict[str, object]:
        db_ok = True
        try:
            with session_factory()() as db:
                db.execute(text("SELECT 1"))
        except Exception:
            db_ok = False
        return {"status": "ok" if db_ok else "degraded", "database": db_ok, "version": __version__}

    app.include_router(api)
    return app


app = create_app()
