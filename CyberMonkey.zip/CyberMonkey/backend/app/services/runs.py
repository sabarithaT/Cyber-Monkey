"""Tool run lifecycle: request -> (approval) -> execution -> results.

Every step is validated server-side and audit-logged:

1. the tool must exist in the registry;
2. the user must hold the tool's permissions and write access to the investigation;
3. arguments must validate against the tool's strict schema;
4. the arguments must be within the investigation's authorized scope;
5. required integrations must be available — otherwise the request is recorded as
   ``unavailable`` and nothing runs;
6. tools that require confirmation wait in ``pending_approval`` until a person approves;
7. execution is time-bounded; output is normalized into findings and the raw output is
   preserved as derived evidence.
"""

from __future__ import annotations

import logging
import time
import traceback
import uuid
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime
from typing import Any

from fastapi import Request
from pydantic import ValidationError
from sqlalchemy import select, update
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.constants import RunStatus
from app.core.db import session_factory
from app.core.errors import AppError, NotFound, PermissionDenied, ValidationFailed
from app.models import Investigation, ToolRun, User
from app.services import audit, authz
from app.services import evidence as evidence_svc
from app.services.findings import persist_findings
from app.services.integrations import availability
from app.tools.base import ScopeError, ToolContext, ToolSpec, ToolTimeout, ToolUnavailable, get_tool

log = logging.getLogger("cybermonkey.runs")

_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="tool-run")
_post_run_hooks: list[Callable[[uuid.UUID], None]] = []


class OutOfScope(AppError):
    status_code = 403
    code = "out_of_scope"


def on_run_finished(hook: Callable[[uuid.UUID], None]) -> None:
    _post_run_hooks.append(hook)


def notify_finished(run_id: uuid.UUID) -> None:
    """Run post-run hooks (also used when a run is declined rather than executed)."""
    for hook in _post_run_hooks:
        try:
            hook(run_id)
        except Exception:
            log.exception("Post-run hook failed for %s", run_id)


def tool_availability(db: Session, spec: ToolSpec) -> tuple[bool, str]:
    for key in spec.integrations_all:
        result = availability(db, key)
        if not result.available:
            return False, f"{key}: {result.detail}"
    if spec.integrations_any:
        results = [availability(db, key) for key in spec.integrations_any]
        if not any(r.available for r in results):
            return False, "; ".join(f"{k}: {r.detail}" for k, r in zip(spec.integrations_any, results, strict=True))
    return True, "available"


def validate_arguments(spec: ToolSpec, raw: dict[str, Any]) -> Any:
    try:
        return spec.args_model.model_validate(raw)
    except ValidationError as exc:
        details = [
            {"loc": list(err.get("loc", [])), "msg": err.get("msg", ""), "type": err.get("type", "")}
            for err in exc.errors()
        ]
        raise ValidationFailed(f"Invalid arguments for {spec.name}", details=details) from exc


def check_scope(db: Session, spec: ToolSpec, investigation: Investigation, args: Any) -> None:
    if spec.scope_validator is None:
        return
    try:
        spec.scope_validator(db, investigation, args)
    except ScopeError as exc:
        raise OutOfScope(str(exc)) from exc


def ensure_tool_permissions(user: User, spec: ToolSpec, request: Request | None) -> None:
    for code in spec.permissions:
        authz.ensure_permission(user, code, request, resource=f"tool:{spec.name}")


def request_run(
    db: Session,
    *,
    user: User,
    investigation: Investigation,
    tool_name: str,
    raw_args: dict[str, Any],
    origin: str = "workspace",
    conversation_id: uuid.UUID | None = None,
    request: Request | None = None,
) -> ToolRun:
    spec = get_tool(tool_name)
    if spec is None:
        raise ValidationFailed(f"Unknown tool '{tool_name}'", code="unknown_tool")
    ensure_tool_permissions(user, spec, request)
    args = validate_arguments(spec, raw_args)
    try:
        check_scope(db, spec, investigation, args)
    except OutOfScope as exc:
        audit.record_independent(
            action="tool_run.request",
            result="denied",
            actor=user,
            resource_type="investigation",
            resource_id=investigation.id,
            request=request,
            details={"tool": spec.name, "arguments": args.model_dump(mode="json"), "reason": exc.message},
        )
        raise
    available, detail = tool_availability(db, spec)
    needs_approval = spec.approval_needed(args)
    run = ToolRun(
        investigation_id=investigation.id,
        workspace=spec.workspace.value,
        tool_name=spec.name,
        arguments=args.model_dump(mode="json"),
        origin=origin,
        requires_approval=needs_approval,
        requested_by_id=user.id,
        timeout_seconds=spec.timeout_seconds,
        conversation_id=conversation_id,
    )
    if not available:
        run.status = RunStatus.UNAVAILABLE
        run.error_message = f"Integration not configured — {detail}. Nothing was executed."
        run.finished_at = datetime.now(UTC)
    elif needs_approval:
        run.status = RunStatus.PENDING_APPROVAL
    else:
        run.status = RunStatus.QUEUED
    db.add(run)
    db.flush()
    audit.record(
        db,
        action="tool_run.request",
        actor=user,
        resource_type="tool_run",
        resource_id=run.id,
        request=request,
        result="success" if available else "failure",
        details={
            "investigation": investigation.reference,
            "tool": spec.name,
            "arguments": run.arguments,
            "status": run.status,
            "origin": origin,
            "requires_approval": needs_approval,
        },
    )
    return run


def get_run(
    db: Session, run_id: uuid.UUID, user: User, *, write: bool = False, request: Request | None = None
) -> ToolRun:
    run = db.get(ToolRun, run_id)
    if run is None:
        raise NotFound("Tool run not found")
    authz.get_investigation(db, run.investigation_id, user, write=write, request=request)
    return run


def decide(
    db: Session, *, run: ToolRun, user: User, approve: bool, note: str, request: Request | None = None
) -> ToolRun:
    if run.status != RunStatus.PENDING_APPROVAL:
        raise ValidationFailed(f"Run is {run.status}; only runs awaiting approval can be decided")
    spec = get_tool(run.tool_name)
    if spec is None:
        raise ValidationFailed("The tool for this run is no longer registered")
    ensure_tool_permissions(user, spec, request)
    investigation = db.get(Investigation, run.investigation_id)
    assert investigation is not None
    if approve:
        # Re-validate at decision time: scope or integrations may have changed meanwhile.
        args = validate_arguments(spec, run.arguments)
        check_scope(db, spec, investigation, args)
        available, detail = tool_availability(db, spec)
        if not available:
            raise ValidationFailed(
                f"Cannot approve: integration not configured — {detail}", code="integration_unavailable"
            )
        run.status = RunStatus.QUEUED
    else:
        run.status = RunStatus.REJECTED
        run.finished_at = datetime.now(UTC)
    run.approved_by_id = user.id
    run.approval_decided_at = datetime.now(UTC)
    run.approval_note = note
    audit.record(
        db,
        action="tool_run.approve" if approve else "tool_run.reject",
        actor=user,
        resource_type="tool_run",
        resource_id=run.id,
        request=request,
        details={"tool": run.tool_name, "arguments": run.arguments, "note": note},
    )
    return run


def dispatch(run_id: uuid.UUID) -> None:
    """Execute a queued run (after the caller has committed it)."""
    if get_settings().tool_execution_mode == "inline":
        execute(run_id)
    else:
        _executor.submit(execute, run_id)


def _sanitize_error(exc: BaseException) -> str:
    text = str(exc) or exc.__class__.__name__
    return text[:1000]


def execute(run_id: uuid.UUID) -> None:
    with session_factory()() as db:
        claimed = db.execute(
            update(ToolRun)
            .where(ToolRun.id == run_id, ToolRun.status == RunStatus.QUEUED)
            .values(status=RunStatus.RUNNING, started_at=datetime.now(UTC))
        ).rowcount
        db.commit()
        if not claimed:
            return  # already taken or no longer queued
        run = db.get(ToolRun, run_id)
        assert run is not None
        spec = get_tool(run.tool_name)
        investigation = db.get(Investigation, run.investigation_id)
        user = db.get(User, run.requested_by_id)
        assert investigation is not None and user is not None
        ctx: ToolContext | None = None
        try:
            if spec is None:
                raise ToolUnavailable("Tool is no longer registered")
            args = validate_arguments(spec, run.arguments)
            check_scope(db, spec, investigation, args)
            ctx = ToolContext(
                db=db,
                run=run,
                investigation=investigation,
                user=user,
                args=args,
                deadline=time.monotonic() + run.timeout_seconds,
            )
            ctx.log(f"Started {spec.name}")
            result = spec.executor(ctx)
            findings = persist_findings(db, run, result.findings, source_tool=spec.name)
            if result.raw_output is not None:
                parent = (
                    db.get(evidence_svc.Evidence, result.raw_output_parent_id) if result.raw_output_parent_id else None
                )
                raw = evidence_svc.store_derived(
                    db,
                    investigation_id=investigation.id,
                    content=result.raw_output,
                    filename=result.raw_output_name,
                    run_id=run.id,
                    parent=parent,
                    description=f"Raw output of {spec.name} run {run.id}",
                    actor=user,
                )
                run.raw_output_evidence_id = raw.id
            run.output_summary = {**result.summary, "finding_count": len(findings), "notes": result.notes}
            run.exit_code = result.exit_code
            run.status = RunStatus.SUCCEEDED
            ctx.log(f"Finished: {len(findings)} finding(s)")
        except ToolTimeout as exc:
            db.rollback()
            run = db.get(ToolRun, run_id)
            assert run is not None
            run.status = RunStatus.TIMED_OUT
            run.error_message = _sanitize_error(exc)
        except (ToolUnavailable, ScopeError, OutOfScope) as exc:
            db.rollback()
            run = db.get(ToolRun, run_id)
            assert run is not None
            run.status = RunStatus.UNAVAILABLE if isinstance(exc, ToolUnavailable) else RunStatus.FAILED
            run.error_message = _sanitize_error(getattr(exc, "message", exc))  # type: ignore[arg-type]
        except AppError as exc:
            db.rollback()
            run = db.get(ToolRun, run_id)
            assert run is not None
            run.status = RunStatus.FAILED
            run.error_message = exc.message[:1000]
        except Exception as exc:
            log.error("Tool run %s failed: %s", run_id, traceback.format_exc())
            db.rollback()
            run = db.get(ToolRun, run_id)
            assert run is not None
            run.status = RunStatus.FAILED
            run.error_message = f"Tool execution failed: {_sanitize_error(exc)}"
        run.finished_at = datetime.now(UTC)
        if ctx is not None:
            run.execution_log = ctx.log_lines[-200:]
        audit.record(
            db,
            action="tool_run.complete",
            actor=user,
            resource_type="tool_run",
            resource_id=run.id,
            result="success" if run.status == RunStatus.SUCCEEDED else "failure",
            details={
                "tool": run.tool_name,
                "status": run.status,
                "error": run.error_message[:300],
                "finding_count": run.output_summary.get("finding_count") if run.output_summary else None,
            },
        )
        db.commit()
    notify_finished(run_id)


def recover_interrupted_runs() -> int:
    """Runs left running/queued by a previous process can never finish; record that."""
    with session_factory()() as db:
        stale = list(db.scalars(select(ToolRun).where(ToolRun.status.in_([RunStatus.RUNNING, RunStatus.QUEUED]))))
        for run in stale:
            run.status = RunStatus.FAILED
            run.error_message = "Interrupted: the server restarted before this run finished. Request it again."
            run.finished_at = datetime.now(UTC)
        db.commit()
        return len(stale)


def ensure_can_view_run_output(user: User, run: ToolRun, request: Request | None) -> None:
    if not authz.has_permission(user, f"{run.workspace}:view"):
        authz.ensure_permission(user, f"{run.workspace}:view", request, resource="tool_run")
        raise PermissionDenied("Missing workspace access")
