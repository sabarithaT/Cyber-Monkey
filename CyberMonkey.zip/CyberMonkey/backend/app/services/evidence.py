"""Controlled evidence storage.

Uploaded files are streamed to a temporary file while MD5/SHA-1/SHA-256 are computed and
the per-kind size limit is enforced, validated against the declared kind, then moved to
a content-addressed path and marked read-only. Analysis never writes to an original:
tools read it and record their output as separate, derived evidence. Every access is
recorded as a custody event."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import stat
import tempfile
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import BinaryIO

from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.constants import EvidenceKind, Workspace
from app.core.errors import Conflict, ValidationFailed
from app.models import Evidence, EvidenceEvent, User

CHUNK = 1024 * 1024

# Which workspace's "operate" permission is needed to upload each kind of evidence.
KIND_WORKSPACE: dict[EvidenceKind, Workspace] = {
    EvidenceKind.LOG: Workspace.SOC,
    EvidenceKind.PCAP: Workspace.NETWORK,
    EvidenceKind.IDS_ALERTS: Workspace.NETWORK,
    EvidenceKind.MALWARE_SAMPLE: Workspace.MALWARE,
    EvidenceKind.SANDBOX_REPORT: Workspace.MALWARE,
    EvidenceKind.DISK_IMAGE: Workspace.FORENSICS,
    EvidenceKind.MEMORY_IMAGE: Workspace.FORENSICS,
    EvidenceKind.FORENSIC_REPORT: Workspace.FORENSICS,
    EvidenceKind.OSINT_RECORD: Workspace.OSINT,
    EvidenceKind.SCAN_REPORT: Workspace.PENTEST,
    EvidenceKind.OTHER: Workspace.FORENSICS,
}

# Kinds that may never be downloaded through the web application.
NO_DOWNLOAD_KINDS = {EvidenceKind.MALWARE_SAMPLE}


def storage_root() -> Path:
    root = Path(get_settings().storage_dir).resolve()
    root.mkdir(parents=True, exist_ok=True)
    return root


def absolute_path(evidence: Evidence) -> Path:
    if not evidence.stored_path:
        raise ValidationFailed("This evidence item was registered without a stored file")
    path = (storage_root() / evidence.stored_path).resolve()
    if storage_root() not in path.parents:
        raise ValidationFailed("Stored path escapes the storage root")
    return path


_FILENAME_BAD = re.compile(r"[\x00-\x1f\x7f/\\]+")


def clean_filename(name: str | None) -> str:
    base = (name or "upload.bin").replace("\\", "/").split("/")[-1]
    base = _FILENAME_BAD.sub("_", base).strip(". ") or "upload.bin"
    return base[:200]


def detect_type(head: bytes) -> str:
    if head.startswith(b"MZ"):
        return "pe_executable"
    if head.startswith(b"\x7fELF"):
        return "elf_executable"
    if head.startswith(b"%PDF"):
        return "pdf"
    if head.startswith(b"PK\x03\x04"):
        return "zip_archive"
    if head.startswith(b"\x1f\x8b"):
        return "gzip"
    if head[:4] in (b"\xd4\xc3\xb2\xa1", b"\xa1\xb2\xc3\xd4", b"\x4d\x3c\xb2\xa1", b"\xa1\xb2\x3c\x4d"):
        return "pcap"
    if head.startswith(b"\x0a\x0d\x0d\x0a"):
        return "pcapng"
    if head.startswith(b"\xca\xfe\xba\xbe") or head[:4] in (b"\xcf\xfa\xed\xfe", b"\xce\xfa\xed\xfe"):
        return "macho_executable"
    if head.startswith(b"EVF") or head.startswith(b"EVF2"):
        return "ewf_image"
    # The sniff window may end in the middle of a multi-byte character, so allow up to
    # three trailing bytes to be dropped before deciding the content is binary.
    for cut in range(4):
        try:
            text = head[: len(head) - cut].decode("utf-8")
            break
        except UnicodeDecodeError:
            continue
    else:
        return "binary"
    if "\x00" in text:
        return "binary"
    stripped = text.lstrip("﻿ \t\r\n")
    if stripped.startswith(("{", "[")):
        return "json_text"
    return "text"


_KIND_RULES: dict[EvidenceKind, set[str] | None] = {
    EvidenceKind.LOG: {"text", "json_text"},
    EvidenceKind.PCAP: {"pcap", "pcapng"},
    EvidenceKind.IDS_ALERTS: {"json_text", "text"},
    EvidenceKind.SANDBOX_REPORT: {"json_text"},
    EvidenceKind.FORENSIC_REPORT: {"json_text", "text"},
    EvidenceKind.OSINT_RECORD: {"json_text", "text"},
    EvidenceKind.SCAN_REPORT: {"json_text", "text"},
    EvidenceKind.MALWARE_SAMPLE: None,
    EvidenceKind.DISK_IMAGE: None,
    EvidenceKind.MEMORY_IMAGE: None,
    EvidenceKind.OTHER: None,
    EvidenceKind.TOOL_OUTPUT: None,
}


@dataclass
class StoredFile:
    relative_path: str
    size: int
    md5: str
    sha1: str
    sha256: str
    detected_type: str


def _store_stream(stream: BinaryIO, kind: EvidenceKind, limit: int) -> StoredFile:
    root = storage_root()
    tmp_dir = root / "tmp"
    tmp_dir.mkdir(exist_ok=True)
    md5, sha1, sha256 = hashlib.md5(usedforsecurity=False), hashlib.sha1(usedforsecurity=False), hashlib.sha256()
    size = 0
    head = b""
    fd, tmp_name = tempfile.mkstemp(dir=tmp_dir, prefix="upload-")
    try:
        with os.fdopen(fd, "wb") as out:
            while True:
                chunk = stream.read(CHUNK)
                if not chunk:
                    break
                size += len(chunk)
                if size > limit:
                    raise ValidationFailed(
                        f"File exceeds the {limit // (1024 * 1024)} MB limit for {kind.value} evidence",
                        code="file_too_large",
                    )
                if len(head) < 4096:
                    head += chunk[: 4096 - len(head)]
                md5.update(chunk)
                sha1.update(chunk)
                sha256.update(chunk)
                out.write(chunk)
        if size == 0:
            raise ValidationFailed("The uploaded file is empty")
        detected = detect_type(head)
        allowed = _KIND_RULES.get(kind)
        if allowed is not None and detected not in allowed:
            raise ValidationFailed(
                f"File content looks like '{detected}', which is not accepted for {kind.value} evidence",
                details={"detected_type": detected, "accepted": sorted(allowed)},
                code="file_type_rejected",
            )
        digest = sha256.hexdigest()
        relative = Path("evidence") / kind.value / digest[:2] / f"{digest}.bin"
        final = root / relative
        final.parent.mkdir(parents=True, exist_ok=True)
        if final.exists():
            os.unlink(tmp_name)
        else:
            shutil.move(tmp_name, final)
            os.chmod(final, stat.S_IREAD | stat.S_IRGRP)  # read-only: originals are never modified
        return StoredFile(relative.as_posix(), size, md5.hexdigest(), sha1.hexdigest(), digest, detected)
    except BaseException:
        if os.path.exists(tmp_name):
            os.unlink(tmp_name)
        raise


def store_upload(
    db: Session,
    *,
    investigation_id: uuid.UUID,
    kind: EvidenceKind,
    stream: BinaryIO,
    filename: str | None,
    uploaded_by: User,
    source_description: str = "",
    acquired_at: datetime | None = None,
    notes: str = "",
) -> Evidence:
    stored = _store_stream(stream, kind, get_settings().max_upload_bytes(kind.value))
    duplicate = (
        db.query(Evidence).filter_by(investigation_id=investigation_id, sha256=stored.sha256, kind=kind.value).first()
    )
    if duplicate is not None:
        raise Conflict(
            "This exact file is already registered as evidence in this investigation",
            details={"evidence_id": str(duplicate.id)},
        )
    evidence = Evidence(
        investigation_id=investigation_id,
        kind=kind.value,
        original_filename=clean_filename(filename),
        stored_path=stored.relative_path,
        size_bytes=stored.size,
        md5=stored.md5,
        sha1=stored.sha1,
        sha256=stored.sha256,
        detected_type=stored.detected_type,
        source_description=source_description,
        acquired_at=acquired_at,
        uploaded_by_id=uploaded_by.id,
        is_original=True,
        notes=notes,
        metadata_json={"hash_source": "computed_on_upload"},
    )
    db.add(evidence)
    db.flush()
    add_event(db, evidence, "registered", uploaded_by, details={"sha256": stored.sha256, "size_bytes": stored.size})
    return evidence


def store_derived(
    db: Session,
    *,
    investigation_id: uuid.UUID,
    content: bytes,
    filename: str,
    run_id: uuid.UUID,
    parent: Evidence | None,
    description: str,
    actor: User | None,
) -> Evidence:
    """Preserve raw tool output as derived evidence linked to the run (and source evidence)."""
    import io

    stored = _store_stream(io.BytesIO(content or b"\n"), EvidenceKind.TOOL_OUTPUT, 512 * 1024 * 1024)
    evidence = Evidence(
        investigation_id=investigation_id,
        kind=EvidenceKind.TOOL_OUTPUT.value,
        original_filename=clean_filename(filename),
        stored_path=stored.relative_path,
        size_bytes=stored.size,
        md5=stored.md5,
        sha1=stored.sha1,
        sha256=stored.sha256,
        detected_type=stored.detected_type,
        source_description=description,
        uploaded_by_id=actor.id if actor else None,
        is_original=False,
        parent_evidence_id=parent.id if parent else None,
        produced_by_run_id=run_id,
        metadata_json={"hash_source": "computed_on_capture"},
    )
    db.add(evidence)
    db.flush()
    add_event(db, evidence, "captured", actor, run_id=run_id, details={"sha256": stored.sha256})
    return evidence


def add_event(
    db: Session,
    evidence: Evidence,
    action: str,
    actor: User | None,
    *,
    run_id: uuid.UUID | None = None,
    details: dict | None = None,
) -> None:
    db.add(
        EvidenceEvent(
            evidence_id=evidence.id,
            action=action,
            actor_id=actor.id if actor else None,
            run_id=run_id,
            details=details or {},
        )
    )


def verify_hash(evidence: Evidence) -> dict[str, object]:
    path = absolute_path(evidence)
    if not path.is_file():
        return {"match": False, "reason": "stored file is missing"}
    sha256 = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(CHUNK), b""):
            sha256.update(chunk)
    digest = sha256.hexdigest()
    return {"match": digest == evidence.sha256, "expected_sha256": evidence.sha256, "computed_sha256": digest}


def open_for_read(evidence: Evidence) -> BinaryIO:
    return open(absolute_path(evidence), "rb")


def read_text(evidence: Evidence, limit: int) -> str:
    with open_for_read(evidence) as fh:
        data = fh.read(limit + 1)
    if len(data) > limit:
        raise ValidationFailed(f"Evidence is larger than the {limit // (1024 * 1024)} MB analysis limit")
    return data.decode("utf-8", errors="replace")


def read_json(evidence: Evidence, limit: int) -> object:
    try:
        return json.loads(read_text(evidence, limit).lstrip("﻿"))
    except json.JSONDecodeError as exc:
        raise ValidationFailed(f"Evidence is not valid JSON: {exc.msg} at line {exc.lineno}") from exc
