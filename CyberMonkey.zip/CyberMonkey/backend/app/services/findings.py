"""Persisting normalized findings, their indicators and intelligence references."""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session

from app.core.constants import FindingOrigin, ValidationStatus
from app.models import Finding, FindingIndicator, FindingReference, Indicator, ThreatIntelReference, ToolRun
from app.services import indicators as ioc
from app.tools.base import NormalizedFinding


def fingerprint(workspace: str, source_tool: str, nf: NormalizedFinding) -> str:
    parts = nf.fingerprint_parts or (nf.finding_type, nf.affected_asset, nf.title)
    payload = json.dumps([workspace, source_tool, nf.finding_type, *parts], sort_keys=True, default=str)
    return hashlib.sha256(payload.encode()).hexdigest()


def upsert_indicator(db: Session, type_: str, value: str) -> Indicator | None:
    normalized = ioc.normalize(type_, value)
    if normalized is None:
        return None
    now = datetime.now(UTC)
    stmt = (
        pg_insert(Indicator)
        .values(type=normalized.type.value, value=normalized.value, first_seen=now, last_seen=now, reputation={})
        .on_conflict_do_update(index_elements=["type", "value"], set_={"last_seen": now})
        .returning(Indicator.id)
    )
    indicator_id = db.execute(stmt).scalar_one()
    return db.get(Indicator, indicator_id)


def reference_for(db: Session, ref_type: str, external_id: str) -> ThreatIntelReference | None:
    return db.scalar(
        select(ThreatIntelReference).where(
            ThreatIntelReference.ref_type == ref_type, ThreatIntelReference.external_id == external_id
        )
    )


def persist_findings(db: Session, run: ToolRun, items: list[NormalizedFinding], *, source_tool: str) -> list[Finding]:
    """Insert new findings or merge evidence into existing ones with the same fingerprint."""
    from app.services.threat_intel import ensure_reference  # local import: TI engine depends on this module

    saved: list[Finding] = []
    for nf in items:
        fp = fingerprint(run.workspace, source_tool, nf)
        finding = db.scalar(
            select(Finding).where(Finding.investigation_id == run.investigation_id, Finding.fingerprint == fp)
        )
        if finding is None:
            finding = Finding(
                investigation_id=run.investigation_id,
                workspace=run.workspace,
                source_tool=source_tool,
                run_id=run.id,
                origin=nf.origin.value if isinstance(nf.origin, FindingOrigin) else str(nf.origin),
                rule_id=nf.rule_id,
                finding_type=nf.finding_type,
                title=nf.title[:300],
                description=nf.description,
                severity=str(nf.severity),
                confidence=str(nf.confidence),
                affected_asset=nf.affected_asset[:255],
                observed_at=nf.observed_at,
                validation_status=ValidationStatus.UNVERIFIED,
                fingerprint=fp,
                details=nf.details,
                evidence_refs=nf.evidence_refs[:50],
                remediation=nf.remediation,
            )
            db.add(finding)
            db.flush()
        else:
            # Re-observed: keep the original record, append new evidence locations and
            # remember which runs saw it.
            refs = list(finding.evidence_refs)
            known = {json.dumps(r, sort_keys=True) for r in refs}
            for ref in nf.evidence_refs:
                if json.dumps(ref, sort_keys=True) not in known and len(refs) < 50:
                    refs.append(ref)
            finding.evidence_refs = refs
            seen = list(finding.details.get("seen_in_runs", []))
            if str(run.id) not in seen:
                seen.append(str(run.id))
            finding.details = {**finding.details, "seen_in_runs": seen[-20:]}
        linked = {link.indicator_id for link in finding.indicator_links}
        for ref in nf.indicators:
            indicator = upsert_indicator(db, ref.type, ref.value)
            if indicator is not None and indicator.id not in linked:
                db.add(
                    FindingIndicator(
                        finding_id=finding.id,
                        indicator_id=indicator.id,
                        relation=ref.relation,
                        context=ref.context[:500],
                    )
                )
                linked.add(indicator.id)
        referenced = {link.reference_id for link in finding.reference_links}
        for ref in nf.references:
            reference = ensure_reference(db, ref.ref_type, ref.external_id)
            if reference is not None and reference.id not in referenced:
                db.add(
                    FindingReference(
                        finding_id=finding.id,
                        reference_id=reference.id,
                        match_basis=ref.match_basis,
                        validation_status=ref.validation,
                    )
                )
                referenced.add(reference.id)
        db.flush()
        saved.append(finding)
    return saved
