"""Indicator-of-compromise extraction and normalization.

Normalization makes the same indicator compare equal regardless of where it was seen:
IPs are canonicalized, domains lower-cased with trailing dots removed and IDNs
converted to punycode, URLs get a lower-cased scheme/host and no fragment, hashes are
lower-cased and length-checked. Private, loopback and documentation IPs are kept (they
matter inside an investigation) but flagged so they are never sent to external
reputation services."""

from __future__ import annotations

import ipaddress
import re
from dataclasses import dataclass
from urllib.parse import urlsplit, urlunsplit

from app.core.constants import IndicatorType

_HEX = re.compile(r"^[0-9a-f]+$")
_DOMAIN = re.compile(r"^(?=.{4,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{1,62}$")

# File extensions that the domain regex would otherwise accept from log text.
_NOT_TLDS = {
    "exe",
    "dll",
    "sys",
    "bat",
    "ps1",
    "vbs",
    "js",
    "jar",
    "zip",
    "rar",
    "gz",
    "tar",
    "txt",
    "log",
    "csv",
    "json",
    "xml",
    "html",
    "htm",
    "php",
    "asp",
    "aspx",
    "jsp",
    "png",
    "jpg",
    "jpeg",
    "gif",
    "pdf",
    "doc",
    "docx",
    "xls",
    "xlsx",
    "ini",
    "cfg",
    "conf",
    "tmp",
    "dat",
    "bin",
    "py",
    "sh",
    "so",
    "lnk",
    "msi",
    "iso",
    "img",
    "local",
}


@dataclass(frozen=True)
class NormalizedIndicator:
    type: IndicatorType
    value: str
    is_internal: bool = False


def normalize(type_: str, value: str) -> NormalizedIndicator | None:
    """Return the canonical indicator, or None if ``value`` is not a valid ``type_``."""
    raw = (value or "").strip().strip("[]()<>\"'")
    if not raw:
        return None
    try:
        kind = IndicatorType(type_)
    except ValueError:
        return None
    if kind in (IndicatorType.IPV4, IndicatorType.IPV6):
        try:
            ip = ipaddress.ip_address(raw.replace("[.]", "."))
        except ValueError:
            return None
        actual = IndicatorType.IPV4 if ip.version == 4 else IndicatorType.IPV6
        if getattr(ip, "ipv4_mapped", None):
            ip = ip.ipv4_mapped  # type: ignore[union-attr]
            actual = IndicatorType.IPV4
        internal = ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast
        return NormalizedIndicator(actual, str(ip), internal)
    if kind == IndicatorType.DOMAIN:
        domain = raw.lower().rstrip(".").replace("[.]", ".")
        try:
            domain = domain.encode("idna").decode("ascii")
        except UnicodeError:
            return None
        if not _DOMAIN.match(domain) or domain.rsplit(".", 1)[-1] in _NOT_TLDS:
            return None
        internal = domain.endswith((".local", ".internal", ".lan", ".corp", ".home.arpa", ".test", ".localhost"))
        return NormalizedIndicator(kind, domain, internal)
    if kind == IndicatorType.URL:
        candidate = raw.replace("hxxp", "http").replace("[.]", ".")
        parts = urlsplit(candidate)
        if parts.scheme.lower() not in ("http", "https", "ftp") or not parts.hostname:
            return None
        host = parts.hostname.lower()
        netloc = host + (f":{parts.port}" if parts.port else "")
        return NormalizedIndicator(kind, urlunsplit((parts.scheme.lower(), netloc, parts.path or "/", parts.query, "")))
    if kind == IndicatorType.EMAIL:
        email = raw.lower()
        if "@" not in email:
            return None
        local, _, domain = email.rpartition("@")
        nd = normalize("domain", domain)
        if not local or nd is None:
            return None
        return NormalizedIndicator(kind, f"{local}@{nd.value}", nd.is_internal)
    expected = {IndicatorType.MD5: 32, IndicatorType.SHA1: 40, IndicatorType.SHA256: 64}[kind]
    digest = raw.lower()
    if len(digest) != expected or not _HEX.match(digest):
        return None
    return NormalizedIndicator(kind, digest)


def hash_type(value: str) -> IndicatorType | None:
    return {32: IndicatorType.MD5, 40: IndicatorType.SHA1, 64: IndicatorType.SHA256}.get(len(value.strip()))


_IPV4_RE = re.compile(r"(?<![\d.])(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)(?![\d.])")
_URL_RE = re.compile(r"\b(?:https?|hxxps?|ftp)://[^\s\"'<>`]{3,2000}", re.IGNORECASE)
_DOMAIN_RE = re.compile(r"\b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{1,62}\b", re.IGNORECASE)
_EMAIL_RE = re.compile(r"\b[a-z0-9._%+-]{1,64}@(?:[a-z0-9-]+\.)+[a-z]{2,63}\b", re.IGNORECASE)
_HASH_RE = re.compile(r"\b(?:[a-f0-9]{64}|[a-f0-9]{40}|[a-f0-9]{32})\b", re.IGNORECASE)


def extract(text: str, *, max_items: int = 200) -> list[NormalizedIndicator]:
    """Extract indicators from free text. Used on strings pulled from tool output; every
    result still carries the evidence location it came from."""
    found: dict[tuple[str, str], NormalizedIndicator] = {}

    def add(candidate: NormalizedIndicator | None) -> None:
        if candidate and len(found) < max_items:
            found.setdefault((candidate.type.value, candidate.value), candidate)

    for match in _URL_RE.findall(text):
        add(normalize("url", match.rstrip(".,;)")))
    for match in _EMAIL_RE.findall(text):
        add(normalize("email", match))
    for match in _IPV4_RE.findall(text):
        add(normalize("ipv4", match))
    for match in _HASH_RE.findall(text):
        kind = hash_type(match)
        if kind:
            add(normalize(kind.value, match))
    emails = {v.value.split("@")[1] for v in found.values() if v.type == IndicatorType.EMAIL}
    for match in _DOMAIN_RE.findall(text):
        nd = normalize("domain", match)
        if nd and nd.value not in emails:
            add(nd)
    return list(found.values())
