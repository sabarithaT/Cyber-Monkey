"""Authorization: permission checks and investigation ownership.

Every protected endpoint checks a permission code *and*, for investigation-scoped data,
that the user owns the investigation, is a member of it, or holds
``investigations:manage_all``. Investigations the user cannot access are reported as
not found so their existence is not disclosed."""

from __future__ import annotations

import uuid

from fastapi import Request
from sqlalchemy import ColumnElement, exists, or_, select
from sqlalchemy.orm import Session

from app.core.constants import Workspace, workspace_permission
from app.core.errors import NotFound, PermissionDenied
from app.models import Investigation, InvestigationMember, User
from app.services import audit


def permissions_of(user: User) -> set[str]:
    cached = getattr(user, "_cm_permissions", None)
    if cached is None:
        cached = user.effective_permissions()
        user._cm_permissions = cached  # type: ignore[attr-defined]
    return cached


def has_permission(user: User, code: str) -> bool:
    return code in permissions_of(user)


def ensure_permission(user: User, code: str, request: Request | None = None, resource: str = "") -> None:
    if not has_permission(user, code):
        audit.record_independent(
            action="authz.denied",
            result="denied",
            actor=user,
            resource_type=resource,
            request=request,
            details={"required_permission": code, "path": request.url.path if request else ""},
        )
        raise PermissionDenied(f"Missing permission: {code}", details={"required_permission": code})


def ensure_workspace(user: User, workspace: Workspace | str, action: str, request: Request | None = None) -> None:
    ensure_permission(user, workspace_permission(workspace, action), request, resource=f"workspace:{workspace}")


def permitted_workspaces(user: User, action: str = "view") -> list[Workspace]:
    return [ws for ws in Workspace if has_permission(user, workspace_permission(ws, action))]


def investigation_visibility_clause(user: User) -> ColumnElement[bool]:
    if has_permission(user, "investigations:manage_all"):
        return Investigation.id.is_not(None)
    member = exists().where(
        InvestigationMember.investigation_id == Investigation.id, InvestigationMember.user_id == user.id
    )
    return or_(Investigation.owner_id == user.id, member)


def get_investigation(
    db: Session,
    investigation_id: uuid.UUID,
    user: User,
    *,
    write: bool = False,
    request: Request | None = None,
) -> Investigation:
    ensure_permission(user, "investigations:view", request, resource="investigation")
    inv = db.get(Investigation, investigation_id)
    if inv is None:
        raise NotFound("Investigation not found")
    if has_permission(user, "investigations:manage_all") or inv.owner_id == user.id:
        return inv
    membership = db.scalar(
        select(InvestigationMember).where(
            InvestigationMember.investigation_id == inv.id, InvestigationMember.user_id == user.id
        )
    )
    if membership is not None and (not write or membership.access_level == "contributor"):
        return inv
    audit.record_independent(
        action="authz.investigation_denied",
        result="denied",
        actor=user,
        resource_type="investigation",
        resource_id=inv.id,
        request=request,
        details={"write": write},
    )
    raise NotFound("Investigation not found")
