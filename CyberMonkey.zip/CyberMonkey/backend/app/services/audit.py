"""Audit logging.

``record`` adds the entry to the caller's session so it commits atomically with the
business change. ``record_independent`` writes in its own transaction and is used for
failures and denials, which must persist even when the caller's transaction rolls back.
Secrets are redacted from ``details`` before anything is stored."""

from __future__ import annotations

import logging
import uuid
from typing import Any

from fastapi import Request
from sqlalchemy.orm import Session

from app.core.db import session_factory
from app.models import AuditLog, User

log = logging.getLogger("cybermonkey.audit")

_SENSITIVE_KEYS = ("password", "token", "secret", "api_key", "apikey", "authorization", "cookie", "credential")
_MAX_STRING = 2000


def _redact(value: Any, depth: int = 0) -> Any:
    if depth > 6:
        return "<truncated>"
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            if any(s in str(key).lower() for s in _SENSITIVE_KEYS):
                out[str(key)] = "<redacted>"
            else:
                out[str(key)] = _redact(item, depth + 1)
        return out
    if isinstance(value, list | tuple):
        return [_redact(v, depth + 1) for v in list(value)[:100]]
    if isinstance(value, str):
        return value if len(value) <= _MAX_STRING else value[:_MAX_STRING] + "…"
    if isinstance(value, uuid.UUID):
        return str(value)
    if value is None or isinstance(value, bool | int | float):
        return value
    return str(value)


def client_ip(request: Request | None) -> str:
    if request is None or request.client is None:
        return ""
    return request.client.host or ""


def _build(
    *,
    action: str,
    result: str,
    actor: User | None,
    actor_email: str | None,
    resource_type: str,
    resource_id: str | uuid.UUID | None,
    request: Request | None,
    details: dict[str, Any] | None,
) -> AuditLog:
    return AuditLog(
        actor_id=actor.id if actor else None,
        actor_email=(actor.email if actor else (actor_email or ""))[:320],
        action=action,
        resource_type=resource_type,
        resource_id=str(resource_id) if resource_id else "",
        result=result,
        ip_address=client_ip(request),
        user_agent=(request.headers.get("user-agent", "") if request else "")[:300],
        details=_redact(details or {}),
    )


def record(
    db: Session,
    *,
    action: str,
    result: str = "success",
    actor: User | None = None,
    actor_email: str | None = None,
    resource_type: str = "",
    resource_id: str | uuid.UUID | None = None,
    request: Request | None = None,
    details: dict[str, Any] | None = None,
) -> None:
    db.add(
        _build(
            action=action,
            result=result,
            actor=actor,
            actor_email=actor_email,
            resource_type=resource_type,
            resource_id=resource_id,
            request=request,
            details=details,
        )
    )


def record_independent(
    *,
    action: str,
    result: str,
    actor: User | None = None,
    actor_email: str | None = None,
    resource_type: str = "",
    resource_id: str | uuid.UUID | None = None,
    request: Request | None = None,
    details: dict[str, Any] | None = None,
) -> None:
    entry = _build(
        action=action,
        result=result,
        actor=actor,
        actor_email=actor_email,
        resource_type=resource_type,
        resource_id=resource_id,
        request=request,
        details=details,
    )
    try:
        with session_factory()() as db:
            db.add(entry)
            db.commit()
    except Exception:  # auditing must never take the request down with it
        log.exception("Failed to write audit entry %s", action)
