"""PDF export of a report (ReportLab, no external binaries)."""

from __future__ import annotations

import io
from typing import Any
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    KeepTogether,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from app.models import Report

SEVERITY_COLORS = {
    "critical": colors.HexColor("#be123c"),
    "high": colors.HexColor("#c2410c"),
    "medium": colors.HexColor("#a16207"),
    "low": colors.HexColor("#1d4ed8"),
    "info": colors.HexColor("#475569"),
}


def _styles() -> dict[str, ParagraphStyle]:
    base = getSampleStyleSheet()
    return {
        "title": ParagraphStyle("t", parent=base["Title"], fontSize=20, leading=24, alignment=TA_LEFT, spaceAfter=6),
        "h1": ParagraphStyle(
            "h1",
            parent=base["Heading1"],
            fontSize=14,
            leading=18,
            spaceBefore=10,
            spaceAfter=6,
            textColor=colors.HexColor("#0f172a"),
        ),
        "h2": ParagraphStyle("h2", parent=base["Heading2"], fontSize=11, leading=14, spaceBefore=8, spaceAfter=4),
        "body": ParagraphStyle("b", parent=base["BodyText"], fontSize=9, leading=12.5),
        "small": ParagraphStyle(
            "s", parent=base["BodyText"], fontSize=7.5, leading=10, textColor=colors.HexColor("#475569")
        ),
        "cell": ParagraphStyle("c", parent=base["BodyText"], fontSize=7.5, leading=9.5),
    }


def _p(text: Any, style: ParagraphStyle) -> Paragraph:
    return Paragraph(escape(str(text if text is not None else "—")).replace("\n", "<br/>"), style)


def _table(rows: list[list[Any]], widths: list[float], s: dict[str, ParagraphStyle]) -> Table:
    data = [[_p(c, s["cell"]) if not isinstance(c, Paragraph) else c for c in row] for row in rows]
    table = Table(data, colWidths=widths, repeatRows=1)
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e2e8f0")),
                ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#cbd5e1")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 3),
                ("RIGHTPADDING", (0, 0), (-1, -1), 3),
            ]
        )
    )
    return table


def render(report: Report) -> bytes:
    s = _styles()
    content, narrative = report.content, report.narrative
    inv = content["investigation"]
    approved = report.status == "approved"
    banner = (
        f"APPROVED by {report.reviewed_by.email if report.reviewed_by else 'reviewer'}"
        if approved
        else f"{report.status.upper().replace('_', ' ')} — NOT YET APPROVED BY A REVIEWER"
    )
    buffer = io.BytesIO()

    def decorate(canvas, doc) -> None:  # type: ignore[no-untyped-def]
        canvas.saveState()
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(colors.HexColor("#64748b"))
        canvas.drawString(15 * mm, 10 * mm, f"Cyber Monkey · {inv['reference']} · report v{report.version} · {banner}")
        canvas.drawRightString(195 * mm, 10 * mm, f"Page {doc.page}")
        if not approved:
            canvas.setFont("Helvetica-Bold", 60)
            canvas.setFillColor(colors.Color(0.8, 0.1, 0.1, alpha=0.08))
            canvas.translate(105 * mm, 150 * mm)
            canvas.rotate(35)
            canvas.drawCentredString(0, 0, "DRAFT")
        canvas.restoreState()

    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=15 * mm,
        rightMargin=15 * mm,
        topMargin=15 * mm,
        bottomMargin=18 * mm,
        title=report.title,
        author="Cyber Monkey",
    )
    story: list[Any] = [
        _p(report.title, s["title"]),
        _p(f"{inv['reference']} · {inv['title']}", s["h2"]),
        _p(
            f"Generated {content['generated_at']} by {content['generated_by']} · version {report.version} · "
            f"status {report.status} · narrative: {narrative.get('generated_with', report.generation_mode)}"
            + (f" ({report.llm_provider} {report.llm_model})" if report.llm_provider else ""),
            s["small"],
        ),
        _p(banner, s["small"]),
    ]
    if inv.get("is_demo"):
        story.append(_p("DEMONSTRATION DATA — generated from bundled sample files.", s["small"]))
    if narrative.get("citation_issues"):
        story.append(_p("Citation check: " + "; ".join(narrative["citation_issues"]), s["small"]))
    story.append(Spacer(1, 6))

    story += [_p("1. Executive Summary", s["h1"]), _p(narrative.get("executive_summary", ""), s["body"])]
    story += [
        _p("2. Technical Findings", s["h1"]),
        _p(narrative.get("technical_findings", ""), s["body"]),
        Spacer(1, 4),
    ]
    rows = [["ID", "Severity", "Finding", "Asset", "Source", "Validation"]]
    for f in content["findings"]:
        rows.append(
            [
                f["cite"],
                Paragraph(
                    f"<font color='{SEVERITY_COLORS.get(f['severity'], colors.black).hexval()}'><b>{f['severity'].upper()}</b></font>",
                    s["cell"],
                ),
                f["title"],
                f["affected_asset"],
                f"{f['source_tool']} ({f['origin']})",
                f["validation_status"],
            ]
        )
    if len(rows) > 1:
        story.append(_table(rows, [21 * mm, 17 * mm, 56 * mm, 34 * mm, 32 * mm, 20 * mm], s))
    for f in content["findings"][:40]:
        block = [_p(f"{f['cite']} — {f['title']}", s["h2"]), _p(f["description"] or "No description.", s["body"])]
        if f["evidence_refs"]:
            block.append(
                _p(
                    "Evidence: "
                    + "; ".join(
                        f"{r.get('evidence_id', '')[:8]} @ {r.get('locator', '')}" for r in f["evidence_refs"][:5]
                    ),
                    s["small"],
                )
            )
        if f["references"]:
            block.append(
                _p("References: " + "; ".join(f"{r['id']} ({r['validation']})" for r in f["references"]), s["small"])
            )
        if f["indicators"]:
            block.append(
                _p("Indicators: " + ", ".join(f"{i['type']}:{i['value']}" for i in f["indicators"][:10]), s["small"])
            )
        story.append(KeepTogether(block))

    story += [_p("3. Risk Assessment", s["h1"]), _p(narrative.get("risk_assessment", ""), s["body"]), Spacer(1, 4)]
    risk = content["risk"]
    rrows = [["Component", "Weight", "Value", "Status", "Basis"]]
    for c in risk["components"]:
        rrows.append(
            [c["label"], c["weight"], c["value"] if c["value"] is not None else "—", c["status"], c["explanation"]]
        )
    rrows.append(
        [
            "Combined S",
            "",
            risk["score"] if risk["score"] is not None else "—",
            f"coverage {risk['coverage']}",
            f"range {risk['lower_bound']}–{risk['upper_bound']}. {risk['interpretation']}",
        ]
    )
    story.append(_table(rrows, [32 * mm, 14 * mm, 14 * mm, 22 * mm, 98 * mm], s))
    if content["cve_references"]:
        story.append(_p("CVE references", s["h2"]))
        story.append(
            _table(
                [["CVE", "CVSS", "Validation", "Findings"]]
                + [
                    [
                        c["id"],
                        c.get("cvss") if c.get("cvss") is not None else "not enriched",
                        c["validation"],
                        ", ".join(c["finding_ids"]),
                    ]
                    for c in content["cve_references"]
                ],
                [35 * mm, 25 * mm, 30 * mm, 90 * mm],
                s,
            )
        )
    if content["attack_references"]:
        story.append(_p("MITRE ATT&CK techniques", s["h2"]))
        story.append(
            _table(
                [["Technique", "Name", "Tactics", "Validation", "Findings"]]
                + [
                    [t["id"], t["title"], ", ".join(t.get("tactics", [])), t["validation"], ", ".join(t["finding_ids"])]
                    for t in content["attack_references"]
                ],
                [22 * mm, 48 * mm, 40 * mm, 22 * mm, 48 * mm],
                s,
            )
        )

    story += [_p("4. Recommended Mitigations", s["h1"])]
    for index, m in enumerate(narrative.get("recommended_mitigations", []), start=1):
        story.append(_p(f"{index}. {m.get('text', '')}  [{', '.join(m.get('finding_ids', []))}]", s["body"]))
    if not narrative.get("recommended_mitigations"):
        story.append(_p("No mitigations could be derived from the recorded evidence.", s["body"]))

    story += [PageBreak(), _p("Appendix A — Scope", s["h1"]), _p(content["scope"]["description"], s["body"])]
    if content["scope"]["authorized_targets"]:
        story.append(
            _table(
                [["Type", "Target", "Authorization", "Authorized by"]]
                + [
                    [t["type"], t["value"], t["authorization"], t["authorized_by"]]
                    for t in content["scope"]["authorized_targets"]
                ],
                [18 * mm, 40 * mm, 82 * mm, 40 * mm],
                s,
            )
        )
    story += [_p("Appendix B — Data sources", s["h1"])]
    if content["data_sources"]["tool_runs"]:
        story.append(
            _table(
                [["Run", "Tool", "Status", "Requested / approved", "Finished"]]
                + [
                    [
                        r["id"][:8],
                        r["tool"],
                        r["status"],
                        f"{r['requested_by']} / {r['approved_by'] or '—'}",
                        r["finished_at"],
                    ]
                    for r in content["data_sources"]["tool_runs"]
                ],
                [18 * mm, 45 * mm, 22 * mm, 55 * mm, 40 * mm],
                s,
            )
        )
    if content["data_sources"]["evidence"]:
        story.append(Spacer(1, 4))
        story.append(
            _table(
                [["Evidence", "Kind", "SHA-256", "Acquired"]]
                + [
                    [e["filename"], e["kind"], e["sha256"], e["acquired_at"]]
                    for e in content["data_sources"]["evidence"]
                ],
                [45 * mm, 25 * mm, 80 * mm, 30 * mm],
                s,
            )
        )
    story += [_p("Appendix C — Limitations and missing information", s["h1"])]
    for item in content["limitations"] or ["None recorded."]:
        story.append(_p(f"• {item}", s["body"]))
    story += [_p("Appendix D — Analyst notes and review", s["h1"])]
    if report.analyst_notes:
        story.append(_p(report.analyst_notes, s["body"]))
    for n in content["analyst_notes"]:
        story.append(
            _p(f"{n['at']} {n['author']}{' on ' + n['finding'] if n['finding'] else ''}: {n['body']}", s["small"])
        )
    story.append(
        _p(
            f"Review status: {report.status}"
            + (f" by {report.reviewed_by.email} at {report.reviewed_at}" if report.reviewed_by else "")
            + (f". Comment: {report.review_comment}" if report.review_comment else ""),
            s["body"],
        )
    )
    doc.build(story, onFirstPage=decorate, onLaterPages=decorate)
    return buffer.getvalue()
