"""Risk scoring (IEEE paper, Eq. 2):  S = w_c·C(F) + w_m·M(F) + w_i·I(F)

F is the investigation's active finding set (excluding findings marked false positive
or rejected by an analyst). Every component is normalized to [0, 1]:

* C(F) — highest CVSS base score / 10 among CVE references that the evidence supports
  (validation ``supported`` or ``confirmed``) and that have been enriched from NVD.
* M(F) — highest tactic weight among supported/confirmed ATT&CK technique references
  (tactic weights in app/services/attack.py; a documented heuristic, not an ATT&CK
  property).
* I(F) — min(1, correlated indicators / 5), where an indicator is correlated if it links
  findings across workspaces or investigations (app/services/correlation.py).

Weights start equal (1/3 each). A component with no data is reported as *missing*: it is
not counted as zero. The headline score is renormalized over the components that were
evaluated, and the bounds show the range the score could take once the missing
components are known (missing = 0 gives the lower bound, missing = 1 the upper bound).
The score is a prioritization aid, not a probability that an attack occurred."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Finding, FindingReference, Investigation, RiskAssessment, ThreatIntelReference, User
from app.services import attack
from app.services.correlation import investigation_correlations

WEIGHTS = {"cve": 1 / 3, "attack": 1 / 3, "ioc": 1 / 3}
IOC_SATURATION = 5
SUPPORTED = ("supported", "confirmed")


@dataclass
class Component:
    key: str
    label: str
    value: float | None
    status: str  # evaluated | missing
    explanation: str
    contributors: list[dict[str, Any]]
    excluded: list[dict[str, Any]]

    def as_dict(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "label": self.label,
            "value": self.value,
            "status": self.status,
            "weight": round(WEIGHTS[self.key], 4),
            "explanation": self.explanation,
            "contributors": self.contributors,
            "excluded": self.excluded,
        }


def _reference_rows(db: Session, investigation_id, ref_type: str):  # type: ignore[no-untyped-def]
    return db.execute(
        select(FindingReference, ThreatIntelReference, Finding)
        .join(ThreatIntelReference, ThreatIntelReference.id == FindingReference.reference_id)
        .join(Finding, Finding.id == FindingReference.finding_id)
        .where(
            Finding.investigation_id == investigation_id,
            Finding.status != "false_positive",
            Finding.validation_status != "rejected",
            ThreatIntelReference.ref_type == ref_type,
        )
    ).all()


def cve_component(db: Session, investigation: Investigation) -> Component:
    rows = _reference_rows(db, investigation.id, "cve")
    contributors, excluded = [], []
    best: float | None = None
    for link, ref, finding in rows:
        item = {
            "reference": ref.external_id,
            "finding_id": str(finding.id),
            "finding": finding.title,
            "validation": link.validation_status,
        }
        if link.validation_status not in SUPPORTED:
            excluded.append({**item, "reason": f"validation is '{link.validation_status}'"})
        elif ref.cvss_score is None:
            excluded.append({**item, "reason": "not enriched from NVD (no CVSS score yet)"})
        else:
            contributors.append({**item, "cvss": ref.cvss_score, "severity": ref.severity})
            best = max(best or 0.0, ref.cvss_score)
    if best is None:
        reason = (
            "CVE references exist but none are both evidence-supported and enriched with a CVSS score."
            if rows
            else "No findings reference a CVE."
        )
        return Component("cve", "C(F) CVE severity", None, "missing", reason, contributors, excluded)
    top = max(contributors, key=lambda c: c["cvss"])
    return Component(
        "cve",
        "C(F) CVE severity",
        round(best / 10, 4),
        "evaluated",
        f"Highest supported CVSS base score is {best} ({top['reference']}), normalized as {best}/10.",
        sorted(contributors, key=lambda c: -c["cvss"])[:20],
        excluded[:20],
    )


def attack_component(db: Session, investigation: Investigation) -> Component:
    rows = _reference_rows(db, investigation.id, "attack_technique")
    contributors, excluded = [], []
    best: float | None = None
    for link, ref, finding in rows:
        item = {
            "reference": ref.external_id,
            "name": ref.title,
            "finding_id": str(finding.id),
            "finding": finding.title,
            "validation": link.validation_status,
        }
        if link.validation_status not in SUPPORTED:
            excluded.append({**item, "reason": f"validation is '{link.validation_status}'"})
            continue
        technique = attack.lookup(ref.external_id)
        tactics = list(technique.tactics) if technique else list(ref.data.get("tactics", []))
        weight = max((attack.TACTIC_WEIGHTS.get(t, 0.0) for t in tactics), default=0.0)
        contributors.append({**item, "tactics": tactics, "tactic_weight": weight})
        best = max(best or 0.0, weight)
    if best is None:
        reason = (
            "ATT&CK references exist but none are evidence-supported."
            if rows
            else "No findings map to an ATT&CK technique."
        )
        return Component("attack", "M(F) ATT&CK mapping", None, "missing", reason, contributors, excluded)
    top = max(contributors, key=lambda c: c["tactic_weight"])
    return Component(
        "attack",
        "M(F) ATT&CK mapping",
        round(best, 4),
        "evaluated",
        f"Highest tactic weight is {best} from {top['reference']} {top['name']} ({', '.join(top['tactics'])}).",
        sorted(contributors, key=lambda c: -c["tactic_weight"])[:20],
        excluded[:20],
    )


def ioc_component(db: Session, investigation: Investigation, user: User) -> Component:
    correlations = investigation_correlations(db, investigation, user)
    if not correlations:
        return Component(
            "ioc", "I(F) correlated indicators", None, "missing", "No findings carry indicators of compromise.", [], []
        )
    correlated = [c for c in correlations if c.correlated]
    value = min(1.0, len(correlated) / IOC_SATURATION)
    contributors = [
        {
            "indicator": f"{c.type}:{c.value}",
            "reasons": c.reasons(),
            "finding_ids": [str(f) for f in c.finding_ids[:10]],
        }
        for c in correlated[:20]
    ]
    return Component(
        "ioc",
        "I(F) correlated indicators",
        round(value, 4),
        "evaluated",
        f"{len(correlated)} of {len(correlations)} indicator(s) are correlated across workspaces or investigations; "
        f"normalized as min(1, {len(correlated)}/{IOC_SATURATION}). Correlation is not a maliciousness verdict.",
        contributors,
        [],
    )


def compute(db: Session, investigation: Investigation, user: User) -> RiskAssessment:
    components = [
        cve_component(db, investigation),
        attack_component(db, investigation),
        ioc_component(db, investigation, user),
    ]
    evaluated = [c for c in components if c.status == "evaluated"]
    weighted = sum(WEIGHTS[c.key] * (c.value or 0.0) for c in evaluated)
    coverage = sum(WEIGHTS[c.key] for c in evaluated)
    missing_weight = sum(WEIGHTS[c.key] for c in components if c.status == "missing")
    score = round(weighted / coverage, 4) if coverage else None
    finding_count = len(
        db.scalars(
            select(Finding.id).where(
                Finding.investigation_id == investigation.id,
                Finding.status != "false_positive",
                Finding.validation_status != "rejected",
            )
        ).all()
    )
    assessment = RiskAssessment(
        investigation_id=investigation.id,
        score=score,
        lower_bound=round(weighted, 4),
        upper_bound=round(weighted + missing_weight, 4),
        coverage=round(coverage, 4),
        finding_count=finding_count,
        weights={k: round(v, 4) for k, v in WEIGHTS.items()},
        components={
            "formula": "S = w_c*C(F) + w_m*M(F) + w_i*I(F)",
            "items": [c.as_dict() for c in components],
            "missing": [c.key for c in components if c.status == "missing"],
            "interpretation": "Prioritization aid on a 0–1 scale; not a calibrated probability of compromise.",
        },
        computed_by_id=user.id,
    )
    db.add(assessment)
    db.flush()
    return assessment


def latest(db: Session, investigation_id) -> RiskAssessment | None:  # type: ignore[no-untyped-def]
    return db.scalar(
        select(RiskAssessment)
        .where(RiskAssessment.investigation_id == investigation_id)
        .order_by(RiskAssessment.computed_at.desc())
        .limit(1)
    )
