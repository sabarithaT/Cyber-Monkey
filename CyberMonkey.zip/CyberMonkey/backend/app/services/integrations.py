"""Integration catalogue and availability checks.

Every optional capability (tool binaries, external APIs, AI providers, sandboxes) is
declared here with a check that reports, honestly, whether it can be used right now
and how to configure it if not. Secrets come only from environment variables; the
database holds the enabled flag and non-secret settings."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import Settings, get_settings
from app.models import IntegrationConfig


@dataclass(frozen=True)
class Availability:
    available: bool
    status: str  # available | not_configured | disabled
    detail: str


@dataclass(frozen=True)
class IntegrationSpec:
    key: str
    label: str
    category: str  # tool | intel | osint | ai | sandbox
    description: str
    configure: str
    check: Callable[[Settings], Availability]
    secret_env_var: str | None = None


def _ok(detail: str) -> Availability:
    return Availability(True, "available", detail)


def _missing(detail: str) -> Availability:
    return Availability(False, "not_configured", detail)


def _outbound_check(label: str) -> Callable[[Settings], Availability]:
    def check(s: Settings) -> Availability:
        if not s.outbound_network_enabled:
            return _missing("Outbound network access is disabled (OUTBOUND_NETWORK_ENABLED=false)")
        return _ok(f"{label} is a public service; reachability is checked when used")

    return check


def _gemini_check(s: Settings) -> Availability:
    if s.ai_provider != "gemini":
        return _missing(f"AI_PROVIDER is '{s.ai_provider}', not 'gemini'")
    if s.gemini_api_key is None or not s.gemini_api_key.get_secret_value():
        return _missing("GEMINI_API_KEY is not set")
    return _ok(f"Gemini model '{s.gemini_model}' configured")


def _ollama_check(s: Settings) -> Availability:
    if s.ai_provider != "ollama":
        return _missing(f"AI_PROVIDER is '{s.ai_provider}', not 'ollama'")
    return _ok(f"Ollama at {s.ollama_base_url}, model '{s.ollama_model}' (reachability checked when used)")


def _attack_dataset_check(s: Settings) -> Availability:
    if s.attack_dataset_path.is_file():
        return _ok(f"Full ATT&CK dataset at {s.attack_dataset_path}")
    return _missing("Full ATT&CK STIX dataset not downloaded; the built-in reference subset is used instead")


CATALOG: list[IntegrationSpec] = [
    IntegrationSpec(
        "findings_import",
        "Structured findings import",
        "tool",
        "Imports results exported by your own authorized tooling in the cybermonkey-findings/v1 JSON format.",
        "No configuration needed: upload the export as evidence and run the workspace's import tool.",
        lambda s: _ok("Built in"),
    ),
    IntegrationSpec(
        "nvd",
        "NVD CVE API",
        "intel",
        "CVE details and CVSS scores from NIST NVD.",
        "Works without a key at a low rate limit; set NVD_API_KEY for a higher limit.",
        _outbound_check("NVD"),
        secret_env_var="NVD_API_KEY",
    ),
    IntegrationSpec(
        "attack_dataset",
        "MITRE ATT&CK dataset",
        "intel",
        "Full Enterprise ATT&CK technique catalogue.",
        "Run `python scripts/fetch_attack.py` to download enterprise-attack.json into backend/data/.",
        _attack_dataset_check,
    ),
    IntegrationSpec(
        "gemini",
        "Google Gemini",
        "ai",
        "LLM provider for routing, explanations and report prose.",
        "Set AI_PROVIDER=gemini and GEMINI_API_KEY (optionally GEMINI_MODEL).",
        _gemini_check,
        secret_env_var="GEMINI_API_KEY",
    ),
    IntegrationSpec(
        "ollama",
        "Ollama (local LLM)",
        "ai",
        "Locally hosted LLM; keeps prompts on your machine.",
        "Install Ollama, `ollama pull <model>`, set AI_PROVIDER=ollama and OLLAMA_MODEL.",
        _ollama_check,
    ),
]

SPECS = {spec.key: spec for spec in CATALOG}


def ensure_integration_rows(db: Session) -> None:
    have = {row.key for row in db.scalars(select(IntegrationConfig))}
    for spec in CATALOG:
        if spec.key not in have:
            db.add(IntegrationConfig(key=spec.key, enabled=True, settings={}, secret_env_var=spec.secret_env_var))
    db.flush()


def availability(db: Session | None, key: str, *, record: bool = False) -> Availability:
    spec = SPECS[key]
    row = db.scalar(select(IntegrationConfig).where(IntegrationConfig.key == key)) if db is not None else None
    if row is not None and not row.enabled:
        result = Availability(False, "disabled", "Disabled by an administrator")
    else:
        result = spec.check(get_settings())
    if record and row is not None:
        row.last_check_status = result.status
        row.last_check_detail = result.detail
        row.last_checked_at = datetime.now(UTC)
    return result
