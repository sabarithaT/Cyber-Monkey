"""Investigation queries and helpers."""

from __future__ import annotations

import ipaddress
import uuid
from datetime import UTC, datetime

from sqlalchemy import func, select, text
from sqlalchemy.orm import Session

from app.core.constants import Severity
from app.models import Evidence, Finding, Investigation, InvestigationMember, ScopeTarget, ToolRun, User
from app.schemas.common import UserRef
from app.schemas.investigations import (
    InvestigationDetail,
    InvestigationSummary,
    MemberOut,
    ScopeTargetOut,
    SeverityCounts,
)
from app.services import authz


def next_reference(db: Session) -> str:
    number = db.execute(text("SELECT nextval('investigation_reference_seq')")).scalar_one()
    return f"INV-{datetime.now(UTC).year}-{number:04d}"


def severity_counts(db: Session, investigation_ids: list[uuid.UUID]) -> dict[uuid.UUID, SeverityCounts]:
    out = {i: SeverityCounts() for i in investigation_ids}
    if not investigation_ids:
        return out
    rows = db.execute(
        select(Finding.investigation_id, Finding.severity, func.count())
        .where(Finding.investigation_id.in_(investigation_ids), Finding.status != "false_positive")
        .group_by(Finding.investigation_id, Finding.severity)
    ).all()
    for inv_id, severity, count in rows:
        setattr(out[inv_id], severity, count)
    return out


def _counts(db: Session, model, ids: list[uuid.UUID]) -> dict[uuid.UUID, int]:  # type: ignore[no-untyped-def]
    if not ids:
        return {}
    rows = db.execute(
        select(model.investigation_id, func.count())
        .where(model.investigation_id.in_(ids))
        .group_by(model.investigation_id)
    ).all()
    return dict(rows)


def summaries(db: Session, investigations: list[Investigation]) -> list[InvestigationSummary]:
    ids = [i.id for i in investigations]
    sev = severity_counts(db, ids)
    runs = _counts(db, ToolRun, ids)
    evidence = _counts(db, Evidence, ids)
    return [
        InvestigationSummary(
            id=i.id,
            reference=i.reference,
            title=i.title,
            primary_workspace=i.primary_workspace,
            status=i.status,
            is_demo=i.is_demo,
            owner=UserRef.model_validate(i.owner),
            created_at=i.created_at,
            updated_at=i.updated_at,
            finding_counts=sev[i.id],
            run_count=runs.get(i.id, 0),
            evidence_count=evidence.get(i.id, 0),
        )
        for i in investigations
    ]


def scope_target_active(target: ScopeTarget, now: datetime | None = None) -> bool:
    now = now or datetime.now(UTC)
    if target.valid_from and target.valid_from > now:
        return False
    return not (target.valid_until and target.valid_until < now)


def access_level(db: Session, inv: Investigation, user: User) -> str:
    if inv.owner_id == user.id:
        return "owner"
    member = db.scalar(
        select(InvestigationMember).where(
            InvestigationMember.investigation_id == inv.id, InvestigationMember.user_id == user.id
        )
    )
    if member is not None:
        return member.access_level
    return "manager" if authz.has_permission(user, "investigations:manage_all") else "viewer"


def detail(db: Session, inv: Investigation, user: User) -> InvestigationDetail:
    base = summaries(db, [inv])[0]
    now = datetime.now(UTC)
    return InvestigationDetail(
        **base.model_dump(),
        description=inv.description,
        closed_at=inv.closed_at,
        members=[
            MemberOut(user=UserRef.model_validate(m.user), access_level=m.access_level, added_at=m.added_at)
            for m in inv.members
        ],
        scope_targets=[
            ScopeTargetOut(
                id=t.id,
                target_type=t.target_type,
                value=t.value,
                authorization_reference=t.authorization_reference,
                authorized_by=UserRef.model_validate(t.authorized_by),
                valid_from=t.valid_from,
                valid_until=t.valid_until,
                notes=t.notes,
                created_at=t.created_at,
                active=scope_target_active(t, now),
            )
            for t in sorted(inv.scope_targets, key=lambda t: t.created_at)
        ],
        my_access=access_level(db, inv, user),  # type: ignore[arg-type]
    )


class ScopeViolation(Exception):
    pass


def target_in_scope(db: Session, investigation_id: uuid.UUID, target: str) -> ScopeTarget:
    """Return the active scope entry covering ``target`` or raise ScopeViolation.

    An IP is covered by an equal ``ip`` entry or a containing ``cidr`` entry. A CIDR
    target must be entirely inside a ``cidr`` entry. A hostname must match a ``hostname``
    entry exactly (no wildcard expansion)."""
    targets = [
        t
        for t in db.scalars(select(ScopeTarget).where(ScopeTarget.investigation_id == investigation_id))
        if scope_target_active(t)
    ]
    value = target.strip().lower()
    for t in targets:
        if _covers(t, value):
            return t
    raise ScopeViolation(f"Target '{target}' is not covered by an active authorized scope entry for this investigation")


def _covers(entry: ScopeTarget, value: str) -> bool:
    try:
        if "/" in value:
            net = ipaddress.ip_network(value, strict=False)
            if entry.target_type == "cidr":
                scope = ipaddress.ip_network(entry.value)
                return net.version == scope.version and net.subnet_of(scope)  # type: ignore[arg-type]
            if entry.target_type == "ip":
                return net.num_addresses == 1 and net.network_address == ipaddress.ip_address(entry.value)
            return False
        try:
            ip = ipaddress.ip_address(value)
        except ValueError:
            return entry.target_type == "hostname" and entry.value == value
        if entry.target_type == "ip":
            return ip == ipaddress.ip_address(entry.value)
        if entry.target_type == "cidr":
            return ip in ipaddress.ip_network(entry.value)
        return False
    except ValueError:
        return False


SEVERITY_VALUES = [s.value for s in Severity]
