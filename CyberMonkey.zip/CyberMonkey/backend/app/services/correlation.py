"""Cross-workspace and cross-investigation indicator correlation.

An indicator is *correlated* when it is linked to findings from two or more workspaces
in the same investigation, or to findings in another investigation the requesting user
can access. Correlation is a prioritization signal: it says "these observations share an
indicator", never "this indicator is malicious"."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Finding, FindingIndicator, Indicator, Investigation, User
from app.services import authz
from app.services import indicators as ioc


@dataclass
class IndicatorCorrelation:
    indicator_id: uuid.UUID
    type: str
    value: str
    is_internal: bool
    workspaces: list[str]
    finding_ids: list[uuid.UUID]
    other_investigations: list[dict[str, str]] = field(default_factory=list)

    @property
    def cross_workspace(self) -> bool:
        return len(self.workspaces) >= 2

    @property
    def cross_investigation(self) -> bool:
        return bool(self.other_investigations)

    @property
    def correlated(self) -> bool:
        return self.cross_workspace or self.cross_investigation

    def reasons(self) -> list[str]:
        out = []
        if self.cross_workspace:
            out.append(f"seen in {len(self.workspaces)} workspaces ({', '.join(self.workspaces)})")
        if self.cross_investigation:
            refs = ", ".join(i["reference"] for i in self.other_investigations[:5])
            out.append(f"also seen in {len(self.other_investigations)} other investigation(s): {refs}")
        return out


def _active_findings(investigation_id: uuid.UUID):  # type: ignore[no-untyped-def]
    return (
        Finding.investigation_id == investigation_id,
        Finding.status != "false_positive",
        Finding.validation_status != "rejected",
    )


def investigation_correlations(db: Session, investigation: Investigation, user: User) -> list[IndicatorCorrelation]:
    rows = db.execute(
        select(Indicator, Finding.id, Finding.workspace)
        .join(FindingIndicator, FindingIndicator.indicator_id == Indicator.id)
        .join(Finding, Finding.id == FindingIndicator.finding_id)
        .where(*_active_findings(investigation.id))
    ).all()
    by_indicator: dict[uuid.UUID, IndicatorCorrelation] = {}
    for indicator, finding_id, workspace in rows:
        entry = by_indicator.get(indicator.id)
        if entry is None:
            normalized = ioc.normalize(indicator.type, indicator.value)
            entry = IndicatorCorrelation(
                indicator_id=indicator.id,
                type=indicator.type,
                value=indicator.value,
                is_internal=bool(normalized and normalized.is_internal),
                workspaces=[],
                finding_ids=[],
            )
            by_indicator[indicator.id] = entry
        if workspace not in entry.workspaces:
            entry.workspaces.append(workspace)
        entry.finding_ids.append(finding_id)
    if not by_indicator:
        return []
    visible = authz.investigation_visibility_clause(user)
    elsewhere = db.execute(
        select(FindingIndicator.indicator_id, Investigation.id, Investigation.reference)
        .join(Finding, Finding.id == FindingIndicator.finding_id)
        .join(Investigation, Investigation.id == Finding.investigation_id)
        .where(
            FindingIndicator.indicator_id.in_(list(by_indicator)),
            Investigation.id != investigation.id,
            Finding.status != "false_positive",
            visible,
        )
        .distinct()
    ).all()
    for indicator_id, inv_id, reference in elsewhere:
        others = by_indicator[indicator_id].other_investigations
        if not any(o["id"] == str(inv_id) for o in others):
            others.append({"id": str(inv_id), "reference": reference})
    return sorted(by_indicator.values(), key=lambda c: (not c.correlated, -len(c.finding_ids), c.value))
