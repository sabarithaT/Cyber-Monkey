"""Demonstration investigation built from bundled sample files.

The investigation is flagged ``is_demo`` and labelled as demo data everywhere it is
shown. The sample exports use documentation address ranges (RFC 5737) and example
domains, and every finding description starts with "DEMO". They are processed through
the normal pipeline: evidence upload, approval-free import tools, normalization,
correlation and risk scoring."""

from __future__ import annotations

from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.constants import EvidenceKind
from app.models import Investigation
from app.services import audit, risk
from app.services import evidence as evidence_svc
from app.services import runs as run_svc
from app.services.identity import get_user_by_email
from app.services.investigations import next_reference

DEMO_DIR = Path(__file__).resolve().parents[1] / "data" / "demo"
DEMO_TITLE = "DEMO — Web portal exposure and suspicious traffic"

SAMPLES = [
    ("pentest_export.json", EvidenceKind.SCAN_REPORT, "pentest_findings_import"),
    ("network_export.json", EvidenceKind.IDS_ALERTS, "network_findings_import"),
]


def seed_demo(db: Session, *, owner_email: str) -> str:
    owner = get_user_by_email(db, owner_email)
    if owner is None:
        raise SystemExit(f"No user {owner_email}; create the user first")
    existing = db.scalar(
        select(Investigation).where(Investigation.is_demo.is_(True), Investigation.owner_id == owner.id)
    )
    if existing:
        return f"Demo investigation already exists: {existing.reference}"
    inv = Investigation(
        reference=next_reference(db),
        title=DEMO_TITLE,
        description=(
            "Demonstration data generated from sample files bundled with Cyber Monkey. "
            "Assets use documentation address ranges and example domains; nothing here describes a real system."
        ),
        primary_workspace="pentest",
        owner_id=owner.id,
        is_demo=True,
    )
    db.add(inv)
    db.flush()
    audit.record(
        db,
        action="investigation.create",
        actor=owner,
        resource_type="investigation",
        resource_id=inv.id,
        details={"reference": inv.reference, "demo": True, "via": "cli seed-demo"},
    )
    run_ids = []
    for filename, kind, tool in SAMPLES:
        with open(DEMO_DIR / filename, "rb") as fh:
            ev = evidence_svc.store_upload(
                db,
                investigation_id=inv.id,
                kind=kind,
                stream=fh,
                filename=filename,
                uploaded_by=owner,
                source_description="Bundled Cyber Monkey demonstration sample (not real data)",
            )
        run = run_svc.request_run(
            db, user=owner, investigation=inv, tool_name=tool, raw_args={"evidence_id": str(ev.id)}
        )
        run_ids.append(run.id)
    db.commit()
    for run_id in run_ids:
        run_svc.execute(run_id)
    db.refresh(inv)
    risk.compute(db, inv, owner)
    return f"Demo investigation {inv.reference} created for {owner.email}"
