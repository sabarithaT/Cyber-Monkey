"""Controlled outbound HTTP.

All calls to external services go through ``outbound_client`` which enforces the global
OUTBOUND_NETWORK_ENABLED switch, a per-integration host allowlist, HTTPS, timeouts and a
response-size cap. Tool code never builds URLs to arbitrary hosts."""

from __future__ import annotations

from urllib.parse import urlsplit

import httpx

from app.core.config import get_settings
from app.core.errors import IntegrationUnavailable

MAX_RESPONSE_BYTES = 10 * 1024 * 1024


class OutboundBlocked(IntegrationUnavailable):
    pass


def outbound_client(allowed_hosts: set[str], *, headers: dict[str, str] | None = None) -> httpx.Client:
    settings = get_settings()
    if not settings.outbound_network_enabled:
        raise OutboundBlocked("Outbound network access is disabled (OUTBOUND_NETWORK_ENABLED=false)")

    def check(request: httpx.Request) -> None:
        host = (request.url.host or "").lower()
        if request.url.scheme != "https":
            raise OutboundBlocked(f"Refusing non-HTTPS request to {host}")
        if host not in allowed_hosts:
            raise OutboundBlocked(f"Host {host} is not on this integration's allowlist")

    def cap(response: httpx.Response) -> None:
        length = response.headers.get("content-length")
        if length and int(length) > MAX_RESPONSE_BYTES:
            response.close()
            raise OutboundBlocked("Response too large")

    return httpx.Client(
        timeout=httpx.Timeout(settings.http_timeout_seconds),
        headers={"User-Agent": "CyberMonkey/0.1 (+academic security operations platform)", **(headers or {})},
        event_hooks={"request": [check], "response": [cap]},
        follow_redirects=False,
    )


def host_of(url: str) -> str:
    return (urlsplit(url).hostname or "").lower()
