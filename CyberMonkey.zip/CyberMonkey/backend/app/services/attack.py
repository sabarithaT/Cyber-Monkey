"""MITRE ATT&CK technique catalogue.

Uses the full Enterprise STIX bundle when it has been downloaded (scripts/fetch_attack.py)
and otherwise a built-in subset of commonly referenced Enterprise techniques."""

from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from app.core.config import get_settings

SUBSET_PATH = Path(__file__).resolve().parents[1] / "data" / "attack_subset.json"

# Baseline priority weight of each tactic, used for the M(F) term of the risk score. A
# heuristic ordering by how far an intrusion has progressed, documented in
# docs/RISK_SCORING.md; it is not an ATT&CK property and can be tuned.
TACTIC_WEIGHTS: dict[str, float] = {
    "reconnaissance": 0.2,
    "resource-development": 0.2,
    "discovery": 0.35,
    "initial-access": 0.6,
    "defense-evasion": 0.6,
    "execution": 0.65,
    "persistence": 0.65,
    "collection": 0.7,
    "credential-access": 0.75,
    "privilege-escalation": 0.75,
    "lateral-movement": 0.8,
    "command-and-control": 0.85,
    "exfiltration": 0.95,
    "impact": 1.0,
}


@dataclass(frozen=True)
class Technique:
    id: str
    name: str
    tactics: tuple[str, ...]
    url: str
    description: str = ""


@dataclass(frozen=True)
class Catalog:
    source: str
    techniques: dict[str, Technique]
    tactic_names: dict[str, str]


def _from_stix(path: Path) -> Catalog:
    bundle = json.loads(path.read_text(encoding="utf-8"))
    techniques: dict[str, Technique] = {}
    tactic_names: dict[str, str] = {}
    version = "unknown"
    for obj in bundle.get("objects", []):
        kind = obj.get("type")
        if kind == "x-mitre-collection":
            version = obj.get("x_mitre_version", version)
        if obj.get("revoked") or obj.get("x_mitre_deprecated"):
            continue
        refs = [r for r in obj.get("external_references", []) if r.get("source_name") == "mitre-attack"]
        if not refs:
            continue
        if kind == "x-mitre-tactic":
            tactic_names[obj.get("x_mitre_shortname", "")] = obj.get("name", "")
        elif kind == "attack-pattern":
            ext_id = refs[0].get("external_id", "")
            phases = tuple(
                p["phase_name"] for p in obj.get("kill_chain_phases", []) if p.get("kill_chain_name") == "mitre-attack"
            )
            techniques[ext_id] = Technique(
                id=ext_id,
                name=obj.get("name", ""),
                tactics=phases,
                url=refs[0].get("url", f"https://attack.mitre.org/techniques/{ext_id.replace('.', '/')}/"),
                description=(obj.get("description") or "")[:4000],
            )
    return Catalog(source=f"mitre-attack-enterprise-stix-v{version}", techniques=techniques, tactic_names=tactic_names)


def _from_subset() -> Catalog:
    data = json.loads(SUBSET_PATH.read_text(encoding="utf-8"))
    techniques = {
        tid: Technique(id=tid, name=t["name"], tactics=tuple(t["tactics"]), url=t["url"])
        for tid, t in data["techniques"].items()
    }
    return Catalog(
        source=data["source"],
        techniques=techniques,
        tactic_names={k: v["name"] for k, v in data["tactics"].items()},
    )


@lru_cache
def catalog() -> Catalog:
    path = get_settings().attack_dataset_path
    if path.is_file():
        return _from_stix(path)
    return _from_subset()


def lookup(technique_id: str) -> Technique | None:
    return catalog().techniques.get(technique_id.strip().upper())


def tactic_weight(technique: Technique) -> float:
    return max((TACTIC_WEIGHTS.get(t, 0.0) for t in technique.tactics), default=0.0)
