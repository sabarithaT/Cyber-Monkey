"""Threat Intelligence Engine — reference management.

CVE and ATT&CK references attached to findings are cached in ``threat_intel_references``
with their source and fetch time. ATT&CK references come from the local catalogue. CVE
references start as unenriched placeholders (an identifier seen in evidence) and are
filled from NVD by an explicit enrichment step; until then they contribute nothing to
the risk score and are reported as missing data."""

from __future__ import annotations

import re

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import ThreatIntelReference
from app.services import attack

CVE_RE = re.compile(r"\bCVE-(\d{4})-(\d{4,7})\b", re.IGNORECASE)
TECHNIQUE_RE = re.compile(r"^T\d{4}(?:\.\d{3})?$")


def normalize_cve(value: str) -> str | None:
    match = CVE_RE.search(value or "")
    return f"CVE-{match.group(1)}-{match.group(2)}" if match else None


def ensure_reference(db: Session, ref_type: str, external_id: str) -> ThreatIntelReference | None:
    if ref_type == "cve":
        cve = normalize_cve(external_id)
        if cve is None:
            return None
        existing = db.scalar(
            select(ThreatIntelReference).where(
                ThreatIntelReference.ref_type == "cve", ThreatIntelReference.external_id == cve
            )
        )
        if existing:
            return existing
        ref = ThreatIntelReference(
            ref_type="cve",
            external_id=cve,
            title=cve,
            description="",
            url=f"https://nvd.nist.gov/vuln/detail/{cve}",
            source="unenriched",
            data={"enriched": False},
        )
        db.add(ref)
        db.flush()
        return ref
    if ref_type == "attack_technique":
        tid = external_id.strip().upper()
        if not TECHNIQUE_RE.match(tid):
            return None
        existing = db.scalar(
            select(ThreatIntelReference).where(
                ThreatIntelReference.ref_type == "attack_technique", ThreatIntelReference.external_id == tid
            )
        )
        if existing:
            return existing
        technique = attack.lookup(tid)
        if technique is None:
            return None  # unknown technique IDs are never invented
        cat = attack.catalog()
        ref = ThreatIntelReference(
            ref_type="attack_technique",
            external_id=tid,
            title=technique.name,
            description=technique.description,
            url=technique.url,
            source=cat.source,
            data={
                "tactics": list(technique.tactics),
                "tactic_names": [cat.tactic_names.get(t, t) for t in technique.tactics],
            },
        )
        db.add(ref)
        db.flush()
        return ref
    return None
