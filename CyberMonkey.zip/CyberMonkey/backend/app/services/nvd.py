"""CVE enrichment from the NIST National Vulnerability Database (CVE API 2.0)."""

from __future__ import annotations

import logging
import time
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select

from app.core.config import get_settings
from app.core.db import session_factory
from app.models import ThreatIntelReference
from app.services.http import host_of, outbound_client

log = logging.getLogger("cybermonkey.nvd")


def _pick_metric(metrics: dict[str, Any]) -> tuple[float | None, str | None, str | None, str]:
    for key, label in (
        ("cvssMetricV40", "4.0"),
        ("cvssMetricV31", "3.1"),
        ("cvssMetricV30", "3.0"),
        ("cvssMetricV2", "2.0"),
    ):
        entries = metrics.get(key) or []
        if not entries:
            continue
        primary = next((m for m in entries if m.get("type") == "Primary"), entries[0])
        data = primary.get("cvssData", {})
        severity = data.get("baseSeverity") or primary.get("baseSeverity")
        return data.get("baseScore"), (severity or "").lower() or None, data.get("vectorString"), label
    return None, None, None, ""


def parse_cve(payload: dict[str, Any]) -> dict[str, Any] | None:
    vulns = payload.get("vulnerabilities") or []
    if not vulns:
        return None
    cve = vulns[0].get("cve", {})
    description = next((d.get("value", "") for d in cve.get("descriptions", []) if d.get("lang") == "en"), "")
    score, severity, vector, version = _pick_metric(cve.get("metrics", {}))
    return {
        "id": cve.get("id"),
        "description": description,
        "cvss_score": score,
        "severity": severity,
        "cvss_vector": vector,
        "cvss_version": version,
        "published": cve.get("published"),
        "last_modified": cve.get("lastModified"),
        "status": cve.get("vulnStatus"),
        "references": [r.get("url") for r in cve.get("references", [])][:20],
        "weaknesses": [
            d.get("value") for w in cve.get("weaknesses", []) for d in w.get("description", []) if d.get("lang") == "en"
        ][:10],
    }


def enrich(cve_ids: list[str]) -> dict[str, str]:
    """Fetch each CVE from NVD and update its cached reference. Returns id -> outcome."""
    settings = get_settings()
    key = settings.nvd_api_key.get_secret_value() if settings.nvd_api_key else ""
    # Public rate limits: 5 requests / 30 s without a key, 50 / 30 s with one.
    delay = 0.7 if key else 6.5
    outcomes: dict[str, str] = {}
    with outbound_client({host_of(settings.nvd_base_url)}, headers={"apiKey": key} if key else None) as client:
        for index, cve_id in enumerate(cve_ids):
            if index:
                time.sleep(delay)
            try:
                response = client.get(settings.nvd_base_url, params={"cveId": cve_id})
                response.raise_for_status()
                parsed = parse_cve(response.json())
            except Exception as exc:  # network errors are reported per CVE, never invented around
                outcomes[cve_id] = f"error: {str(exc)[:200]}"
                continue
            with session_factory()() as db:
                ref = db.scalar(
                    select(ThreatIntelReference).where(
                        ThreatIntelReference.ref_type == "cve", ThreatIntelReference.external_id == cve_id
                    )
                )
                if ref is None:
                    continue
                if parsed is None:
                    ref.data = {
                        **ref.data,
                        "enriched": False,
                        "nvd_lookup": "not found",
                        "checked_at": datetime.now(UTC).isoformat(),
                    }
                    outcomes[cve_id] = "not found in NVD"
                else:
                    ref.title = cve_id
                    ref.description = parsed["description"]
                    ref.cvss_score = parsed["cvss_score"]
                    ref.cvss_vector = parsed["cvss_vector"]
                    ref.severity = parsed["severity"]
                    ref.source = "nvd"
                    ref.fetched_at = datetime.now(UTC)
                    ref.data = {**parsed, "enriched": True}
                    outcomes[cve_id] = "enriched"
                db.commit()
    return outcomes
