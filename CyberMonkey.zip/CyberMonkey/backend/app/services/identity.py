"""User, role and permission management, and RBAC seeding."""

from __future__ import annotations

import re
import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.constants import DEFAULT_ROLES, all_permissions
from app.core.errors import Conflict, NotFound, ValidationFailed
from app.core.security import hash_password
from app.models import Permission, Role, User, UserPermission, UserRole
from app.schemas.identity import MeOut, RoleOut, RoleSummary, UserOut
from app.services import authz


def ensure_rbac_seed(db: Session) -> None:
    """Create missing permissions and default system roles. Existing roles keep any
    customization an administrator made, except that the Administrator role always
    receives newly introduced permissions."""
    catalog = all_permissions()
    existing = {p.code: p for p in db.scalars(select(Permission))}
    for code, description in catalog.items():
        scope, action = code.split(":", 1)
        perm = existing.get(code)
        if perm is None:
            perm = Permission(code=code, scope=scope, action=action, description=description)
            db.add(perm)
            existing[code] = perm
        else:
            perm.description = description
    db.flush()

    for slug, spec in DEFAULT_ROLES.items():
        role = db.scalar(select(Role).where(Role.slug == slug))
        wanted = [existing[c] for c in spec["permissions"]]  # type: ignore[union-attr]
        if role is None:
            role = Role(
                slug=slug,
                name=str(spec["name"]),
                description=str(spec["description"]),
                is_system=True,
                permissions=wanted,
            )
            db.add(role)
        elif slug == "administrator":
            have = {p.code for p in role.permissions}
            role.permissions.extend(p for p in wanted if p.code not in have)
    db.flush()


def normalize_email(email: str) -> str:
    return email.strip().lower()


def get_user_by_email(db: Session, email: str) -> User | None:
    return db.scalar(select(User).where(User.email == normalize_email(email)))


def create_user(
    db: Session, *, email: str, full_name: str, password: str, role_ids: list[int], actor: User | None
) -> User:
    if get_user_by_email(db, email) is not None:
        raise Conflict("A user with this email already exists")
    user = User(email=normalize_email(email), full_name=full_name, password_hash=hash_password(password))
    db.add(user)
    db.flush()
    set_user_roles(db, user, role_ids, actor)
    return user


def set_user_roles(db: Session, user: User, role_ids: list[int], actor: User | None) -> None:
    roles = list(db.scalars(select(Role).where(Role.id.in_(role_ids)))) if role_ids else []
    if len(roles) != len(set(role_ids)):
        raise ValidationFailed("One or more role IDs do not exist")
    user.role_links.clear()
    db.flush()
    for role in roles:
        user.role_links.append(UserRole(user_id=user.id, role_id=role.id, assigned_by_id=actor.id if actor else None))
    user.token_version += 1  # force re-login so tokens reflect the new authorization
    db.flush()
    db.refresh(user)


def resolve_permissions(db: Session, codes: list[str]) -> list[Permission]:
    perms = list(db.scalars(select(Permission).where(Permission.code.in_(codes)))) if codes else []
    missing = set(codes) - {p.code for p in perms}
    if missing:
        raise ValidationFailed("Unknown permission codes", details=sorted(missing))
    return perms


def set_user_direct_permissions(db: Session, user: User, codes: list[str], actor: User) -> None:
    perms = resolve_permissions(db, codes)
    user.permission_links.clear()
    db.flush()
    for perm in perms:
        user.permission_links.append(UserPermission(user_id=user.id, permission_id=perm.id, granted_by_id=actor.id))
    user.token_version += 1
    db.flush()
    db.refresh(user)


def get_user(db: Session, user_id: uuid.UUID) -> User:
    user = db.get(User, user_id)
    if user is None:
        raise NotFound("User not found")
    return user


def get_role(db: Session, role_id: int) -> Role:
    role = db.get(Role, role_id)
    if role is None:
        raise NotFound("Role not found")
    return role


def slugify(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
    return slug or "role"


def create_role(db: Session, *, name: str, description: str, codes: list[str]) -> Role:
    if db.scalar(select(Role).where(func.lower(Role.name) == name.lower())):
        raise Conflict("A role with this name already exists")
    base = slugify(name)
    slug, n = base, 2
    while db.scalar(select(Role).where(Role.slug == slug)):
        slug, n = f"{base}_{n}", n + 1
    role = Role(
        slug=slug, name=name, description=description, is_system=False, permissions=resolve_permissions(db, codes)
    )
    db.add(role)
    db.flush()
    return role


def bump_role_members(db: Session, role: Role) -> None:
    for user in db.scalars(select(User).join(UserRole, UserRole.user_id == User.id).where(UserRole.role_id == role.id)):
        user.token_version += 1


def user_out(user: User) -> UserOut:
    return UserOut(
        id=user.id,
        email=user.email,
        full_name=user.full_name,
        is_active=user.is_active,
        last_login_at=user.last_login_at,
        created_at=user.created_at,
        roles=[RoleSummary.model_validate(r) for r in user.roles],
        direct_permissions=sorted(link.permission.code for link in user.permission_links),
    )


def me_out(user: User) -> MeOut:
    base = user_out(user).model_dump()
    return MeOut(
        **base,
        permissions=sorted(authz.permissions_of(user)),
        workspaces=[ws.value for ws in authz.permitted_workspaces(user)],
    )


def role_out(db: Session, role: Role) -> RoleOut:
    count = db.scalar(select(func.count()).select_from(UserRole).where(UserRole.role_id == role.id)) or 0
    return RoleOut(
        id=role.id,
        slug=role.slug,
        name=role.name,
        description=role.description,
        is_system=role.is_system,
        permissions=[p.code for p in role.permissions],
        user_count=count,
    )
