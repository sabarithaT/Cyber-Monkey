"""allow scan_report evidence kind

Revision ID: 0003_scan_report_kind
Revises: 0002_run_conversation
Create Date: 2026-10-12
"""

from collections.abc import Sequence

from alembic import op

revision: str = "0003_scan_report_kind"
down_revision: str | None = "0002_run_conversation"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_BASE = (
    "'log', 'pcap', 'ids_alerts', 'malware_sample', 'sandbox_report', 'disk_image', 'memory_image', "
    "'forensic_report', 'tool_output', 'osint_record'"
)


def upgrade() -> None:
    op.drop_constraint(op.f("ck_evidence_kind_valid"), "evidence", type_="check")
    op.create_check_constraint("kind_valid", "evidence", f"kind IN ({_BASE}, 'scan_report', 'other')")


def downgrade() -> None:
    op.execute("DELETE FROM evidence WHERE kind = 'scan_report'")
    op.drop_constraint(op.f("ck_evidence_kind_valid"), "evidence", type_="check")
    op.create_check_constraint("kind_valid", "evidence", f"kind IN ({_BASE}, 'other')")
