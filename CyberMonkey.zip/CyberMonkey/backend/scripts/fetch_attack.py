"""Download the MITRE ATT&CK Enterprise STIX bundle used by the Threat Intelligence Engine.

    python scripts/fetch_attack.py [--url URL] [--out PATH]

The file (~45 MB) is saved to backend/data/enterprise-attack.json (ATTACK_DATASET_PATH).
When present it replaces the built-in technique subset. Restart the backend afterwards.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import httpx

DEFAULT_URL = "https://raw.githubusercontent.com/mitre/cti/master/enterprise-attack/enterprise-attack.json"
DEFAULT_OUT = Path(__file__).resolve().parents[1] / "data" / "enterprise-attack.json"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", default=DEFAULT_URL)
    parser.add_argument("--out", default=str(DEFAULT_OUT))
    args = parser.parse_args()
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    print(f"Downloading {args.url} ...")
    with httpx.Client(timeout=120, follow_redirects=True) as client:
        response = client.get(args.url)
        response.raise_for_status()
    bundle = response.json()
    if bundle.get("type") != "bundle" or not isinstance(bundle.get("objects"), list):
        print("The download is not a STIX bundle; nothing was written.", file=sys.stderr)
        return 1
    patterns = sum(1 for o in bundle["objects"] if o.get("type") == "attack-pattern")
    tmp = out.with_suffix(".tmp")
    tmp.write_text(json.dumps(bundle), encoding="utf-8")
    tmp.replace(out)
    print(f"Saved {out} ({patterns} attack patterns). Restart the backend to load it.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
