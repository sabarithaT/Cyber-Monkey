"""Run a local PostgreSQL server without Docker or an installer (development only).

Uses the ``pgserver`` package, which bundles PostgreSQL binaries. The data directory is
``<repo>/.devdb`` by default. Prints the DATABASE_URL to put in ``backend/.env`` and keeps
running until interrupted.

    python scripts/dev_postgres.py            # start and keep running
    python scripts/dev_postgres.py --print    # start (if needed), print URL, exit
"""

from __future__ import annotations

import argparse
import re
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default=str(REPO / ".devdb"))
    parser.add_argument("--database", default="cybermonkey")
    parser.add_argument("--print", action="store_true", help="print the URL and exit, leaving the server running")
    args = parser.parse_args()

    try:
        import pgserver
    except ImportError:
        print("pgserver is not installed: pip install -r requirements-dev.txt", file=sys.stderr)
        return 1

    if not re.fullmatch(r"[a-z_][a-z0-9_]{0,62}", args.database):
        print("--database must be a simple lower-case identifier", file=sys.stderr)
        return 2
    server = pgserver.get_server(args.data_dir, cleanup_mode=None if args.print else "stop")
    # Identifier validated above; psql here is a local development helper.
    exists = server.psql(f"SELECT 1 FROM pg_database WHERE datname = '{args.database}';")  # noqa: S608
    if "1 row" not in exists:
        server.psql(f"CREATE DATABASE {args.database};")
    uri = server.get_uri(args.database).replace("postgresql://", "postgresql+psycopg://", 1)
    print(f"DATABASE_URL={uri}", flush=True)
    if args.print:
        return 0
    print("PostgreSQL is running. Press Ctrl+C to stop.", flush=True)
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
