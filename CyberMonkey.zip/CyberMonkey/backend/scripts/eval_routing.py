"""Measure workspace routing accuracy and macro-F1 (research question RQ2).

    python scripts/eval_routing.py --user admin@example.org [--dataset ../docs/evaluation/routing_requests.json]
                                   [--router auto|rules] [--out results.json]

Routes every labelled request through the orchestrator's router (the configured LLM when
--router auto and AI_PROVIDER is set, otherwise the deterministic rules) as the given
user, and compares the predicted workspace with the label. Requests the router leaves
without a workspace count as wrong. Nothing is executed: only routing is evaluated.

Record the configuration with every result (the script prints it): LLM provider and
model, router mode, dataset size and commit. Results are only meaningful for that
configuration and dataset.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.ai.provider import provider_status
from app.core.db import session_factory
from app.services import orchestrator
from app.services.identity import get_user_by_email

DEFAULT_DATASET = Path(__file__).resolve().parents[2] / "docs" / "evaluation" / "routing_requests.json"


def macro_f1(pairs: list[tuple[str, str]], labels: list[str]) -> tuple[float, dict[str, dict[str, float]]]:
    per_label: dict[str, dict[str, float]] = {}
    for label in labels:
        tp = sum(1 for truth, pred in pairs if truth == label and pred == label)
        fp = sum(1 for truth, pred in pairs if truth != label and pred == label)
        fn = sum(1 for truth, pred in pairs if truth == label and pred != label)
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        per_label[label] = {
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "f1": round(f1, 4),
            "support": tp + fn,
        }
    return round(sum(v["f1"] for v in per_label.values()) / len(labels), 4), per_label


def commit_hash() -> str:
    try:
        return (
            subprocess.run(
                ["git", "rev-parse", "--short", "HEAD"], capture_output=True, text=True, check=False
            ).stdout.strip()
            or "uncommitted"
        )
    except OSError:
        return "unknown"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--user", required=True, help="email of the user whose permissions apply (use an administrator)"
    )
    parser.add_argument("--dataset", default=str(DEFAULT_DATASET))
    parser.add_argument("--router", choices=["auto", "rules"], default="auto")
    parser.add_argument("--out", help="write detailed results to this JSON file")
    args = parser.parse_args()

    dataset = json.loads(Path(args.dataset).read_text(encoding="utf-8"))
    labels: list[str] = dataset["labels"]
    rows = []
    with session_factory()() as db:
        user = get_user_by_email(db, args.user)
        if user is None:
            print(f"No user {args.user}", file=sys.stderr)
            return 2
        for item in dataset["requests"]:
            intent = None
            if args.router == "auto":
                intent = orchestrator.llm_route(db, item["text"], user, None, None)
            if intent is None:
                intent = orchestrator.rule_route(item["text"], user, None)
            rows.append(
                {
                    "text": item["text"],
                    "label": item["workspace"],
                    "predicted": intent.workspace or "none",
                    "router": intent.router,
                    "router_error": intent.router_error,
                }
            )
    pairs = [(r["label"], r["predicted"]) for r in rows]
    accuracy = round(sum(1 for t, p in pairs if t == p) / len(pairs), 4)
    f1, per_label = macro_f1(pairs, labels)
    config = {
        "measured_at": datetime.now(UTC).isoformat(),
        "router_mode": args.router,
        "routers_used": dict(Counter(r["router"] for r in rows)),
        "llm": provider_status(),
        "dataset": str(args.dataset),
        "requests": len(rows),
        "commit": commit_hash(),
    }
    result = {"configuration": config, "accuracy": accuracy, "macro_f1": f1, "per_label": per_label, "rows": rows}
    print(json.dumps({k: result[k] for k in ("configuration", "accuracy", "macro_f1", "per_label")}, indent=2))
    errors = [r for r in rows if r["label"] != r["predicted"]]
    for r in errors[:20]:
        print(f"  MISROUTED  expected={r['label']:<9} got={r['predicted']:<9} {r['text']}")
    if args.out:
        Path(args.out).write_text(json.dumps(result, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
