"""Authentication: login, lockout, token validation, logout, cookies and CSRF."""

from __future__ import annotations

from sqlalchemy import select

from app.models import AuditLog
from tests.conftest import PASSWORD


def test_login_success_returns_token_and_permissions(client, make_user):
    make_user("soc@example.org", "soc_analyst")
    resp = client.post("/api/v1/auth/login", json={"email": "SOC@example.org", "password": PASSWORD})
    assert resp.status_code == 200
    body = resp.json()
    assert body["token_type"] == "bearer"
    assert "soc:execute" in body["user"]["permissions"]
    assert body["user"]["workspaces"] == ["soc", "network"]
    assert "cm_session" in resp.cookies


def test_login_failure_is_generic_and_audited(client, make_user, db):
    make_user("soc@example.org", "soc_analyst")
    bad = client.post("/api/v1/auth/login", json={"email": "soc@example.org", "password": "wrong-password"})
    unknown = client.post("/api/v1/auth/login", json={"email": "nobody@example.org", "password": "x"})
    assert bad.status_code == unknown.status_code == 401
    assert bad.json()["error"]["message"] == unknown.json()["error"]["message"]
    rows = db.scalars(select(AuditLog).where(AuditLog.action == "auth.login")).all()
    assert {r.result for r in rows} == {"failure"}
    assert {r.details["reason"] for r in rows} == {"bad_password", "unknown_account"}
    # Passwords never reach the audit log.
    assert all("wrong-password" not in str(r.details) for r in rows)


def test_account_locks_after_repeated_failures(client, make_user):
    make_user("soc@example.org", "soc_analyst")
    for _ in range(5):
        client.post("/api/v1/auth/login", json={"email": "soc@example.org", "password": "nope"})
    resp = client.post("/api/v1/auth/login", json={"email": "soc@example.org", "password": PASSWORD})
    assert resp.status_code == 401


def test_me_requires_valid_token(client, make_user, login):
    assert client.get("/api/v1/auth/me").status_code == 401
    assert client.get("/api/v1/auth/me", headers={"Authorization": "Bearer not-a-jwt"}).status_code == 401
    make_user("soc@example.org", "soc_analyst")
    headers = login("soc@example.org")
    resp = client.get("/api/v1/auth/me", headers=headers)
    assert resp.status_code == 200
    assert resp.json()["email"] == "soc@example.org"


def test_tampered_token_rejected(client, make_user, login):
    make_user("soc@example.org", "soc_analyst")
    token = login("soc@example.org")["Authorization"].split()[1]
    header, payload, signature = token.split(".")
    tampered = f"{header}.{payload}.{signature[:-2]}{'AA' if signature[-2:] != 'AA' else 'BB'}"
    assert client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {tampered}"}).status_code == 401


def test_logout_revokes_token(client, make_user, login):
    make_user("soc@example.org", "soc_analyst")
    headers = login("soc@example.org")
    assert client.post("/api/v1/auth/logout", headers=headers).status_code == 200
    assert client.get("/api/v1/auth/me", headers=headers).status_code == 401


def test_cookie_auth_requires_csrf_header_for_writes(client, make_user):
    make_user("soc@example.org", "soc_analyst")
    client.post("/api/v1/auth/login", json={"email": "soc@example.org", "password": PASSWORD})
    assert client.get("/api/v1/auth/me").status_code == 200  # safe method via cookie
    assert client.post("/api/v1/auth/logout").status_code == 401  # no anti-CSRF header
    assert client.post("/api/v1/auth/logout", headers={"X-CM-Client": "web"}).status_code == 200


def test_change_password_invalidates_sessions(client, make_user, login):
    make_user("soc@example.org", "soc_analyst")
    headers = login("soc@example.org")
    weak = client.post(
        "/api/v1/auth/change-password",
        headers=headers,
        json={"current_password": PASSWORD, "new_password": "short"},
    )
    assert weak.status_code == 422
    ok = client.post(
        "/api/v1/auth/change-password",
        headers=headers,
        json={"current_password": PASSWORD, "new_password": "An0ther-Strong-Passphrase"},
    )
    assert ok.status_code == 200
    assert client.get("/api/v1/auth/me", headers=headers).status_code == 401
    login("soc@example.org", "An0ther-Strong-Passphrase")


def test_unknown_fields_rejected(client):
    resp = client.post("/api/v1/auth/login", json={"email": "a@example.org", "password": "x", "is_admin": True})
    assert resp.status_code == 422
    assert resp.json()["error"]["code"] == "validation_failed"
