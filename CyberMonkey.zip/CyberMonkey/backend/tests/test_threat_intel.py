"""Threat Intelligence Engine: IOC normalization, correlation, references and risk scoring."""

from __future__ import annotations

import json

import pytest
from sqlalchemy import select

from app.models import ThreatIntelReference
from app.services import indicators as ioc
from app.services import nvd
from tests.helpers import create_investigation, findings_document, run_tool, upload


@pytest.mark.parametrize(
    ("type_", "raw", "expected", "internal"),
    [
        ("ipv4", " 010.010.000.005 ", None, False),  # leading zeros are ambiguous and rejected
        ("ipv4", "10.10.0.5", "10.10.0.5", True),
        ("ipv4", "8.8.8.8", "8.8.8.8", False),
        ("ipv6", "2001:DB8::1", "2001:db8::1", True),
        ("domain", "Example.COM.", "example.com", False),
        ("domain", "evil[.]example", "evil.example", False),
        ("domain", "payload.exe", None, False),
        ("domain", "host.corp", "host.corp", True),
        ("url", "HTTP://Example.com/a#frag", "http://example.com/a", False),
        ("url", "javascript:alert(1)", None, False),
        ("sha256", "A" * 64, "a" * 64, False),
        ("md5", "zz" * 16, None, False),
        ("email", "User@Example.com", "user@example.com", False),
    ],
)
def test_indicator_normalization(type_, raw, expected, internal):
    result = ioc.normalize(type_, raw)
    if expected is None:
        assert result is None
    else:
        assert result is not None and result.value == expected and result.is_internal == internal


def test_indicator_extraction_skips_filenames():
    text = "Beacon to http://bad.example/x.php from 10.0.0.9; dropped invoice.exe, contacted c2.example.net"
    found = {(i.type.value, i.value) for i in ioc.extract(text)}
    assert ("url", "http://bad.example/x.php") in found
    assert ("ipv4", "10.0.0.9") in found
    assert ("domain", "c2.example.net") in found
    assert not any(v.endswith(".exe") for _, v in found)


def _import(client, headers, inv_id, workspace, kind, document):
    ev = upload(client, headers, inv_id, document, kind=kind).json()
    run = run_tool(client, headers, inv_id, f"{workspace}_findings_import", {"evidence_id": ev["id"]}).json()
    assert run["status"] == "succeeded", run
    return run


def test_risk_score_components_and_missing_data(client, admin_headers, db):
    inv = create_investigation(client, admin_headers, workspace="pentest")
    # Without findings every component is missing and no score is produced.
    empty = client.post(f"/api/v1/threat-intelligence/risk/{inv['id']}", headers=admin_headers).json()
    assert empty["score"] is None and empty["coverage"] == 0
    assert empty["lower_bound"] == 0 and empty["upper_bound"] == pytest.approx(1.0, abs=1e-3)

    _import(client, admin_headers, inv["id"], "pentest", "scan_report", findings_document())
    network_doc = json.dumps(
        {
            "format": "cybermonkey-findings/v1",
            "source_tool": "lab-ids 7",
            "findings": [
                {
                    "type": "alert",
                    "title": "Inbound connection attempt",
                    "severity": "medium",
                    "indicators": [{"type": "ipv4", "value": "10.10.0.5"}],
                }
            ],
        }
    ).encode()
    _import(client, admin_headers, inv["id"], "network", "ids_alerts", network_doc)

    result = client.post(f"/api/v1/threat-intelligence/risk/{inv['id']}", headers=admin_headers).json()
    items = {c["key"]: c for c in result["components"]["items"]}
    assert items["cve"]["status"] == "missing"  # CVE present but not enriched from NVD
    assert items["cve"]["excluded"][0]["reason"].startswith("not enriched")
    assert items["attack"]["value"] == pytest.approx(0.6)  # T1190 -> initial-access
    assert items["ioc"]["value"] == pytest.approx(0.2)  # 1 correlated indicator / 5
    assert result["coverage"] == pytest.approx(2 / 3, abs=1e-3)
    assert result["score"] == pytest.approx(0.4, abs=1e-3)
    assert result["lower_bound"] == pytest.approx((0.6 + 0.2) / 3, abs=1e-3)
    assert result["upper_bound"] == pytest.approx((0.6 + 0.2 + 1) / 3, abs=1e-3)

    # Enrich the CVE (simulating a completed NVD lookup) and the C(F) term is evaluated.
    ref = db.scalar(select(ThreatIntelReference).where(ThreatIntelReference.external_id == "CVE-2021-41773"))
    ref.cvss_score, ref.source = 7.5, "nvd"
    db.commit()
    result = client.post(f"/api/v1/threat-intelligence/risk/{inv['id']}", headers=admin_headers).json()
    items = {c["key"]: c for c in result["components"]["items"]}
    assert items["cve"]["value"] == pytest.approx(0.75)
    assert result["coverage"] == pytest.approx(1.0, abs=1e-3)
    assert result["score"] == pytest.approx((0.75 + 0.6 + 0.2) / 3, abs=1e-3)
    history = client.get(f"/api/v1/threat-intelligence/risk/{inv['id']}", headers=admin_headers).json()
    assert len(history) == 3


def test_rejected_findings_do_not_count(client, admin_headers):
    inv = create_investigation(client, admin_headers, workspace="pentest")
    _import(client, admin_headers, inv["id"], "pentest", "scan_report", findings_document())
    vuln = client.get("/api/v1/findings", headers=admin_headers, params={"investigation_id": inv["id"]}).json()[
        "items"
    ][0]
    client.patch(f"/api/v1/findings/{vuln['id']}", headers=admin_headers, json={"validation_status": "rejected"})
    result = client.post(f"/api/v1/threat-intelligence/risk/{inv['id']}", headers=admin_headers).json()
    items = {c["key"]: c for c in result["components"]["items"]}
    assert items["attack"]["status"] == "missing"


def test_cross_investigation_correlation_respects_visibility(client, make_user, login):
    make_user("a@example.org", "penetration_tester")
    make_user("b@example.org", "penetration_tester")
    a, b = login("a@example.org"), login("b@example.org")
    inv_a = create_investigation(client, a, workspace="pentest", title="Case A")
    inv_b = create_investigation(client, b, workspace="pentest", title="Case B")
    _import(client, a, inv_a["id"], "pentest", "scan_report", findings_document())
    _import(client, b, inv_b["id"], "pentest", "scan_report", findings_document())
    # User A cannot see case B, so no cross-investigation correlation is reported to them.
    corr = client.get(
        "/api/v1/threat-intelligence/correlations", headers=a, params={"investigation_id": inv_a["id"]}
    ).json()
    assert corr and all(not c["other_investigations"] for c in corr)
    client.post(
        f"/api/v1/investigations/{inv_b['id']}/members",
        headers=b,
        json={"email": "a@example.org", "access_level": "viewer"},
    )
    corr = client.get(
        "/api/v1/threat-intelligence/correlations", headers=a, params={"investigation_id": inv_a["id"]}
    ).json()
    shared = next(c for c in corr if c["value"] == "10.10.0.5")
    assert shared["correlated"] and shared["other_investigations"][0]["reference"] == inv_b["reference"]
    iocs = client.get("/api/v1/threat-intelligence/iocs", headers=a, params={"correlated_only": True}).json()
    assert iocs["items"][0]["value"] == "10.10.0.5" and iocs["items"][0]["investigation_count"] == 2


def test_references_and_attack_search(client, admin_headers):
    inv = create_investigation(client, admin_headers, workspace="pentest")
    _import(client, admin_headers, inv["id"], "pentest", "scan_report", findings_document())
    refs = client.get("/api/v1/threat-intelligence/references", headers=admin_headers).json()
    assert {r["external_id"] for r in refs["items"]} == {"CVE-2021-41773", "T1190"}
    techniques = client.get(
        "/api/v1/threat-intelligence/attack/techniques", headers=admin_headers, params={"q": "brute"}
    ).json()
    assert any(t["id"] == "T1110" for t in techniques["items"])


def test_enrichment_reports_unavailable_when_outbound_disabled(client, admin_headers):
    inv = create_investigation(client, admin_headers, workspace="pentest")
    resp = client.post(
        "/api/v1/threat-intelligence/enrich-cves", headers=admin_headers, json={"investigation_id": inv["id"]}
    )
    assert resp.status_code == 202 and resp.json()["status"] == "not_configured"


def test_nvd_payload_parsing():
    payload = {
        "vulnerabilities": [
            {
                "cve": {
                    "id": "CVE-2021-41773",
                    "descriptions": [{"lang": "en", "value": "Path traversal in Apache HTTP Server 2.4.49."}],
                    "metrics": {
                        "cvssMetricV31": [
                            {
                                "type": "Primary",
                                "cvssData": {
                                    "baseScore": 7.5,
                                    "baseSeverity": "HIGH",
                                    "vectorString": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N",
                                },
                            }
                        ]
                    },
                    "references": [{"url": "https://httpd.apache.org/security/vulnerabilities_24.html"}],
                }
            }
        ]
    }
    parsed = nvd.parse_cve(payload)
    assert parsed["cvss_score"] == 7.5 and parsed["severity"] == "high" and parsed["cvss_version"] == "3.1"
    assert nvd.parse_cve({"vulnerabilities": []}) is None


def test_dashboard_counts_only_visible_data(client, make_user, login, admin_headers):
    make_user("pt@example.org", "penetration_tester")
    pt = login("pt@example.org")
    empty = client.get("/api/v1/dashboard/summary", headers=pt).json()
    assert empty["investigations"]["total"] == 0 and sum(empty["findings_by_severity"].values()) == 0
    inv = create_investigation(client, admin_headers, workspace="pentest")
    _import(client, admin_headers, inv["id"], "pentest", "scan_report", findings_document())
    assert client.get("/api/v1/dashboard/summary", headers=pt).json()["investigations"]["total"] == 0
    admin = client.get("/api/v1/dashboard/summary", headers=admin_headers).json()
    assert admin["investigations"] == {"total": 1, "open": 1, "closed": 0}
    assert admin["findings_by_severity"]["high"] == 1 and admin["open_findings"] == 2
    assert admin["runs_by_status"] == {"succeeded": 1}
    assert admin["recent_alerts"][0]["severity"] == "high"
    assert {i["value"] for i in admin["recent_iocs"]} == {"10.10.0.5"}
    assert admin["activity_scope"] == "all" and admin["has_demo_data"] is False


def test_demo_seed_is_labelled_and_correlated(client, admin_headers, db):
    from app.services.demo import seed_demo

    message = seed_demo(db, owner_email="admin@example.org")
    db.commit()
    assert "Demo investigation" in message
    assert "already exists" in seed_demo(db, owner_email="admin@example.org")
    cases = client.get("/api/v1/investigations", headers=admin_headers).json()["items"]
    demo = cases[0]
    assert demo["is_demo"] is True and demo["title"].startswith("DEMO")
    findings = client.get("/api/v1/findings", headers=admin_headers, params={"investigation_id": demo["id"]}).json()
    assert findings["total"] == 5 and all(f["description"].startswith("DEMO") for f in findings["items"])
    corr = client.get(
        "/api/v1/threat-intelligence/correlations", headers=admin_headers, params={"investigation_id": demo["id"]}
    ).json()
    shared = next(c for c in corr if c["value"] == "198.51.100.20")
    assert shared["correlated"] and set(shared["workspaces"]) == {"pentest", "network"}
    assert client.get("/api/v1/dashboard/summary", headers=admin_headers).json()["has_demo_data"] is True
