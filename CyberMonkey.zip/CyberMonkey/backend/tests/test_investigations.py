"""Investigations, ownership, membership, authorized scope, notes and timeline."""

from __future__ import annotations

from tests.helpers import create_investigation


def test_create_requires_workspace_access(client, make_user, login):
    make_user("pt@example.org", "penetration_tester")
    headers = login("pt@example.org")
    denied = client.post(
        "/api/v1/investigations", headers=headers, json={"title": "Case", "primary_workspace": "malware"}
    )
    assert denied.status_code == 403
    inv = create_investigation(client, headers, workspace="pentest")
    assert inv["reference"].startswith("INV-") and inv["my_access"] == "owner"


def test_references_are_sequential_and_unique(client, admin_headers):
    refs = {create_investigation(client, admin_headers, title=f"Case {i}")["reference"] for i in range(3)}
    assert len(refs) == 3


def test_other_users_cannot_see_investigation(client, make_user, login):
    make_user("a@example.org", "forensics_analyst")
    make_user("b@example.org", "forensics_analyst")
    a, b = login("a@example.org"), login("b@example.org")
    inv = create_investigation(client, a)
    assert client.get(f"/api/v1/investigations/{inv['id']}", headers=b).status_code == 404
    assert client.get("/api/v1/investigations", headers=b).json()["total"] == 0
    assert client.get("/api/v1/investigations", headers=a).json()["total"] == 1


def test_membership_grants_access_by_level(client, make_user, login):
    make_user("owner@example.org", "forensics_analyst")
    make_user("viewer@example.org", "forensics_analyst")
    owner, viewer = login("owner@example.org"), login("viewer@example.org")
    inv = create_investigation(client, owner)
    resp = client.post(
        f"/api/v1/investigations/{inv['id']}/members",
        headers=owner,
        json={"email": "viewer@example.org", "access_level": "viewer"},
    )
    assert resp.status_code == 200
    assert client.get(f"/api/v1/investigations/{inv['id']}", headers=viewer).json()["my_access"] == "viewer"
    # A viewer cannot write.
    note = client.post(f"/api/v1/investigations/{inv['id']}/notes", headers=viewer, json={"body": "hello"})
    assert note.status_code == 404
    # Only the owner manages members.
    again = client.post(
        f"/api/v1/investigations/{inv['id']}/members",
        headers=viewer,
        json={"email": "owner@example.org", "access_level": "viewer"},
    )
    assert again.status_code == 404


def test_admin_manage_all_sees_everything(client, make_user, login, admin_headers):
    make_user("a@example.org", "forensics_analyst")
    inv = create_investigation(client, login("a@example.org"))
    detail = client.get(f"/api/v1/investigations/{inv['id']}", headers=admin_headers)
    assert detail.status_code == 200 and detail.json()["my_access"] == "manager"


def test_scope_targets_validated_and_permissioned(client, make_user, login):
    make_user("pt@example.org", "penetration_tester")
    make_user("soc@example.org", "soc_analyst")
    pt = login("pt@example.org")
    inv = create_investigation(client, pt, workspace="pentest")
    url = f"/api/v1/investigations/{inv['id']}/scope"
    ok = client.post(
        url,
        headers=pt,
        json={"target_type": "cidr", "value": "10.10.0.0/24", "authorization_reference": "Lab network, RoE v1"},
    )
    assert ok.status_code == 201, ok.text
    assert ok.json()["value"] == "10.10.0.0/24" and ok.json()["active"]
    assert (
        client.post(
            url, headers=pt, json={"target_type": "cidr", "value": "10.0.0.0/8", "authorization_reference": "too big"}
        ).status_code
        == 422
    )
    assert (
        client.post(
            url, headers=pt, json={"target_type": "ip", "value": "999.1.1.1", "authorization_reference": "bad ip"}
        ).status_code
        == 422
    )
    assert (
        client.post(
            url,
            headers=pt,
            json={"target_type": "hostname", "value": "-bad-.example", "authorization_reference": "bad host"},
        ).status_code
        == 422
    )
    assert (
        client.post(
            url, headers=pt, json={"target_type": "cidr", "value": "10.10.0.0/24", "authorization_reference": "dup ref"}
        ).status_code
        == 409
    )


def test_target_in_scope_logic(db, client, make_user, login):
    from app.services.investigations import ScopeViolation, target_in_scope

    make_user("pt@example.org", "penetration_tester")
    pt = login("pt@example.org")
    inv = create_investigation(client, pt, workspace="pentest")
    url = f"/api/v1/investigations/{inv['id']}/scope"
    client.post(
        url,
        headers=pt,
        json={"target_type": "cidr", "value": "192.168.56.0/24", "authorization_reference": "Lab network RoE v1"},
    )
    client.post(
        url,
        headers=pt,
        json={"target_type": "hostname", "value": "lab.example.test", "authorization_reference": "Lab network RoE v1"},
    )
    import uuid

    inv_id = uuid.UUID(inv["id"])
    assert target_in_scope(db, inv_id, "192.168.56.10").value == "192.168.56.0/24"
    assert target_in_scope(db, inv_id, "192.168.56.0/28").value == "192.168.56.0/24"
    assert target_in_scope(db, inv_id, "LAB.example.test").target_type == "hostname"
    for outside in ("192.168.57.1", "192.168.0.0/16", "other.example.test", "::1"):
        try:
            target_in_scope(db, inv_id, outside)
        except ScopeViolation:
            continue
        raise AssertionError(f"{outside} should be out of scope")


def test_notes_and_timeline(client, admin_headers):
    inv = create_investigation(client, admin_headers)
    assert (
        client.post(
            f"/api/v1/investigations/{inv['id']}/notes", headers=admin_headers, json={"body": "First note"}
        ).status_code
        == 201
    )
    notes = client.get(f"/api/v1/investigations/{inv['id']}/notes", headers=admin_headers).json()
    assert [n["body"] for n in notes] == ["First note"]
    timeline = client.get(f"/api/v1/investigations/{inv['id']}/timeline", headers=admin_headers).json()
    assert timeline[0]["kind"] == "note"


def test_close_and_reopen(client, admin_headers):
    inv = create_investigation(client, admin_headers)
    closed = client.patch(
        f"/api/v1/investigations/{inv['id']}", headers=admin_headers, json={"status": "closed"}
    ).json()
    assert closed["status"] == "closed" and closed["closed_at"]
    reopened = client.patch(
        f"/api/v1/investigations/{inv['id']}", headers=admin_headers, json={"status": "open"}
    ).json()
    assert reopened["closed_at"] is None
