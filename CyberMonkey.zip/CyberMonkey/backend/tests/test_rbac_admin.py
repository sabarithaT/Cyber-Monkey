"""Role-based access control and administration endpoints."""

from __future__ import annotations

from sqlalchemy import select

from app.models import AuditLog, Role


def test_non_admin_cannot_manage_users(client, make_user, login, db):
    make_user("soc@example.org", "soc_analyst")
    headers = login("soc@example.org")
    resp = client.get("/api/v1/users", headers=headers)
    assert resp.status_code == 403
    assert resp.json()["error"]["details"]["required_permission"] == "users:manage"
    denied = db.scalars(select(AuditLog).where(AuditLog.action == "authz.denied")).all()
    assert len(denied) == 1 and denied[0].result == "denied"


def test_admin_creates_user_with_role_and_password_policy(client, admin_headers, db):
    role = db.scalar(select(Role).where(Role.slug == "penetration_tester"))
    weak = client.post(
        "/api/v1/users",
        headers=admin_headers,
        json={"email": "pt@example.org", "full_name": "PT", "password": "password", "role_ids": [role.id]},
    )
    assert weak.status_code == 422
    resp = client.post(
        "/api/v1/users",
        headers=admin_headers,
        json={"email": "pt@example.org", "full_name": "PT", "password": "Str0ng-Enough-Pass", "role_ids": [role.id]},
    )
    assert resp.status_code == 201, resp.text
    assert [r["slug"] for r in resp.json()["roles"]] == ["penetration_tester"]
    dup = client.post(
        "/api/v1/users",
        headers=admin_headers,
        json={"email": "PT@example.org", "full_name": "PT", "password": "Str0ng-Enough-Pass"},
    )
    assert dup.status_code == 409
    assert db.scalar(select(AuditLog).where(AuditLog.action == "user.create")) is not None


def test_role_change_invalidates_existing_tokens(client, make_user, login, admin_headers, db):
    user = make_user("soc@example.org", "soc_analyst")
    headers = login("soc@example.org")
    pt = db.scalar(select(Role).where(Role.slug == "penetration_tester"))
    resp = client.put(f"/api/v1/users/{user.id}/roles", headers=admin_headers, json={"role_ids": [pt.id]})
    assert resp.status_code == 200
    assert client.get("/api/v1/auth/me", headers=headers).status_code == 401
    me = client.get("/api/v1/auth/me", headers=login("soc@example.org")).json()
    assert me["workspaces"] == ["pentest"]


def test_direct_permission_grant_is_separate_from_roles(client, make_user, login, admin_headers):
    user = make_user("soc@example.org", "soc_analyst")
    resp = client.put(
        f"/api/v1/users/{user.id}/permissions", headers=admin_headers, json={"permission_codes": ["osint:view"]}
    )
    assert resp.status_code == 200
    assert resp.json()["direct_permissions"] == ["osint:view"]
    me = client.get("/api/v1/auth/me", headers=login("soc@example.org")).json()
    assert "osint" in me["workspaces"]
    assert [r["slug"] for r in me["roles"]] == ["soc_analyst"]
    bad = client.put(
        f"/api/v1/users/{user.id}/permissions", headers=admin_headers, json={"permission_codes": ["root:everything"]}
    )
    assert bad.status_code == 422


def test_custom_role_lifecycle(client, admin_headers, make_user, login):
    resp = client.post(
        "/api/v1/roles",
        headers=admin_headers,
        json={"name": "Threat Hunter", "permission_codes": ["soc:view", "network:view", "threat_intel:view"]},
    )
    assert resp.status_code == 201, resp.text
    role = resp.json()
    assert role["slug"] == "threat_hunter" and not role["is_system"]
    upd = client.patch(f"/api/v1/roles/{role['id']}", headers=admin_headers, json={"permission_codes": ["soc:view"]})
    assert upd.json()["permissions"] == ["soc:view"]
    assert client.delete(f"/api/v1/roles/{role['id']}", headers=admin_headers).status_code == 200


def test_system_roles_protected(client, admin_headers, db):
    admin_role = db.scalar(select(Role).where(Role.slug == "administrator"))
    soc_role = db.scalar(select(Role).where(Role.slug == "soc_analyst"))
    assert client.delete(f"/api/v1/roles/{soc_role.id}", headers=admin_headers).status_code == 422
    resp = client.patch(f"/api/v1/roles/{admin_role.id}", headers=admin_headers, json={"permission_codes": []})
    assert resp.status_code == 422


def test_admin_cannot_lock_themselves_out(client, admin_headers, db):
    me = client.get("/api/v1/auth/me", headers=admin_headers).json()
    soc_role = db.scalar(select(Role).where(Role.slug == "soc_analyst"))
    resp = client.put(f"/api/v1/users/{me['id']}/roles", headers=admin_headers, json={"role_ids": [soc_role.id]})
    assert resp.status_code == 422
    assert (
        client.patch(f"/api/v1/users/{me['id']}", headers=admin_headers, json={"is_active": False}).status_code == 422
    )


def test_deactivated_user_cannot_use_token(client, make_user, login, admin_headers):
    user = make_user("soc@example.org", "soc_analyst")
    headers = login("soc@example.org")
    client.patch(f"/api/v1/users/{user.id}", headers=admin_headers, json={"is_active": False})
    assert client.get("/api/v1/auth/me", headers=headers).status_code == 401


def test_audit_log_access_restricted(client, make_user, login, admin_headers):
    make_user("soc@example.org", "soc_analyst")
    assert client.get("/api/v1/audit-logs", headers=login("soc@example.org")).status_code == 403
    resp = client.get("/api/v1/audit-logs?action=auth.", headers=admin_headers)
    assert resp.status_code == 200
    assert resp.json()["total"] >= 1
