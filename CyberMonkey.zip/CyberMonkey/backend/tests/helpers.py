"""Shared helpers for API tests."""

from __future__ import annotations

import io
import json
from typing import Any


def create_investigation(client, headers, *, workspace: str = "forensics", title: str = "Test case") -> dict[str, Any]:
    resp = client.post("/api/v1/investigations", headers=headers, json={"title": title, "primary_workspace": workspace})
    assert resp.status_code == 201, resp.text
    return resp.json()


def upload(client, headers, investigation_id: str, content: bytes, *, kind: str, filename: str = "file.bin", **form):
    resp = client.post(
        f"/api/v1/investigations/{investigation_id}/evidence",
        headers=headers,
        files={"file": (filename, io.BytesIO(content), "application/octet-stream")},
        data={"kind": kind, **form},
    )
    return resp


def findings_document(source_tool: str = "lab-scanner 1.0", findings: list[dict[str, Any]] | None = None) -> bytes:
    return json.dumps(
        {
            "format": "cybermonkey-findings/v1",
            "source_tool": source_tool,
            "generated_at": "2026-10-01T10:00:00Z",
            "findings": findings
            if findings is not None
            else [
                {
                    "id": "f-1",
                    "type": "vulnerability",
                    "title": "Outdated web server",
                    "description": "Server banner reports an outdated version.",
                    "severity": "high",
                    "asset": "10.10.0.5:80/tcp",
                    "indicators": [{"type": "ipv4", "value": "10.10.0.5"}, {"type": "ipv4", "value": "not-an-ip"}],
                    "cve": ["CVE-2021-41773", "CVE-bogus"],
                    "attack": ["T1190", "T9999"],
                    "remediation": ["Upgrade the web server to a supported release."],
                },
                {
                    "id": "f-2",
                    "type": "open_service",
                    "title": "SSH exposed",
                    "severity": "low",
                    "asset": "10.10.0.5:22/tcp",
                    "indicators": [{"type": "ipv4", "value": "10.10.0.5"}],
                },
                {"type": "broken"},
            ],
        }
    ).encode()


def run_tool(client, headers, investigation_id: str, tool: str, arguments: dict[str, Any]):
    return client.post(
        "/api/v1/tool-runs",
        headers=headers,
        json={"investigation_id": investigation_id, "tool": tool, "arguments": arguments},
    )
