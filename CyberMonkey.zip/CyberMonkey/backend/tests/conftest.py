"""Test fixtures.

Tests run against a real PostgreSQL database. If TEST_DATABASE_URL is set it is used
(e.g. the docker-compose service); otherwise an embedded server is started with
``pgserver``. Every test starts from an empty schema with RBAC reference data seeded."""

from __future__ import annotations

import os
import shutil
import tempfile
from collections.abc import Iterator
from pathlib import Path

_TMP = Path(tempfile.mkdtemp(prefix="cybermonkey-tests-"))
os.environ.update(
    {
        "ENVIRONMENT": "test",
        "JWT_SECRET": "test-secret-not-for-production-use-0123456789abcdef",
        "STORAGE_DIR": str(_TMP / "storage"),
        "AI_PROVIDER": "none",
        "OUTBOUND_NETWORK_ENABLED": "false",
        "LOGIN_RATE_LIMIT_PER_MINUTE": "1000",
        "TOOL_EXECUTION_MODE": "inline",
    }
)

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from sqlalchemy import select, text  # noqa: E402
from sqlalchemy.orm import Session  # noqa: E402


def _database_url() -> str:
    url = os.environ.get("TEST_DATABASE_URL")
    if url:
        return url
    import pgserver

    server = pgserver.get_server(str(_TMP / "pgdata"), cleanup_mode="stop")
    server.psql("CREATE DATABASE cybermonkey_test;")
    return server.get_uri("cybermonkey_test").replace("postgresql://", "postgresql+psycopg://", 1)


@pytest.fixture(scope="session")
def database_url() -> Iterator[str]:
    url = _database_url()
    os.environ["DATABASE_URL"] = url
    from app.core.config import get_settings

    get_settings.cache_clear()
    from app.core.db import configure_engine

    engine = configure_engine(url)
    from alembic import command
    from alembic.config import Config

    from app.core.config import BACKEND_DIR

    cfg = Config(str(BACKEND_DIR / "alembic.ini"))
    cfg.set_main_option("script_location", str(BACKEND_DIR / "alembic"))
    with engine.begin() as conn:
        conn.execute(text("DROP SCHEMA public CASCADE; CREATE SCHEMA public;"))
    with engine.connect() as conn:
        cfg.attributes["connection"] = conn
        command.upgrade(cfg, "head")
        conn.commit()
    yield url
    engine.dispose()
    shutil.rmtree(_TMP, ignore_errors=True)


@pytest.fixture(autouse=True)
def _clean_database(database_url: str) -> Iterator[None]:
    from app.core.db import Base, get_engine, session_factory
    from app.core.ratelimit import limiter
    from app.services.identity import ensure_rbac_seed
    from app.services.integrations import ensure_integration_rows

    tables = ", ".join(f'"{t.name}"' for t in Base.metadata.sorted_tables)
    with get_engine().begin() as conn:
        conn.execute(text(f"TRUNCATE {tables} RESTART IDENTITY CASCADE"))
    with session_factory()() as db:
        ensure_rbac_seed(db)
        ensure_integration_rows(db)
        db.commit()
    limiter.reset()
    yield


@pytest.fixture
def db() -> Iterator[Session]:
    from app.core.db import session_factory

    with session_factory()() as session:
        yield session


@pytest.fixture
def client(database_url: str) -> Iterator[TestClient]:
    from app.main import create_app

    with TestClient(create_app()) as c:
        yield c


PASSWORD = "Correct-Horse-Battery-9"


@pytest.fixture
def make_user(db: Session):
    from app.models import Role
    from app.services.identity import create_user

    def _make(email: str, *role_slugs: str, password: str = PASSWORD, full_name: str = "Test User"):
        roles = list(db.scalars(select(Role).where(Role.slug.in_(role_slugs)))) if role_slugs else []
        assert len(roles) == len(role_slugs), f"unknown role in {role_slugs}"
        user = create_user(
            db, email=email, full_name=full_name, password=password, role_ids=[r.id for r in roles], actor=None
        )
        db.commit()
        return user

    return _make


@pytest.fixture
def login(client: TestClient):
    def _login(email: str, password: str = PASSWORD) -> dict[str, str]:
        resp = client.post("/api/v1/auth/login", json={"email": email, "password": password})
        assert resp.status_code == 200, resp.text
        client.cookies.clear()  # tests authenticate with explicit bearer headers
        return {"Authorization": f"Bearer {resp.json()['access_token']}"}

    return _login


@pytest.fixture
def admin_headers(make_user, login) -> dict[str, str]:
    make_user("admin@example.org", "administrator", full_name="Admin")
    return login("admin@example.org")
