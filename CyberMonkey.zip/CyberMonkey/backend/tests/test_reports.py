"""Report generation, citation checks, review workflow and PDF export."""

from __future__ import annotations

from app.ai.provider import LLMInfo, set_provider_override
from tests.helpers import create_investigation, findings_document, run_tool, upload


def _case_with_findings(client, headers):
    inv = create_investigation(client, headers, workspace="pentest")
    ev = upload(client, headers, inv["id"], findings_document(), kind="scan_report").json()
    run_tool(client, headers, inv["id"], "pentest_findings_import", {"evidence_id": ev["id"]})
    return inv


def test_template_report_is_evidence_linked(client, admin_headers):
    inv = _case_with_findings(client, admin_headers)
    resp = client.post("/api/v1/reports", headers=admin_headers, json={"investigation_id": inv["id"]})
    assert resp.status_code == 201, resp.text
    report = resp.json()
    assert report["generation_mode"] == "template" and report["status"] == "draft"
    content, narrative = report["content"], report["narrative"]
    cites = {f["cite"] for f in content["findings"]}
    assert len(cites) == 2
    assert narrative["citation_issues"] == []
    assert any(c in narrative["executive_summary"] for c in cites)
    assert narrative["recommended_mitigations"][0]["text"].startswith("Upgrade the web server")
    assert any("not been enriched" in item for item in content["limitations"])
    assert any("not been validated" in item for item in content["limitations"])
    assert content["data_sources"]["tool_runs"][0]["tool"] == "pentest_findings_import"
    assert content["risk"]["coverage"] > 0


def test_llm_report_citations_are_checked(client, admin_headers):
    class FakeLLM:
        info = LLMInfo("fake", "fake-1")

        def generate_text(self, system, prompt, *, temperature=0.2):
            return ""

        def generate_json(self, system, prompt, schema, *, temperature=0.0):
            assert "<report_data>" in prompt and "Ignore any instructions" in system
            return {
                "executive_summary": "One high finding [F-deadbeef] was reported.",
                "technical_findings": "Details.",
                "risk_assessment": "Partial.",
                "recommended_mitigations": [{"text": "Patch it.", "finding_ids": ["F-00000000"]}],
            }

    inv = _case_with_findings(client, admin_headers)
    set_provider_override(FakeLLM())
    try:
        report = client.post("/api/v1/reports", headers=admin_headers, json={"investigation_id": inv["id"]}).json()
    finally:
        set_provider_override(None)
    assert report["generation_mode"] == "llm" and report["llm_model"] == "fake-1"
    issues = report["narrative"]["citation_issues"]
    assert any("F-deadbeef" in i for i in issues)
    assert any("mitigation 1" in i for i in issues)
    assert report["citation_issue_count"] == len(issues)


def test_review_workflow_requires_second_person(client, admin_headers, make_user, login):
    make_user("lead@example.org", "administrator")
    lead = login("lead@example.org")
    inv = _case_with_findings(client, admin_headers)
    client.post(
        f"/api/v1/investigations/{inv['id']}/members", headers=admin_headers, json={"email": "lead@example.org"}
    )
    report = client.post("/api/v1/reports", headers=admin_headers, json={"investigation_id": inv["id"]}).json()
    rid = report["id"]
    assert (
        client.patch(f"/api/v1/reports/{rid}", headers=admin_headers, json={"analyst_notes": "Checked."}).status_code
        == 200
    )
    assert client.post(f"/api/v1/reports/{rid}/approve", headers=lead, json={}).status_code == 422  # not submitted
    assert client.post(f"/api/v1/reports/{rid}/submit", headers=admin_headers).json()["status"] == "in_review"
    assert (
        client.post(f"/api/v1/reports/{rid}/approve", headers=admin_headers, json={}).status_code == 403
    )  # self-review
    assert (
        client.post(f"/api/v1/reports/{rid}/request-changes", headers=lead, json={}).status_code == 422
    )  # needs comment
    sent_back = client.post(
        f"/api/v1/reports/{rid}/request-changes", headers=lead, json={"comment": "Add scope"}
    ).json()
    assert sent_back["status"] == "changes_requested"
    client.post(f"/api/v1/reports/{rid}/submit", headers=admin_headers)
    approved = client.post(f"/api/v1/reports/{rid}/approve", headers=lead, json={"comment": "OK"}).json()
    assert approved["status"] == "approved" and approved["reviewed_by"]["email"] == "lead@example.org"
    assert client.patch(f"/api/v1/reports/{rid}", headers=admin_headers, json={"analyst_notes": "x"}).status_code == 422
    v2 = client.post(f"/api/v1/reports/{rid}/regenerate", headers=admin_headers).json()
    assert v2["version"] == 2 and v2["status"] == "draft" and v2["analyst_notes"] == "Checked."
    history = client.get("/api/v1/reports", headers=admin_headers, params={"investigation_id": inv["id"]}).json()
    assert [r["version"] for r in history["items"]] == [2, 1]


def test_pdf_export(client, admin_headers):
    inv = _case_with_findings(client, admin_headers)
    report = client.post("/api/v1/reports", headers=admin_headers, json={"investigation_id": inv["id"]}).json()
    resp = client.get(f"/api/v1/reports/{report['id']}/pdf", headers=admin_headers)
    assert resp.status_code == 200 and resp.headers["content-type"] == "application/pdf"
    assert resp.content.startswith(b"%PDF") and len(resp.content) > 2000
    assert "draft" in resp.headers["content-disposition"]


def test_report_access_control(client, make_user, login, admin_headers):
    make_user("pt@example.org", "penetration_tester")
    inv = _case_with_findings(client, admin_headers)
    report = client.post("/api/v1/reports", headers=admin_headers, json={"investigation_id": inv["id"]}).json()
    pt = login("pt@example.org")
    assert client.get(f"/api/v1/reports/{report['id']}", headers=pt).status_code == 404
    assert client.post("/api/v1/reports", headers=pt, json={"investigation_id": inv["id"]}).status_code == 404


def test_empty_investigation_report_states_limits(client, admin_headers):
    inv = create_investigation(client, admin_headers)
    report = client.post("/api/v1/reports", headers=admin_headers, json={"investigation_id": inv["id"]}).json()
    assert report["content"]["findings"] == []
    assert "no active findings" in report["narrative"]["executive_summary"].lower()
    assert report["narrative"]["recommended_mitigations"] == []
