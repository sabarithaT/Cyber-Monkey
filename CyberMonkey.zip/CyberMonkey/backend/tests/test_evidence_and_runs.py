"""Evidence storage, tool runs, findings import and triage."""

from __future__ import annotations

import hashlib
import os

from sqlalchemy import select

from app.models import AuditLog, Evidence, EvidenceEvent, Indicator
from app.services import evidence as evidence_svc
from tests.helpers import create_investigation, findings_document, run_tool, upload


def test_upload_hashes_and_custody(client, admin_headers, db):
    inv = create_investigation(client, admin_headers)
    content = b"disk image bytes \x00\x01\x02" * 100
    resp = upload(
        client,
        admin_headers,
        inv["id"],
        content,
        kind="disk_image",
        filename="../../evil/disk.img",
        source_description="Lab VM",
        acquired_at="2026-10-01T09:00:00Z",
    )
    assert resp.status_code == 201, resp.text
    ev = resp.json()
    assert ev["sha256"] == hashlib.sha256(content).hexdigest()
    assert ev["original_filename"] == "disk.img"  # path components stripped
    assert ev["acquired_at"].startswith("2026-10-01")
    stored = evidence_svc.absolute_path(db.get(Evidence, __import__("uuid").UUID(ev["id"])))
    assert not os.access(stored, os.W_OK)  # originals are read-only
    detail = client.get(f"/api/v1/evidence/{ev['id']}", headers=admin_headers).json()
    assert [e["action"] for e in detail["events"]][:1] == ["registered"]
    verify = client.post(f"/api/v1/evidence/{ev['id']}/verify", headers=admin_headers).json()
    assert verify["match"] is True
    dup = upload(client, admin_headers, inv["id"], content, kind="disk_image")
    assert dup.status_code == 409


def test_upload_type_and_permission_rules(client, make_user, login):
    make_user("soc@example.org", "soc_analyst")
    soc = login("soc@example.org")
    inv = create_investigation(client, soc, workspace="soc")
    assert upload(client, soc, inv["id"], b"MZ\x90\x00binary", kind="log").status_code == 422  # wrong content
    assert upload(client, soc, inv["id"], b"", kind="log").status_code == 422  # empty
    assert upload(client, soc, inv["id"], b"MZ\x90\x00", kind="malware_sample").status_code == 403  # no malware:operate
    assert upload(client, soc, inv["id"], b"x", kind="tool_output").status_code == 403
    assert upload(client, soc, inv["id"], b"line one\nline two\n", kind="log").status_code == 201


def test_malware_samples_cannot_be_downloaded(client, make_user, login):
    make_user("mal@example.org", "malware_analyst")
    mal = login("mal@example.org")
    inv = create_investigation(client, mal, workspace="malware")
    ev = upload(client, mal, inv["id"], b"MZ\x90\x00 sample", kind="malware_sample").json()
    assert ev["downloadable"] is False
    assert client.get(f"/api/v1/evidence/{ev['id']}/download", headers=mal).status_code == 403


def test_profile_tool_end_to_end(client, make_user, login, db):
    make_user("mal@example.org", "malware_analyst")
    mal = login("mal@example.org")
    inv = create_investigation(client, mal, workspace="malware")
    content = os.urandom(4096)
    ev = upload(client, mal, inv["id"], content, kind="malware_sample", filename="sample.bin").json()
    resp = run_tool(client, mal, inv["id"], "malware_file_profile", {"evidence_id": ev["id"]})
    assert resp.status_code == 201, resp.text
    run = resp.json()
    assert run["status"] == "succeeded", run
    assert run["output_summary"]["integrity_verified"] is True
    assert 7.5 < run["output_summary"]["entropy"] <= 8.0  # random bytes
    assert run["raw_output_evidence_id"]
    findings = client.get("/api/v1/findings", headers=mal, params={"investigation_id": inv["id"]}).json()
    assert findings["total"] == 1
    f = findings["items"][0]
    assert {i["type"] for i in f["indicators"]} == {"md5", "sha1", "sha256"}
    assert f["evidence_refs"][0]["evidence_id"] == ev["id"]
    events = db.scalars(
        select(EvidenceEvent.action).where(EvidenceEvent.evidence_id == __import__("uuid").UUID(ev["id"]))
    ).all()
    assert "analyzed" in events


def test_tool_permission_and_scope_enforced(client, make_user, login):
    make_user("mal@example.org", "malware_analyst")
    make_user("for@example.org", "forensics_analyst")
    mal, fo = login("mal@example.org"), login("for@example.org")
    inv = create_investigation(client, fo)
    ev = upload(client, fo, inv["id"], b"evidence text\n", kind="forensic_report").json()
    # Malware analyst has no access to this investigation.
    assert run_tool(client, mal, inv["id"], "forensics_evidence_profile", {"evidence_id": ev["id"]}).status_code == 404
    # Wrong evidence kind for the malware profile tool / missing permission.
    assert run_tool(client, fo, inv["id"], "malware_file_profile", {"evidence_id": ev["id"]}).status_code == 403
    # Extra fields rejected by the strict schema.
    bad = run_tool(client, fo, inv["id"], "forensics_evidence_profile", {"evidence_id": ev["id"], "shell": "rm -rf /"})
    assert bad.status_code == 422
    assert run_tool(client, fo, inv["id"], "no_such_tool", {}).status_code == 422
    # Evidence from another investigation is out of scope.
    other = create_investigation(client, fo, title="Other case")
    resp = run_tool(client, fo, other["id"], "forensics_evidence_profile", {"evidence_id": ev["id"]})
    assert resp.status_code == 403 and resp.json()["error"]["code"] == "out_of_scope"


def test_findings_import_pipeline(client, make_user, login, db):
    make_user("pt@example.org", "penetration_tester")
    pt = login("pt@example.org")
    inv = create_investigation(client, pt, workspace="pentest")
    ev = upload(client, pt, inv["id"], findings_document(), kind="scan_report", filename="scan.json").json()
    run = run_tool(client, pt, inv["id"], "pentest_findings_import", {"evidence_id": ev["id"]}).json()
    assert run["status"] == "succeeded", run
    summary = run["output_summary"]
    assert summary["imported"] == 2 and len(summary["rejected_entries"]) == 1
    assert summary["dropped_values"] == {"indicators": 1, "cve": 1, "attack": 1}
    items = client.get("/api/v1/findings", headers=pt, params={"investigation_id": inv["id"]}).json()["items"]
    assert [f["severity"] for f in items] == ["high", "low"]  # sorted by severity
    vuln = items[0]
    assert vuln["origin"] == "import" and vuln["details"]["reported_by"] == "lab-scanner 1.0"
    refs = {r["external_id"]: r for r in vuln["references"]}
    assert set(refs) == {"CVE-2021-41773", "T1190"}
    assert refs["T1190"]["title"] == "Exploit Public-Facing Application"
    assert refs["CVE-2021-41773"]["source"] == "unenriched"
    assert db.scalar(select(Indicator).where(Indicator.value == "10.10.0.5")) is not None
    # Re-importing the same file is idempotent (same fingerprints).
    ev2 = upload(client, pt, inv["id"], findings_document() + b" ", kind="scan_report").json()
    run_tool(client, pt, inv["id"], "pentest_findings_import", {"evidence_id": ev2["id"]})
    assert client.get("/api/v1/findings", headers=pt, params={"investigation_id": inv["id"]}).json()["total"] == 2


def test_import_rejects_wrong_format(client, admin_headers):
    inv = create_investigation(client, admin_headers, workspace="network")
    ev = upload(client, admin_headers, inv["id"], b'{"format": "other"}', kind="ids_alerts").json()
    run = run_tool(client, admin_headers, inv["id"], "network_findings_import", {"evidence_id": ev["id"]}).json()
    assert run["status"] == "failed" and "cybermonkey-findings/v1" in run["error_message"]


def test_triage_updates_status_and_audits(client, admin_headers, db):
    inv = create_investigation(client, admin_headers, workspace="pentest")
    ev = upload(client, admin_headers, inv["id"], findings_document(), kind="scan_report").json()
    run_tool(client, admin_headers, inv["id"], "pentest_findings_import", {"evidence_id": ev["id"]})
    finding = client.get("/api/v1/findings", headers=admin_headers, params={"investigation_id": inv["id"]}).json()[
        "items"
    ][0]
    resp = client.patch(
        f"/api/v1/findings/{finding['id']}",
        headers=admin_headers,
        json={"status": "investigating", "validation_status": "confirmed", "note": "Verified manually"},
    )
    assert resp.status_code == 200
    assert resp.json()["validation_status"] == "confirmed"
    ref = next(r for r in finding["references"] if r["ref_type"] == "attack_technique")
    resp = client.patch(
        f"/api/v1/findings/{finding['id']}/references/{ref['id']}",
        headers=admin_headers,
        json={"validation_status": "rejected"},
    )
    assert next(r for r in resp.json()["references"] if r["id"] == ref["id"])["validation_status"] == "rejected"
    actions = set(db.scalars(select(AuditLog.action)))
    assert {
        "tool_run.request",
        "tool_run.complete",
        "finding.triage",
        "finding.reference_validated",
        "evidence.upload",
    } <= actions


def test_tools_listing_reflects_permissions(client, make_user, login):
    make_user("mal@example.org", "malware_analyst")
    tools = client.get("/api/v1/tools", headers=login("mal@example.org")).json()
    names = {t["name"] for t in tools}
    assert "malware_file_profile" in names and "pentest_findings_import" not in names
    profile = next(t for t in tools if t["name"] == "malware_file_profile")
    assert profile["permitted"] and profile["available"] and profile["arguments_schema"]["required"] == ["evidence_id"]
