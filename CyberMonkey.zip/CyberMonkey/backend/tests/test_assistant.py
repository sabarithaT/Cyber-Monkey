"""AI Orchestrator through the assistant API."""

from __future__ import annotations

import json
import os

import pytest

from app.ai.provider import LLMInfo, set_provider_override
from app.core.constants import Workspace
from app.tools import base as tool_base
from app.tools.base import ToolArgs, ToolResult, ToolSpec
from tests.helpers import create_investigation, findings_document, run_tool, upload


def chat(client, headers, message, **extra):
    resp = client.post("/api/v1/assistant/chat", headers=headers, json={"message": message, **extra})
    assert resp.status_code == 200, resp.text
    return resp.json()


def conversation(client, headers, conversation_id):
    return client.get(f"/api/v1/assistant/conversations/{conversation_id}", headers=headers).json()


def test_spec_example_request_end_to_end(client, admin_headers):
    inv = create_investigation(client, admin_headers, workspace="network")
    ev = upload(client, admin_headers, inv["id"], findings_document(), kind="ids_alerts").json()
    run_tool(client, admin_headers, inv["id"], "network_findings_import", {"evidence_id": ev["id"]})
    reply = chat(
        client,
        admin_headers,
        "Analyze this network scan, identify the most critical findings, correlate them with known "
        "vulnerabilities, and generate a security report.",
        investigation_id=inv["id"],
    )["assistant_message"]
    record = reply["orchestration"]
    assert record["intent"]["router"] == "rules" and record["llm"]["configured"] is False
    actions = [(s["action"], s["status"]) for s in record["plan"]]
    assert actions == [
        ("review_findings", "done"),
        ("enrich_cves", "unavailable"),  # outbound network disabled in tests — reported, not faked
        ("correlate", "done"),
        ("generate_report", "done"),
    ]
    assert record["execution_status"] == "completed_with_issues"
    explanation = record["explanation"]
    assert explanation["mode"] == "template" and explanation["cited"]
    assert record["evidence_references"][0]["evidence"][0]["evidence_id"] == ev["id"]
    report_id = record["plan"][3]["result"]["report_id"]
    assert client.get(f"/api/v1/reports/{report_id}", headers=admin_headers).json()["status"] == "draft"


def test_tool_request_runs_and_follow_up_explains(client, make_user, login):
    make_user("mal@example.org", "malware_analyst")
    mal = login("mal@example.org")
    inv = create_investigation(client, mal, workspace="malware")
    upload(client, mal, inv["id"], os.urandom(2048), kind="malware_sample", filename="dropper.bin")
    data = chat(client, mal, "Profile the suspicious sample and calculate its hashes", investigation_id=inv["id"])
    step = data["assistant_message"]["orchestration"]["plan"][0]
    assert step["tool"] == "malware_file_profile" and step["approval_required"] is False
    assert "Selected the most recent compatible evidence: dropper.bin" in step["detail"]
    messages = conversation(client, mal, data["conversation"]["id"])["messages"]
    assert [m["role"] for m in messages] == ["user", "assistant", "assistant"]
    follow_up = messages[2]["orchestration"]
    assert follow_up["source_run"]["status"] == "succeeded"
    assert follow_up["explanation"]["cited"]  # explanation cites the produced finding
    assert messages[1]["orchestration"]["plan"][0]["status"] == "succeeded"


def test_out_of_role_request_is_refused(client, make_user, login):
    make_user("soc@example.org", "soc_analyst")
    soc = login("soc@example.org")
    inv = create_investigation(client, soc, workspace="soc")
    record = chat(client, soc, "Profile the malware sample", investigation_id=inv["id"])["assistant_message"][
        "orchestration"
    ]
    step = record["plan"][0]
    assert step["status"] == "denied"
    assert "malware" in step["detail"] or "Missing permission" in step["detail"]


def test_requests_without_investigation_ask_for_one(client, admin_headers):
    record = chat(client, admin_headers, "Generate a report")["assistant_message"]["orchestration"]
    assert record["plan"][0]["status"] == "needs_input" and record["execution_status"] == "needs_input"


def test_unmappable_request_gets_clarification(client, admin_headers):
    record = chat(client, admin_headers, "Order me a pizza")["assistant_message"]["orchestration"]
    assert record["plan"] == [] and "could not map" in record["clarification"]


def test_capabilities(client, make_user, login):
    make_user("for@example.org", "forensics_analyst")
    record = chat(client, login("for@example.org"), "What can you do?")["assistant_message"]["orchestration"]
    result = record["plan"][0]["result"]
    assert result["workspaces"] == ["Digital Forensics"]
    assert {t["tool"] for t in result["tools"]} == {"forensics_evidence_profile", "forensics_findings_import"}


class RouterLLM:
    info = LLMInfo("fake", "router-1")

    def __init__(self, steps):
        self.steps = steps

    def generate_text(self, system, prompt, *, temperature=0.2):
        return "Summary of [F-00000000] which does not exist."

    def generate_json(self, system, prompt, schema, *, temperature=0.0):
        assert "<request>" in prompt and "Never invent IDs" in system
        return {"workspace": "malware", "rationale": "test", "steps": self.steps}


def test_llm_proposals_are_validated(client, make_user, login):
    make_user("mal@example.org", "malware_analyst")
    mal = login("mal@example.org")
    inv = create_investigation(client, mal, workspace="malware")
    ev = upload(client, mal, inv["id"], os.urandom(512), kind="malware_sample").json()
    set_provider_override(
        RouterLLM(
            [
                {
                    "action": "run_tool",
                    "tool": "malware_file_profile",
                    "arguments_json": json.dumps({"evidence_id": ev["id"], "command": "calc.exe"}),
                },
                {"action": "run_tool", "tool": "shell_exec", "arguments_json": '{"cmd": "whoami"}'},
            ]
        )
    )
    try:
        record = chat(client, mal, "do it", investigation_id=inv["id"])["assistant_message"]["orchestration"]
    finally:
        set_provider_override(None)
    assert record["intent"]["router"] == "llm"
    first, second = record["plan"]
    assert first["status"] == "rejected" and "Invalid arguments" in first["detail"]
    assert second["status"] == "rejected" and "not a registered tool" in second["detail"]
    assert client.get("/api/v1/tool-runs", headers=mal, params={"investigation_id": inv["id"]}).json()["total"] == 0


def test_llm_explanation_citations_checked(client, make_user, login):
    make_user("mal@example.org", "malware_analyst")
    mal = login("mal@example.org")
    inv = create_investigation(client, mal, workspace="malware")
    ev = upload(client, mal, inv["id"], os.urandom(512), kind="malware_sample").json()
    run_tool(client, mal, inv["id"], "malware_file_profile", {"evidence_id": ev["id"]})
    set_provider_override(RouterLLM([{"action": "review_findings", "tool": None, "arguments_json": "{}"}]))
    try:
        record = chat(client, mal, "explain", investigation_id=inv["id"])["assistant_message"]["orchestration"]
    finally:
        set_provider_override(None)
    issues = record["explanation"]["citation_issues"]
    assert record["explanation"]["mode"] == "llm" and any("F-00000000" in i for i in issues)


@pytest.fixture
def approval_tool():
    class Args(ToolArgs):
        label: str

    spec = ToolSpec(
        name="test_confirm_tool",
        workspace=Workspace.MALWARE,
        title="Confirmation test tool",
        purpose="Test-only tool that requires approval",
        args_model=Args,
        executor=lambda ctx: ToolResult(summary={"label": ctx.args.label}),
        timeout_seconds=5,
        output_format="none",
        requires_approval=True,
    )
    tool_base._load()
    tool_base._REGISTRY[spec.name] = spec
    yield spec
    tool_base._REGISTRY.pop(spec.name, None)


def test_approval_required_tool_waits_then_continues(client, admin_headers, approval_tool):
    inv = create_investigation(client, admin_headers, workspace="malware")
    set_provider_override(
        RouterLLM(
            [
                {"action": "run_tool", "tool": "test_confirm_tool", "arguments_json": '{"label": "x"}'},
                {"action": "assess_risk", "tool": None, "arguments_json": "{}"},
            ]
        )
    )
    try:
        data = chat(client, admin_headers, "run the confirmation tool then score risk", investigation_id=inv["id"])
    finally:
        set_provider_override(None)
    record = data["assistant_message"]["orchestration"]
    assert record["execution_status"] == "awaiting_approval"
    assert [s["status"] for s in record["plan"]] == ["awaiting_approval", "deferred"]
    run_id = record["plan"][0]["run_id"]
    notes = client.get("/api/v1/notifications", headers=admin_headers).json()
    assert notes[0]["kind"] == "approval_required"
    approved = client.post(
        f"/api/v1/tool-runs/{run_id}/approve", headers=admin_headers, json={"note": "lab only"}
    ).json()
    assert approved["status"] == "succeeded" and approved["approved_by"]["email"] == "admin@example.org"
    messages = conversation(client, admin_headers, data["conversation"]["id"])["messages"]
    follow_up = messages[-1]["orchestration"]
    assert [s["action"] for s in follow_up["plan"]] == ["review_findings", "assess_risk"]
    assert follow_up["plan"][1]["status"] == "done"
    assert messages[1]["orchestration"]["plan"][1]["status"] == "continued"


def test_declined_run_is_reported(client, admin_headers, approval_tool):
    inv = create_investigation(client, admin_headers, workspace="malware")
    set_provider_override(
        RouterLLM([{"action": "run_tool", "tool": "test_confirm_tool", "arguments_json": '{"label": "y"}'}])
    )
    try:
        data = chat(client, admin_headers, "run it", investigation_id=inv["id"])
    finally:
        set_provider_override(None)
    run_id = data["assistant_message"]["orchestration"]["plan"][0]["run_id"]
    rejected = client.post(f"/api/v1/tool-runs/{run_id}/reject", headers=admin_headers, json={"note": "not now"}).json()
    assert rejected["status"] == "rejected"
    last = conversation(client, admin_headers, data["conversation"]["id"])["messages"][-1]
    assert last["content"].startswith("The test_confirm_tool run was declined: not now")


def test_conversations_are_private(client, make_user, login, admin_headers):
    data = chat(client, admin_headers, "What can you do?")
    make_user("soc@example.org", "soc_analyst")
    soc = login("soc@example.org")
    assert client.get(f"/api/v1/assistant/conversations/{data['conversation']['id']}", headers=soc).status_code == 404
    assert client.get("/api/v1/assistant/conversations", headers=soc).json() == []
