# Cyber Monkey frontend

React 19 + Vite + TypeScript + Tailwind CSS. See the repository [README](../README.md).

```bash
npm install
npm run dev        # http://localhost:5173, proxies /api to http://127.0.0.1:8000
npm test           # vitest
npm run typecheck
npm run build      # production bundle in dist/ (served by nginx in docker compose)
```
