import type { ReactNode } from 'react'
import { NoAccess } from '../components/ui/States'
import { useAuth } from './AuthContext'

/** Hides a route's content when the user lacks the permission. The backend enforces the
 * same permission on every endpoint; this only avoids showing a page that cannot load. */
export function RequirePermission({ permission, children }: { permission: string; children: ReactNode }) {
  const { can } = useAuth()
  if (!can(permission)) return <NoAccess permission={permission} />
  return <>{children}</>
}
