import { lazy, Suspense, type ComponentType, type ReactNode } from 'react'
import { Route, Routes } from 'react-router-dom'
import { RequirePermission } from './auth/RequirePermission'
import { LoadingState } from './components/ui/States'
import { AppLayout } from './layout/AppLayout'
import { WORKSPACES } from './lib/workspaces'
import { LoginPage } from './pages/LoginPage'
import { NotFoundPage } from './pages/NotFoundPage'

// Route-level code splitting keeps the initial bundle small (charts load with the dashboard).
function page<K extends string>(loader: () => Promise<Record<K, ComponentType<never>>>, name: K) {
  return lazy(async () => ({ default: (await loader())[name] as ComponentType }))
}

const DashboardPage = page(() => import('./pages/DashboardPage'), 'DashboardPage')
const AssistantPage = page(() => import('./pages/AssistantPage'), 'AssistantPage')
const AuditLogsPage = page(() => import('./pages/AuditLogsPage'), 'AuditLogsPage')
const InvestigationsPage = page(() => import('./pages/investigations/InvestigationsPage'), 'InvestigationsPage')
const InvestigationDetailPage = page(() => import('./pages/investigations/InvestigationDetailPage'), 'InvestigationDetailPage')
const ReportsPage = page(() => import('./pages/reports/ReportsPage'), 'ReportsPage')
const ReportDetailPage = page(() => import('./pages/reports/ReportDetailPage'), 'ReportDetailPage')
const SettingsPage = page(() => import('./pages/SettingsPage'), 'SettingsPage')
const ThreatIntelPage = page(() => import('./pages/ThreatIntelPage'), 'ThreatIntelPage')
const WorkspacePageModule = () => import('./pages/WorkspacePage')
const WorkspacePage = lazy(async () => ({ default: (await WorkspacePageModule()).WorkspacePage }))

function guard(permission: string, element: ReactNode) {
  return <RequirePermission permission={permission}>{element}</RequirePermission>
}

export default function App() {
  return (
    <Suspense fallback={<LoadingState />}>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route element={<AppLayout />}>
          <Route index element={guard('dashboard:view', <DashboardPage />)} />
          <Route path="assistant" element={guard('assistant:use', <AssistantPage />)} />
          {WORKSPACES.map((ws) => (
            <Route key={ws.key} path={ws.path.slice(1)} element={guard(`${ws.key}:view`, <WorkspacePage key={ws.key} workspace={ws.key} />)} />
          ))}
          <Route path="threat-intel" element={guard('threat_intel:view', <ThreatIntelPage />)} />
          <Route path="investigations" element={guard('investigations:view', <InvestigationsPage />)} />
          <Route path="investigations/:id" element={guard('investigations:view', <InvestigationDetailPage />)} />
          <Route path="reports" element={guard('reports:view', <ReportsPage />)} />
          <Route path="reports/:id" element={guard('reports:view', <ReportDetailPage />)} />
          <Route path="audit-logs" element={guard('audit:view', <AuditLogsPage />)} />
          <Route path="settings" element={<SettingsPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Route>
      </Routes>
    </Suspense>
  )
}
