import { afterEach, describe, expect, it, vi } from 'vitest'
import { ApiError, buildQuery, errorMessage, request } from '../api/client'

describe('buildQuery', () => {
  it('omits empty values and encodes the rest', () => {
    expect(buildQuery({ page: 2, search: 'a b', empty: '', none: undefined, nil: null, flag: false })).toBe(
      '?page=2&search=a+b&flag=false',
    )
    expect(buildQuery({})).toBe('')
  })
})

describe('errorMessage', () => {
  it('shows the first validation problem with its field', () => {
    const error = new ApiError(422, {
      code: 'validation_failed',
      message: 'Request validation failed',
      details: [{ loc: ['body', 'password'], msg: 'Value error, Password must be at least 12 characters' }],
    })
    expect(errorMessage(error)).toBe('password: Password must be at least 12 characters')
  })

  it('falls back to the server message', () => {
    expect(errorMessage(new ApiError(403, { code: 'permission_denied', message: 'Missing permission: audit:view' }))).toBe(
      'Missing permission: audit:view',
    )
  })
})

describe('request', () => {
  afterEach(() => vi.unstubAllGlobals())

  it('sends the anti-CSRF header and parses the error envelope', async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ error: { code: 'not_found', message: 'Investigation not found' } }), {
        status: 404,
        headers: { 'content-type': 'application/json' },
      }),
    )
    vi.stubGlobal('fetch', fetchMock)
    await expect(request('POST', '/investigations', { body: { title: 'x' } })).rejects.toMatchObject({
      status: 404,
      code: 'not_found',
      message: 'Investigation not found',
    })
    const [url, init] = fetchMock.mock.calls[0]
    expect(url).toBe('/api/v1/investigations')
    expect(init.headers['X-CM-Client']).toBe('web')
    expect(init.credentials).toBe('same-origin')
  })
})
