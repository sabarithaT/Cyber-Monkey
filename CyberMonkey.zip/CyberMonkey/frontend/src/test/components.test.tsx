import { render, screen } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { describe, expect, it, vi } from 'vitest'
import { DemoBadge, SeverityBadge, StatusBadge } from '../components/ui/Badge'

const permissions = new Set(['dashboard:view', 'soc:view'])
vi.mock('../auth/AuthContext', () => ({
  useAuth: () => ({ can: (p: string) => permissions.has(p), user: null, loading: false }),
}))

describe('badges', () => {
  it('renders severity and status labels', () => {
    render(
      <>
        <SeverityBadge severity="critical" />
        <StatusBadge status="pending_approval" />
        <DemoBadge />
      </>,
    )
    expect(screen.getByText('critical')).toBeInTheDocument()
    expect(screen.getByText('Pending Approval')).toBeInTheDocument()
    expect(screen.getByText(/demo data/i)).toBeInTheDocument()
  })
})

describe('permission-aware navigation', () => {
  it('links permitted items and marks the rest as locked', async () => {
    const { Sidebar } = await import('../layout/Sidebar')
    render(
      <MemoryRouter>
        <Sidebar />
      </MemoryRouter>,
    )
    expect(screen.getByRole('link', { name: /SOC Monitoring/ })).toBeInTheDocument()
    expect(screen.queryByRole('link', { name: /Malware Analysis/ })).not.toBeInTheDocument()
    expect(screen.getByTitle('Requires the malware:view permission')).toHaveAttribute('aria-disabled', 'true')
    expect(screen.getByRole('link', { name: /Settings/ })).toBeInTheDocument()
  })

  it('shows a no-access state instead of a page the user cannot load', async () => {
    const { RequirePermission } = await import('../auth/RequirePermission')
    render(
      <RequirePermission permission="audit:view">
        <p>secret page</p>
      </RequirePermission>,
    )
    expect(screen.queryByText('secret page')).not.toBeInTheDocument()
    expect(screen.getByText(/do not have access/i)).toBeInTheDocument()
  })
})
