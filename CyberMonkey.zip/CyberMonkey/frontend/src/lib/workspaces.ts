import {
  Activity,
  Bug,
  Crosshair,
  Fingerprint,
  Globe,
  Network,
  type LucideIcon,
} from 'lucide-react'
import type { WorkspaceKey } from '../api/types'

export interface WorkspaceMeta {
  key: WorkspaceKey
  label: string
  short: string
  path: string
  icon: LucideIcon
  description: string
}

export const WORKSPACES: WorkspaceMeta[] = [
  { key: 'soc', label: 'SOC Monitoring', short: 'SOC', path: '/workspaces/soc', icon: Activity,
    description: 'Import authorized security logs, triage alerts and track incidents.' },
  { key: 'pentest', label: 'Penetration Testing', short: 'Pentest', path: '/workspaces/pentest', icon: Crosshair,
    description: 'Scoped, authorized reconnaissance against registered targets.' },
  { key: 'osint', label: 'OSINT Investigation', short: 'OSINT', path: '/workspaces/osint', icon: Globe,
    description: 'Public-source information about domains and usernames.' },
  { key: 'malware', label: 'Malware Analysis', short: 'Malware', path: '/workspaces/malware', icon: Bug,
    description: 'Static analysis of suspicious files and sandbox report import.' },
  { key: 'forensics', label: 'Digital Forensics', short: 'Forensics', path: '/workspaces/forensics', icon: Fingerprint,
    description: 'Evidence registration, provenance and forensic tool output.' },
  { key: 'network', label: 'Network Monitoring', short: 'Network', path: '/workspaces/network', icon: Network,
    description: 'Packet captures, flows and IDS alerts.' },
]

export const WORKSPACE_BY_KEY = Object.fromEntries(WORKSPACES.map((w) => [w.key, w])) as Record<
  WorkspaceKey,
  WorkspaceMeta
>
