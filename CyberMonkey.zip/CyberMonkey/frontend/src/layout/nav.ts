import {
  Bot,
  FileText,
  FolderSearch,
  LayoutDashboard,
  ScrollText,
  Settings,
  ShieldAlert,
  type LucideIcon,
} from 'lucide-react'
import { WORKSPACES } from '../lib/workspaces'

export interface NavItem {
  label: string
  path: string
  icon: LucideIcon
  permission: string | null
}

export interface NavSection {
  title: string
  items: NavItem[]
}

export const NAV: NavSection[] = [
  {
    title: 'Operations',
    items: [
      { label: 'Overview Dashboard', path: '/', icon: LayoutDashboard, permission: 'dashboard:view' },
      { label: 'AI Assistant', path: '/assistant', icon: Bot, permission: 'assistant:use' },
    ],
  },
  {
    title: 'Workspaces',
    items: WORKSPACES.map((ws) => ({ label: ws.label, path: ws.path, icon: ws.icon, permission: `${ws.key}:view` })),
  },
  {
    title: 'Intelligence & Cases',
    items: [
      { label: 'Threat Intelligence', path: '/threat-intel', icon: ShieldAlert, permission: 'threat_intel:view' },
      { label: 'Investigations', path: '/investigations', icon: FolderSearch, permission: 'investigations:view' },
      { label: 'Reports', path: '/reports', icon: FileText, permission: 'reports:view' },
    ],
  },
  {
    title: 'Administration',
    items: [
      { label: 'Audit Logs', path: '/audit-logs', icon: ScrollText, permission: 'audit:view' },
      { label: 'Settings', path: '/settings', icon: Settings, permission: null },
    ],
  },
]
