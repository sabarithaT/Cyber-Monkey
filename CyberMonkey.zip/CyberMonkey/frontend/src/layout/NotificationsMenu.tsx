import { useQuery } from '@tanstack/react-query'
import { Bell } from 'lucide-react'
import { useCallback, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api/client'
import { formatRelative } from '../lib/format'
import { Spinner } from '../components/ui/States'
import { useClickOutside } from './Topbar'

interface Notification {
  kind: string
  title: string
  detail: string
  link: string
  occurred_at: string
}

export function NotificationsMenu() {
  const [open, setOpen] = useState(false)
  const close = useCallback(() => setOpen(false), [])
  const ref = useClickOutside(close)
  const query = useQuery({
    queryKey: ['notifications'],
    queryFn: () => api.get<Notification[]>('/notifications'),
    refetchInterval: 30_000,
  })
  const count = query.data?.length ?? 0

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="relative rounded p-2 text-fg-muted hover:bg-surface-3 hover:text-fg"
        aria-label={`Notifications${count ? ` (${count})` : ''}`}
        aria-expanded={open}
      >
        <Bell className="size-5" />
        {count > 0 ? (
          <span className="absolute right-1 top-1 flex min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-semibold leading-4 text-white">
            {count}
          </span>
        ) : null}
      </button>
      {open ? (
        <div className="absolute right-0 z-40 mt-2 w-80 max-w-[calc(100vw-2rem)] rounded-md border border-line-strong bg-surface-2 shadow-xl">
          <p className="border-b border-line px-3 py-2 text-xs font-semibold uppercase tracking-wide text-fg-subtle">
            Notifications
          </p>
          <div className="max-h-96 overflow-y-auto">
            {query.isLoading ? (
              <div className="p-4">
                <Spinner label="Loading" />
              </div>
            ) : query.isError ? (
              <p className="p-4 text-xs text-rose-300">Could not load notifications.</p>
            ) : count === 0 ? (
              <p className="p-4 text-xs text-fg-muted">
                Nothing needs your attention. Approvals, finished tool runs and reports awaiting review appear here.
              </p>
            ) : (
              <ul>
                {query.data!.map((n, index) => (
                  <li key={`${n.link}-${index}`} className="border-b border-line/60 last:border-0">
                    <Link to={n.link} onClick={close} className="block px-3 py-2.5 hover:bg-surface-3">
                      <p className="text-sm text-fg">{n.title}</p>
                      <p className="mt-0.5 text-xs text-fg-muted">{n.detail}</p>
                      <p className="mt-0.5 text-[11px] text-fg-subtle">{formatRelative(n.occurred_at)}</p>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      ) : null}
    </div>
  )
}
