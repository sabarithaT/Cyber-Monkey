import { useState } from 'react'
import { Navigate, Outlet, useLocation } from 'react-router-dom'
import { useAuth } from '../auth/AuthContext'
import { ErrorBoundary } from '../components/ErrorBoundary'
import { LoadingState } from '../components/ui/States'
import { Sidebar } from './Sidebar'
import { Topbar } from './Topbar'

export function AppLayout() {
  const { user, loading } = useAuth()
  const location = useLocation()
  const [drawer, setDrawer] = useState(false)

  if (loading) return <LoadingState label="Checking session…" />
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname + location.search }} />

  return (
    <div className="flex h-full">
      <aside className="hidden w-64 shrink-0 border-r border-line bg-surface lg:block">
        <Sidebar />
      </aside>
      {drawer ? (
        <div className="fixed inset-0 z-40 lg:hidden" role="dialog" aria-modal="true">
          <button
            type="button"
            className="absolute inset-0 bg-black/60"
            onClick={() => setDrawer(false)}
            aria-label="Close navigation"
          />
          <aside className="relative h-full w-72 max-w-[85vw] border-r border-line bg-surface">
            <Sidebar onNavigate={() => setDrawer(false)} />
          </aside>
        </div>
      ) : null}
      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar onMenu={() => setDrawer(true)} />
        <main className="flex-1 overflow-y-auto">
          <div className="mx-auto w-full max-w-[1400px] px-4 py-6 sm:px-6 lg:px-8">
            <ErrorBoundary resetKey={location.pathname}>
              <Outlet />
            </ErrorBoundary>
          </div>
        </main>
      </div>
    </div>
  )
}
