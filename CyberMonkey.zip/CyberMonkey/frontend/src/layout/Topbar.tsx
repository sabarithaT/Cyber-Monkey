import { LogOut, Menu, Settings, UserRound } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../auth/AuthContext'
import { NotificationsMenu } from './NotificationsMenu'

function useClickOutside(onOutside: () => void) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    function handle(event: MouseEvent) {
      if (ref.current && !ref.current.contains(event.target as Node)) onOutside()
    }
    document.addEventListener('mousedown', handle)
    return () => document.removeEventListener('mousedown', handle)
  }, [onOutside])
  return ref
}

export { useClickOutside }

export function Topbar({ onMenu }: { onMenu: () => void }) {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const ref = useClickOutside(() => setOpen(false))
  if (!user) return null
  const roleLabel = user.roles.map((r) => r.name).join(', ') || 'No role assigned'

  return (
    <header className="flex h-14 shrink-0 items-center gap-3 border-b border-line bg-surface/80 px-4 backdrop-blur">
      <button
        type="button"
        onClick={onMenu}
        className="rounded p-1.5 text-fg-muted hover:bg-surface-3 hover:text-fg lg:hidden"
        aria-label="Open navigation"
      >
        <Menu className="size-5" />
      </button>
      <div className="flex-1" />
      <NotificationsMenu />
      <div className="relative" ref={ref}>
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="flex items-center gap-2.5 rounded-md px-2 py-1 hover:bg-surface-3"
          aria-haspopup="menu"
          aria-expanded={open}
        >
          <span className="flex size-8 items-center justify-center rounded-full bg-accent-soft text-xs font-semibold text-accent">
            {user.full_name
              .split(/\s+/)
              .map((part) => part[0])
              .slice(0, 2)
              .join('')
              .toUpperCase()}
          </span>
          <span className="hidden text-left leading-tight sm:block">
            <span className="block max-w-48 truncate text-sm text-fg">{user.full_name}</span>
            <span className="block max-w-48 truncate text-[11px] text-fg-subtle">{roleLabel}</span>
          </span>
        </button>
        {open ? (
          <div
            className="absolute right-0 z-40 mt-2 w-64 rounded-md border border-line-strong bg-surface-2 py-1 shadow-xl"
            role="menu"
          >
            <div className="border-b border-line px-3 py-2">
              <p className="truncate text-sm text-fg">{user.email}</p>
              <p className="truncate text-[11px] text-fg-subtle">{roleLabel}</p>
            </div>
            <Link
              to="/settings"
              onClick={() => setOpen(false)}
              className="flex items-center gap-2 px-3 py-2 text-sm text-fg-muted hover:bg-surface-3 hover:text-fg"
              role="menuitem"
            >
              <UserRound className="size-4" /> Profile & password
            </Link>
            <Link
              to="/settings"
              onClick={() => setOpen(false)}
              className="flex items-center gap-2 px-3 py-2 text-sm text-fg-muted hover:bg-surface-3 hover:text-fg"
              role="menuitem"
            >
              <Settings className="size-4" /> Account settings
            </Link>
            <button
              type="button"
              onClick={async () => {
                setOpen(false)
                await logout()
                navigate('/login')
              }}
              className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm text-fg-muted hover:bg-surface-3 hover:text-fg"
              role="menuitem"
            >
              <LogOut className="size-4" /> Log out
            </button>
          </div>
        ) : null}
      </div>
    </header>
  )
}
