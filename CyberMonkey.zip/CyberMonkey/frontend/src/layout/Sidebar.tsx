import clsx from 'clsx'
import { Lock } from 'lucide-react'
import { NavLink } from 'react-router-dom'
import { useAuth } from '../auth/AuthContext'
import { NAV } from './nav'

export function Logo() {
  return (
    <div className="flex items-center gap-2.5">
      <img src="/favicon.svg" alt="" className="size-8" />
      <div className="leading-tight">
        <p className="text-sm font-semibold tracking-wide text-fg">CYBER MONKEY</p>
        <p className="text-[10px] uppercase tracking-[0.18em] text-fg-subtle">Unified SecOps</p>
      </div>
    </div>
  )
}

export function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const { can } = useAuth()
  return (
    <nav className="flex h-full flex-col" aria-label="Main navigation">
      <div className="flex h-14 shrink-0 items-center border-b border-line px-4">
        <Logo />
      </div>
      <div className="flex-1 space-y-5 overflow-y-auto px-2 py-4">
        {NAV.map((section) => (
          <div key={section.title}>
            <p className="px-2 pb-1.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-fg-subtle">
              {section.title}
            </p>
            <ul className="space-y-0.5">
              {section.items.map((item) => {
                const allowed = item.permission === null || can(item.permission)
                const Icon = item.icon
                if (!allowed) {
                  return (
                    <li key={item.path}>
                      <span
                        className="flex cursor-not-allowed items-center gap-2.5 rounded-md px-2 py-1.5 text-sm text-fg-subtle/70"
                        title={`Requires the ${item.permission} permission`}
                        aria-disabled="true"
                      >
                        <Icon className="size-4 shrink-0" />
                        <span className="flex-1 truncate">{item.label}</span>
                        <Lock className="size-3 shrink-0" aria-label="No access" />
                      </span>
                    </li>
                  )
                }
                return (
                  <li key={item.path}>
                    <NavLink
                      to={item.path}
                      end={item.path === '/'}
                      onClick={onNavigate}
                      className={({ isActive }) =>
                        clsx(
                          'flex items-center gap-2.5 rounded-md px-2 py-1.5 text-sm transition-colors',
                          isActive
                            ? 'bg-accent-soft font-medium text-accent'
                            : 'text-fg-muted hover:bg-surface-3 hover:text-fg',
                        )
                      }
                    >
                      <Icon className="size-4 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </NavLink>
                  </li>
                )
              })}
            </ul>
          </div>
        ))}
      </div>
      <p className="border-t border-line px-4 py-3 text-[10px] leading-relaxed text-fg-subtle">
        Use only against systems you are authorized to assess.
      </p>
    </nav>
  )
}
