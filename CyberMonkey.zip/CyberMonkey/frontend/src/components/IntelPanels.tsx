import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Calculator, Link2, RefreshCw } from 'lucide-react'
import { api, errorMessage } from '../api/client'
import type { Correlation, RiskAssessment, RiskComponent } from '../api/models'
import { useAuth } from '../auth/AuthContext'
import { formatDateTime } from '../lib/format'
import { Badge, StatusBadge } from './ui/Badge'
import { Button } from './ui/Button'
import { CardHeader } from './ui/Card'
import { Alert, EmptyState, ErrorState, LoadingState } from './ui/States'
import { DataTable } from './ui/Table'
import { useToast } from './ui/Toast'

function pct(value: number | null) {
  return value === null ? '—' : `${Math.round(value * 100)}`
}

function ComponentBar({ c }: { c: RiskComponent }) {
  const width = c.value === null ? 0 : Math.round(c.value * 100)
  return (
    <div className="rounded-md border border-line bg-surface-2 p-3">
      <div className="flex items-center justify-between gap-2">
        <p className="text-sm font-medium">{c.label}</p>
        <div className="flex items-center gap-2">
          <span className="text-xs text-fg-subtle">weight {c.weight.toFixed(2)}</span>
          <StatusBadge status={c.status === 'evaluated' ? 'available' : 'not_configured'} label={c.status === 'evaluated' ? `value ${c.value?.toFixed(2)}` : 'missing data'} />
        </div>
      </div>
      <div className="mt-2 h-2 overflow-hidden rounded bg-canvas" aria-hidden="true">
        {c.status === 'evaluated' ? (
          <div className="h-full rounded bg-accent" style={{ width: `${width}%` }} />
        ) : (
          <div className="h-full w-full bg-[repeating-linear-gradient(45deg,transparent,transparent_4px,rgb(100_116_139/0.35)_4px,rgb(100_116_139/0.35)_8px)]" />
        )}
      </div>
      <p className="mt-2 text-xs text-fg-muted">{c.explanation}</p>
      {c.contributors.length ? (
        <ul className="mt-2 space-y-0.5 text-[11px] text-fg-subtle">
          {c.contributors.slice(0, 5).map((item, i) => (
            <li key={i} className="font-mono">
              {String(item.reference ?? item.indicator ?? '')}
              {item.cvss !== undefined ? ` · CVSS ${String(item.cvss)}` : ''}
              {item.tactic_weight !== undefined ? ` · tactic weight ${String(item.tactic_weight)}` : ''}
              {Array.isArray(item.reasons) ? ` · ${(item.reasons as string[]).join('; ')}` : ''}
            </li>
          ))}
        </ul>
      ) : null}
      {c.excluded.length ? (
        <p className="mt-2 text-[11px] text-amber-300/80">
          {c.excluded.length} reference(s) excluded — {String(c.excluded[0].reason)}
        </p>
      ) : null}
    </div>
  )
}

export function RiskPanel({ investigationId }: { investigationId: string }) {
  const toast = useToast()
  const queryClient = useQueryClient()
  const { can } = useAuth()
  const history = useQuery({
    queryKey: ['risk', investigationId],
    queryFn: () => api.get<RiskAssessment[]>(`/threat-intelligence/risk/${investigationId}`),
  })
  const compute = useMutation({
    mutationFn: () => api.post<RiskAssessment>(`/threat-intelligence/risk/${investigationId}`),
    onSuccess: () => {
      toast.success('Risk score recomputed from current findings')
      queryClient.invalidateQueries({ queryKey: ['risk', investigationId] })
    },
    onError: (e) => toast.error(errorMessage(e)),
  })
  const enrich = useMutation({
    mutationFn: () => api.post<{ queued: number; status: string; detail: string }>('/threat-intelligence/enrich-cves', { investigation_id: investigationId }),
    onSuccess: (r) => (r.status === 'queued' ? toast.success(`${r.queued} CVE(s) queued for NVD enrichment`) : toast.info(r.detail)),
    onError: (e) => toast.error(errorMessage(e)),
  })
  const latest = history.data?.[0]

  return (
    <>
      <CardHeader
        title="Risk score"
        subtitle="S = w_c·C(F) + w_m·M(F) + w_i·I(F) — a transparent prioritization aid, not a probability of compromise."
        actions={
          <>
            {can('threat_intel:enrich') ? (
              <Button size="sm" variant="ghost" icon={RefreshCw} loading={enrich.isPending} onClick={() => enrich.mutate()}>Enrich CVEs</Button>
            ) : null}
            <Button size="sm" variant="primary" icon={Calculator} loading={compute.isPending} onClick={() => compute.mutate()}>Compute now</Button>
          </>
        }
      />
      <div className="p-4">
        {history.isLoading ? <LoadingState /> : history.error ? <ErrorState error={history.error} /> : !latest ? (
          <EmptyState icon={Calculator} title="No risk score computed yet" description="Compute the score to see each component, the evidence behind it and what is missing." />
        ) : (
          <div className="space-y-4">
            <div className="flex flex-wrap items-end gap-6">
              <div>
                <p className="text-xs uppercase tracking-wide text-fg-subtle">Score (evaluated components)</p>
                <p className="text-4xl font-semibold tabular-nums text-accent">{pct(latest.score)}<span className="text-lg text-fg-subtle">/100</span></p>
              </div>
              <div className="text-sm text-fg-muted">
                <p>Coverage <span className="tabular-nums text-fg">{Math.round(latest.coverage * 100)}%</span> of scoring weight evaluated</p>
                <p>Possible range <span className="tabular-nums text-fg">{pct(latest.lower_bound)}–{pct(latest.upper_bound)}</span> once missing data is known</p>
                <p className="text-xs text-fg-subtle">{latest.finding_count} active findings · computed {formatDateTime(latest.computed_at)}</p>
              </div>
            </div>
            {latest.components.missing.length ? (
              <Alert tone="warning" title="Some components have no data">
                Missing components are not treated as zero risk. They narrow the score once the evidence exists.
              </Alert>
            ) : null}
            <div className="grid gap-3 lg:grid-cols-3">
              {latest.components.items.map((c) => (
                <ComponentBar key={c.key} c={c} />
              ))}
            </div>
            {history.data && history.data.length > 1 ? (
              <p className="text-xs text-fg-subtle">
                History: {history.data.slice(0, 8).map((h) => `${pct(h.score)} (${formatDateTime(h.computed_at)})`).join(' · ')}
              </p>
            ) : null}
          </div>
        )}
      </div>
    </>
  )
}

export function CorrelationPanel({ investigationId }: { investigationId: string }) {
  const query = useQuery({
    queryKey: ['correlations', investigationId],
    queryFn: () => api.get<Correlation[]>('/threat-intelligence/correlations', { investigation_id: investigationId }),
  })
  return (
    <>
      <CardHeader
        title="Indicators & correlation"
        subtitle="Indicators shared across workspaces or with other investigations you can access. Correlation raises priority; it is not a verdict that an indicator is malicious."
      />
      <DataTable
        rows={query.data}
        loading={query.isLoading}
        error={query.error}
        onRetry={() => query.refetch()}
        rowKey={(c) => c.indicator_id}
        dense
        empty={<EmptyState icon={Link2} title="No indicators yet" description="Indicators are extracted from findings (IPs, domains, URLs, hashes, emails)." />}
        columns={[
          { key: 'ioc', header: 'Indicator', render: (c) => <span className="font-mono text-xs">{c.type}:{c.value}</span> },
          { key: 'internal', header: 'Scope', render: (c) => (c.is_internal ? <Badge>internal</Badge> : <Badge tone="info">external</Badge>) },
          { key: 'ws', header: 'Workspaces', render: (c) => <span className="text-xs">{c.workspaces.join(', ')}</span> },
          { key: 'f', header: 'Findings', render: (c) => <span className="text-xs tabular-nums">{c.finding_ids.length}</span> },
          {
            key: 'corr',
            header: 'Correlation',
            render: (c) => (c.correlated ? <span className="text-xs text-amber-200">{c.reasons.join('; ')}</span> : <span className="text-xs text-fg-subtle">single source</span>),
          },
        ]}
      />
    </>
  )
}
