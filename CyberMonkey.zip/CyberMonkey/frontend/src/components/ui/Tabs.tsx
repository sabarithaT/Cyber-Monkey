import clsx from 'clsx'
import type { ReactNode } from 'react'

export interface TabItem {
  key: string
  label: ReactNode
  count?: number
}

export function Tabs({ items, active, onChange }: { items: TabItem[]; active: string; onChange: (key: string) => void }) {
  return (
    <div className="mb-4 overflow-x-auto border-b border-line" role="tablist">
      <div className="flex min-w-max gap-1">
        {items.map((item) => (
          <button
            key={item.key}
            type="button"
            role="tab"
            aria-selected={item.key === active}
            onClick={() => onChange(item.key)}
            className={clsx(
              '-mb-px inline-flex items-center gap-2 border-b-2 px-3 py-2 text-sm transition-colors',
              item.key === active
                ? 'border-accent text-fg'
                : 'border-transparent text-fg-muted hover:border-line-strong hover:text-fg',
            )}
          >
            {item.label}
            {item.count !== undefined ? (
              <span className="rounded bg-surface-3 px-1.5 text-[11px] tabular-nums text-fg-muted">{item.count}</span>
            ) : null}
          </button>
        ))}
      </div>
    </div>
  )
}
