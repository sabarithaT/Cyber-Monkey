import clsx from 'clsx'
import { CheckCircle2, Info, X, XCircle } from 'lucide-react'
import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react'

type ToastTone = 'success' | 'error' | 'info'
interface ToastItem {
  id: number
  tone: ToastTone
  message: string
}

interface ToastApi {
  success: (message: string) => void
  error: (message: string) => void
  info: (message: string) => void
}

const ToastContext = createContext<ToastApi | null>(null)
let nextId = 1

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastItem[]>([])

  const dismiss = useCallback((id: number) => setToasts((items) => items.filter((t) => t.id !== id)), [])
  const push = useCallback(
    (tone: ToastTone, message: string) => {
      const id = nextId++
      setToasts((items) => [...items.slice(-3), { id, tone, message }])
      window.setTimeout(() => dismiss(id), tone === 'error' ? 8000 : 4500)
    },
    [dismiss],
  )
  const api = useMemo<ToastApi>(
    () => ({
      success: (m) => push('success', m),
      error: (m) => push('error', m),
      info: (m) => push('info', m),
    }),
    [push],
  )

  return (
    <ToastContext.Provider value={api}>
      {children}
      <div className="pointer-events-none fixed inset-x-4 bottom-4 z-50 flex flex-col items-end gap-2 sm:inset-x-auto sm:right-4" aria-live="polite">
        {toasts.map((toast) => {
          const Icon = toast.tone === 'success' ? CheckCircle2 : toast.tone === 'error' ? XCircle : Info
          return (
            <div
              key={toast.id}
              className={clsx(
                'pointer-events-auto flex w-full max-w-sm items-start gap-2.5 rounded-md border bg-surface-2 px-3 py-2.5 text-sm shadow-lg',
                toast.tone === 'success' && 'border-emerald-500/40',
                toast.tone === 'error' && 'border-rose-500/40',
                toast.tone === 'info' && 'border-sky-500/40',
              )}
              role={toast.tone === 'error' ? 'alert' : 'status'}
            >
              <Icon
                className={clsx(
                  'mt-0.5 size-4 shrink-0',
                  toast.tone === 'success' && 'text-emerald-400',
                  toast.tone === 'error' && 'text-rose-400',
                  toast.tone === 'info' && 'text-sky-400',
                )}
              />
              <p className="min-w-0 flex-1 break-words text-fg">{toast.message}</p>
              <button type="button" onClick={() => dismiss(toast.id)} className="text-fg-subtle hover:text-fg" aria-label="Dismiss">
                <X className="size-4" />
              </button>
            </div>
          )
        })}
      </div>
    </ToastContext.Provider>
  )
}

export function useToast(): ToastApi {
  const ctx = useContext(ToastContext)
  if (!ctx) throw new Error('useToast must be used inside ToastProvider')
  return ctx
}
