import clsx from 'clsx'
import type { ReactNode } from 'react'
import type { Severity } from '../../api/types'
import { titleCase } from '../../lib/format'

type Tone = 'neutral' | 'accent' | 'success' | 'warning' | 'danger' | 'info' | 'violet'

const tones: Record<Tone, string> = {
  neutral: 'bg-slate-500/15 text-slate-300 ring-slate-500/30',
  accent: 'bg-accent-soft text-accent ring-accent/30',
  success: 'bg-emerald-500/15 text-emerald-300 ring-emerald-500/30',
  warning: 'bg-amber-500/15 text-amber-300 ring-amber-500/30',
  danger: 'bg-rose-500/15 text-rose-300 ring-rose-500/30',
  info: 'bg-sky-500/15 text-sky-300 ring-sky-500/30',
  violet: 'bg-violet-500/15 text-violet-300 ring-violet-500/30',
}

export function Badge({ tone = 'neutral', children, className }: { tone?: Tone; children: ReactNode; className?: string }) {
  return (
    <span
      className={clsx(
        'inline-flex items-center gap-1 whitespace-nowrap rounded px-1.5 py-0.5 text-[11px] font-medium ring-1 ring-inset',
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  )
}

const severityStyles: Record<Severity, string> = {
  critical: 'bg-sev-critical/15 text-rose-300 ring-sev-critical/40',
  high: 'bg-sev-high/15 text-orange-300 ring-sev-high/40',
  medium: 'bg-sev-medium/15 text-yellow-200 ring-sev-medium/40',
  low: 'bg-sev-low/15 text-blue-300 ring-sev-low/40',
  info: 'bg-sev-info/15 text-slate-300 ring-sev-info/40',
}

const severityDots: Record<Severity, string> = {
  critical: 'bg-sev-critical',
  high: 'bg-sev-high',
  medium: 'bg-sev-medium',
  low: 'bg-sev-low',
  info: 'bg-sev-info',
}

export function SeverityBadge({ severity }: { severity: Severity }) {
  return (
    <span
      className={clsx(
        'inline-flex items-center gap-1.5 whitespace-nowrap rounded px-1.5 py-0.5 text-[11px] font-semibold uppercase tracking-wide ring-1 ring-inset',
        severityStyles[severity] ?? severityStyles.info,
      )}
    >
      <span className={clsx('size-1.5 rounded-full', severityDots[severity] ?? severityDots.info)} />
      {severity}
    </span>
  )
}

const statusTones: Record<string, Tone> = {
  // runs
  pending_approval: 'warning',
  queued: 'info',
  running: 'info',
  succeeded: 'success',
  failed: 'danger',
  timed_out: 'danger',
  rejected: 'neutral',
  unavailable: 'neutral',
  // findings / investigations
  open: 'warning',
  in_progress: 'info',
  investigating: 'info',
  resolved: 'success',
  closed: 'neutral',
  false_positive: 'neutral',
  // validation
  unverified: 'neutral',
  supported: 'info',
  confirmed: 'success',
  candidate: 'warning',
  // reports
  draft: 'neutral',
  in_review: 'info',
  changes_requested: 'warning',
  approved: 'success',
  // audit
  success: 'success',
  failure: 'danger',
  denied: 'warning',
  // integrations
  available: 'success',
  not_configured: 'neutral',
  disabled: 'neutral',
}

export function StatusBadge({ status, label }: { status: string; label?: string }) {
  return <Badge tone={statusTones[status] ?? 'neutral'}>{label ?? titleCase(status)}</Badge>
}

export function DemoBadge() {
  return (
    <Badge tone="violet" className="uppercase tracking-wide">
      Demo data
    </Badge>
  )
}
