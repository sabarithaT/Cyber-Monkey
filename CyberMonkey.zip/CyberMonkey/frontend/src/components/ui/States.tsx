import { AlertTriangle, Inbox, Loader2, Lock, PlugZap, type LucideIcon } from 'lucide-react'
import type { ReactNode } from 'react'
import { errorMessage } from '../../api/client'
import { Button } from './Button'

export function Spinner({ label }: { label?: string }) {
  return (
    <span className="inline-flex items-center gap-2 text-sm text-fg-muted">
      <Loader2 className="size-4 animate-spin" />
      {label}
    </span>
  )
}

export function LoadingState({ label = 'Loading…' }: { label?: string }) {
  return (
    <div className="flex min-h-32 items-center justify-center p-6" role="status">
      <Spinner label={label} />
    </div>
  )
}

export function EmptyState({
  title,
  description,
  action,
  icon: Icon = Inbox,
}: {
  title: string
  description?: ReactNode
  action?: ReactNode
  icon?: LucideIcon
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 px-6 py-10 text-center">
      <Icon className="size-8 text-fg-subtle" />
      <p className="text-sm font-medium text-fg">{title}</p>
      {description ? <div className="max-w-md text-xs text-fg-muted">{description}</div> : null}
      {action ? <div className="mt-2">{action}</div> : null}
    </div>
  )
}

export function ErrorState({ error, onRetry }: { error: unknown; onRetry?: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 px-6 py-10 text-center" role="alert">
      <AlertTriangle className="size-8 text-rose-400" />
      <p className="text-sm font-medium text-fg">Could not load this data</p>
      <p className="max-w-md text-xs text-fg-muted">{errorMessage(error)}</p>
      {onRetry ? (
        <Button size="sm" onClick={onRetry} className="mt-2">
          Retry
        </Button>
      ) : null}
    </div>
  )
}

export function Alert({
  tone = 'info',
  title,
  children,
}: {
  tone?: 'info' | 'warning' | 'danger' | 'success'
  title?: ReactNode
  children?: ReactNode
}) {
  const styles = {
    info: 'border-sky-500/30 bg-sky-500/10 text-sky-100',
    warning: 'border-amber-500/30 bg-amber-500/10 text-amber-100',
    danger: 'border-rose-500/30 bg-rose-500/10 text-rose-100',
    success: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-100',
  }[tone]
  return (
    <div className={`rounded-md border px-3 py-2.5 text-sm ${styles}`} role={tone === 'danger' ? 'alert' : 'status'}>
      {title ? <p className="font-medium">{title}</p> : null}
      {children ? <div className={title ? 'mt-1 text-xs opacity-90' : 'text-xs'}>{children}</div> : null}
    </div>
  )
}

export function NoAccess({ permission }: { permission: string }) {
  return (
    <EmptyState
      icon={Lock}
      title="You do not have access to this area"
      description={
        <>
          It requires the <code className="font-mono text-fg">{permission}</code> permission. An administrator can grant
          it through a role or a direct permission.
        </>
      }
    />
  )
}

export function NotConfigured({ title, detail, howTo }: { title: string; detail: ReactNode; howTo?: ReactNode }) {
  return (
    <div className="flex items-start gap-3 rounded-md border border-line bg-surface-2 p-3">
      <PlugZap className="mt-0.5 size-4 shrink-0 text-fg-subtle" />
      <div className="min-w-0 text-xs">
        <p className="font-medium text-fg">{title}</p>
        <p className="mt-0.5 text-fg-muted">{detail}</p>
        {howTo ? <p className="mt-1 text-fg-subtle">{howTo}</p> : null}
      </div>
    </div>
  )
}
