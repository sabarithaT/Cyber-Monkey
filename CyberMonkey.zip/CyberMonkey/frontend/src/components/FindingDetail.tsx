import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { ExternalLink } from 'lucide-react'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { api, errorMessage } from '../api/client'
import type { Finding, Note } from '../api/models'
import { useAuth } from '../auth/AuthContext'
import { formatDateTime, shortId, titleCase } from '../lib/format'
import { Badge, SeverityBadge, StatusBadge } from './ui/Badge'
import { Button } from './ui/Button'
import { CodeBlock, KeyValue } from './ui/Card'
import { Select, Textarea } from './ui/Form'
import { Modal } from './ui/Modal'
import { ErrorState, LoadingState } from './ui/States'
import { useToast } from './ui/Toast'

const ORIGIN_LABEL: Record<Finding['origin'], string> = {
  tool: 'Tool output',
  rule: 'Detection rule',
  import: 'Imported report',
  analyst: 'Analyst entry',
}

export function FindingDetail({ findingId, onClose }: { findingId: string | null; onClose: () => void }) {
  const { can } = useAuth()
  const toast = useToast()
  const queryClient = useQueryClient()
  const [note, setNote] = useState('')
  const query = useQuery({
    queryKey: ['finding', findingId],
    queryFn: () => api.get<Finding>(`/findings/${findingId}`),
    enabled: !!findingId,
  })
  const notes = useQuery({
    queryKey: ['notes', query.data?.investigation_id, findingId],
    queryFn: () => api.get<Note[]>(`/investigations/${query.data!.investigation_id}/notes`, { finding_id: findingId }),
    enabled: !!query.data,
  })
  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ['finding', findingId] })
    queryClient.invalidateQueries({ queryKey: ['findings'] })
    queryClient.invalidateQueries({ queryKey: ['notes'] })
  }
  const triage = useMutation({
    mutationFn: (body: Record<string, string>) => api.patch<Finding>(`/findings/${findingId}`, body),
    onSuccess: () => {
      toast.success('Finding updated')
      setNote('')
      invalidate()
    },
    onError: (e) => toast.error(errorMessage(e)),
  })
  const validateRef = useMutation({
    mutationFn: ({ refId, status }: { refId: string; status: string }) =>
      api.patch<Finding>(`/findings/${findingId}/references/${refId}`, { validation_status: status }),
    onSuccess: () => {
      toast.success('Reference updated')
      invalidate()
    },
    onError: (e) => toast.error(errorMessage(e)),
  })
  const f = query.data
  const canTriage = can('findings:triage')

  return (
    <Modal open={!!findingId} onClose={onClose} title={f ? f.title : 'Finding'} wide>
      {query.isLoading ? <LoadingState /> : query.error ? <ErrorState error={query.error} /> : f ? (
        <div className="space-y-5">
          <div className="flex flex-wrap items-center gap-2">
            <SeverityBadge severity={f.severity} />
            <StatusBadge status={f.status} />
            <StatusBadge status={f.validation_status} label={`Validation: ${titleCase(f.validation_status)}`} />
            <Badge tone="info">{ORIGIN_LABEL[f.origin]}</Badge>
            <Badge>Confidence: {f.confidence}</Badge>
          </div>
          <p className="whitespace-pre-wrap text-sm text-fg-muted">{f.description || 'No description recorded.'}</p>
          <KeyValue
            items={[
              ['Finding ID', <span className="font-mono text-xs">F-{shortId(f.id)} · {f.id}</span>],
              ['Investigation', <Link className="text-accent hover:underline" to={`/investigations/${f.investigation_id}`}>{f.investigation_reference}</Link>],
              ['Workspace', titleCase(f.workspace)],
              ['Source tool', <span className="font-mono text-xs">{f.source_tool}{f.rule_id ? ` · rule ${f.rule_id}` : ''}</span>],
              ['Type', f.finding_type],
              ['Affected asset', f.affected_asset || '—'],
              ['Observed', formatDateTime(f.observed_at)],
              ['Recorded', formatDateTime(f.created_at)],
            ]}
          />
          <section>
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-fg-subtle">Supporting evidence</h3>
            {f.evidence_refs.length ? (
              <ul className="space-y-2">
                {f.evidence_refs.map((ref, i) => (
                  <li key={i} className="rounded-md border border-line bg-surface-2 p-2.5 text-xs">
                    <p className="text-fg-muted">
                      Evidence <span className="font-mono text-fg">{ref.evidence_id?.slice(0, 8)}</span> · location{' '}
                      <span className="font-mono text-fg">{ref.locator}</span>
                    </p>
                    {ref.excerpt ? <CodeBlock className="mt-1.5 max-h-32">{ref.excerpt}</CodeBlock> : null}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-xs text-fg-subtle">No evidence location recorded.</p>
            )}
          </section>
          {f.indicators.length ? (
            <section>
              <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-fg-subtle">Indicators</h3>
              <div className="flex flex-wrap gap-1.5">
                {f.indicators.map((i) => (
                  <Badge key={i.id} className="font-mono">{i.type}:{i.value}</Badge>
                ))}
              </div>
            </section>
          ) : null}
          {f.references.length ? (
            <section>
              <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-fg-subtle">CVE and ATT&CK references</h3>
              <ul className="space-y-2">
                {f.references.map((r) => (
                  <li key={r.id} className="flex flex-wrap items-start gap-3 rounded-md border border-line p-2.5 text-xs">
                    <div className="min-w-0 flex-1">
                      <a href={r.url} target="_blank" rel="noreferrer noopener" className="inline-flex items-center gap-1 font-mono text-accent hover:underline">
                        {r.external_id} <ExternalLink className="size-3" />
                      </a>
                      <span className="ml-2 text-fg">{r.title !== r.external_id ? r.title : ''}</span>
                      {r.cvss_score !== null ? <span className="ml-2 text-fg-muted">CVSS {r.cvss_score}</span> : r.ref_type === 'cve' ? <span className="ml-2 text-fg-subtle">not enriched</span> : null}
                      {r.tactics.length ? <span className="ml-2 text-fg-muted">{r.tactics.join(', ')}</span> : null}
                      <p className="mt-0.5 text-fg-subtle">{r.match_basis}</p>
                    </div>
                    <StatusBadge status={r.validation_status} />
                    {canTriage ? (
                      <Select
                        value={r.validation_status}
                        className="h-7 w-auto text-xs"
                        aria-label={`Validation of ${r.external_id}`}
                        onChange={(e) => validateRef.mutate({ refId: r.id, status: e.target.value })}
                      >
                        <option value="candidate">Candidate</option>
                        <option value="supported">Supported</option>
                        <option value="confirmed">Confirmed</option>
                        <option value="rejected">Rejected</option>
                      </Select>
                    ) : null}
                  </li>
                ))}
              </ul>
            </section>
          ) : null}
          {f.remediation.length ? (
            <section>
              <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-fg-subtle">Recorded remediation guidance</h3>
              <ul className="list-disc space-y-1 pl-5 text-sm">
                {f.remediation.map((r, i) => (
                  <li key={i}>
                    {r.text} <span className="text-xs text-fg-subtle">({r.source})</span>
                  </li>
                ))}
              </ul>
            </section>
          ) : null}
          {Object.keys(f.details).length ? (
            <section>
              <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-fg-subtle">Structured details</h3>
              <CodeBlock>{JSON.stringify(f.details, null, 2)}</CodeBlock>
            </section>
          ) : null}
          <section className="space-y-3 border-t border-line pt-4">
            <h3 className="text-xs font-semibold uppercase tracking-wide text-fg-subtle">Triage and notes</h3>
            {canTriage ? (
              <div className="flex flex-wrap gap-2">
                <Select value={f.status} className="h-8 w-auto text-xs" aria-label="Status" onChange={(e) => triage.mutate({ status: e.target.value })}>
                  <option value="open">Open</option>
                  <option value="investigating">Investigating</option>
                  <option value="resolved">Resolved</option>
                  <option value="false_positive">False positive</option>
                </Select>
                <Select value={f.validation_status} className="h-8 w-auto text-xs" aria-label="Validation" onChange={(e) => triage.mutate({ validation_status: e.target.value })}>
                  <option value="unverified">Unverified</option>
                  <option value="supported">Supported</option>
                  <option value="confirmed">Confirmed</option>
                  <option value="rejected">Rejected</option>
                </Select>
              </div>
            ) : (
              <p className="text-xs text-fg-subtle">Changing status requires the findings:triage permission.</p>
            )}
            <div className="space-y-2">
              {notes.data?.map((n) => (
                <div key={n.id} className="rounded-md bg-surface-2 p-2.5 text-xs">
                  <p className="text-fg-subtle">{n.author.full_name} · {formatDateTime(n.created_at)}</p>
                  <p className="mt-1 whitespace-pre-wrap text-fg">{n.body}</p>
                </div>
              ))}
            </div>
            {canTriage ? (
              <div className="space-y-2">
                <Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Add an investigation note about this finding" className="min-h-16 text-xs" />
                <Button size="sm" disabled={!note.trim()} loading={triage.isPending} onClick={() => triage.mutate({ note })}>
                  Add note
                </Button>
              </div>
            ) : null}
          </section>
        </div>
      ) : null}
    </Modal>
  )
}
