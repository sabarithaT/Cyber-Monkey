import { useQuery } from '@tanstack/react-query'
import { ShieldQuestion } from 'lucide-react'
import { useEffect, useState } from 'react'
import { api } from '../api/client'
import type { Finding } from '../api/models'
import type { Page, WorkspaceKey } from '../api/types'
import { formatRelative, shortId, titleCase } from '../lib/format'
import { useDebounced } from '../lib/useDebounced'
import { FindingDetail } from './FindingDetail'
import { Badge, SeverityBadge, StatusBadge } from './ui/Badge'
import { SearchInput, Select } from './ui/Form'
import { EmptyState } from './ui/States'
import { DataTable, Pagination } from './ui/Table'

export function FindingsTable({
  investigationId,
  workspace,
  runId,
  showInvestigation = false,
  emptyHint,
}: {
  investigationId?: string
  workspace?: WorkspaceKey
  runId?: string
  showInvestigation?: boolean
  emptyHint?: string
}) {
  const [page, setPage] = useState(1)
  const [severity, setSeverity] = useState('')
  const [status, setStatus] = useState('')
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState<string | null>(null)
  const debounced = useDebounced(search)
  useEffect(() => {
    setPage(1)
  }, [severity, status, debounced, investigationId, workspace])

  const query = useQuery({
    queryKey: ['findings', investigationId, workspace, runId, page, severity, status, debounced],
    queryFn: () =>
      api.get<Page<Finding>>('/findings', {
        investigation_id: investigationId,
        workspace,
        run_id: runId,
        page,
        page_size: 25,
        severity: severity || undefined,
        status: status || undefined,
        search: debounced,
      }),
  })

  return (
    <div>
      <div className="flex flex-wrap items-center gap-2 border-b border-line px-4 py-2.5">
        <SearchInput value={search} onChange={setSearch} placeholder="Search findings" />
        <Select value={severity} onChange={(e) => setSeverity(e.target.value)} className="h-8 w-auto text-xs" aria-label="Severity filter">
          <option value="">All severities</option>
          {['critical', 'high', 'medium', 'low', 'info'].map((s) => (
            <option key={s} value={s}>{titleCase(s)}</option>
          ))}
        </Select>
        <Select value={status} onChange={(e) => setStatus(e.target.value)} className="h-8 w-auto text-xs" aria-label="Status filter">
          <option value="">Any status</option>
          {['open', 'investigating', 'resolved', 'false_positive'].map((s) => (
            <option key={s} value={s}>{titleCase(s)}</option>
          ))}
        </Select>
        {query.data ? <span className="ml-auto text-xs text-fg-subtle">{query.data.total} findings</span> : null}
      </div>
      <DataTable
        rows={query.data?.items}
        loading={query.isLoading}
        error={query.error}
        onRetry={() => query.refetch()}
        rowKey={(f) => f.id}
        onRowClick={(f) => setSelected(f.id)}
        empty={
          <EmptyState
            icon={ShieldQuestion}
            title="No findings"
            description={emptyHint ?? 'Findings appear here after a tool run or an import produces them. Nothing is shown until real data exists.'}
          />
        }
        columns={[
          { key: 'sev', header: 'Severity', render: (f) => <SeverityBadge severity={f.severity} /> },
          {
            key: 'title',
            header: 'Finding',
            render: (f) => (
              <div className="min-w-0">
                <p className="font-medium">{f.title}</p>
                <p className="mt-0.5 font-mono text-[11px] text-fg-subtle">F-{shortId(f.id)} · {f.finding_type}</p>
              </div>
            ),
          },
          { key: 'asset', header: 'Asset', render: (f) => <span className="text-xs">{f.affected_asset || '—'}</span> },
          ...(showInvestigation
            ? [{ key: 'inv', header: 'Investigation', render: (f: Finding) => <span className="font-mono text-xs">{f.investigation_reference}</span> }]
            : []),
          {
            key: 'source',
            header: 'Source',
            render: (f) => (
              <div className="text-xs">
                <p className="font-mono">{f.source_tool}</p>
                <Badge tone="info" className="mt-1">{f.origin}</Badge>
              </div>
            ),
          },
          {
            key: 'state',
            header: 'Status',
            render: (f) => (
              <div className="flex flex-col items-start gap-1">
                <StatusBadge status={f.status} />
                <StatusBadge status={f.validation_status} />
              </div>
            ),
          },
          { key: 'when', header: 'Recorded', render: (f) => <span className="whitespace-nowrap text-xs text-fg-muted">{formatRelative(f.created_at)}</span> },
        ]}
      />
      {query.data ? <Pagination page={page} pageSize={query.data.page_size} total={query.data.total} onPage={setPage} /> : null}
      <FindingDetail findingId={selected} onClose={() => setSelected(null)} />
    </div>
  )
}
