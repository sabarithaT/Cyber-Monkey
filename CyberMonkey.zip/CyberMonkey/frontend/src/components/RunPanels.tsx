import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Check, Play, ShieldAlert, X } from 'lucide-react'
import { useState } from 'react'
import { api, errorMessage } from '../api/client'
import type { Evidence, Tool, ToolRun } from '../api/models'
import type { Page, WorkspaceKey } from '../api/types'
import { formatDateTime, formatRelative, shortId, titleCase } from '../lib/format'
import { FindingsTable } from './FindingsTable'
import { Badge, StatusBadge } from './ui/Badge'
import { Button } from './ui/Button'
import { Card, CardBody, CardHeader, CodeBlock, KeyValue } from './ui/Card'
import { Field, Input, Select, Textarea } from './ui/Form'
import { ConfirmDialog, Modal } from './ui/Modal'
import { Alert, EmptyState, ErrorState, LoadingState, NotConfigured } from './ui/States'
import { DataTable, Pagination } from './ui/Table'
import { useToast } from './ui/Toast'

const ACTIVE: ToolRun['status'][] = ['queued', 'running']

export function useRun(runId: string | null) {
  return useQuery({
    queryKey: ['run', runId],
    queryFn: () => api.get<ToolRun>(`/tool-runs/${runId}`),
    enabled: !!runId,
    refetchInterval: (query) => (query.state.data && ACTIVE.includes(query.state.data.status) ? 1500 : false),
  })
}

export function RunDecisionButtons({ run, onDone }: { run: ToolRun; onDone?: () => void }) {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [confirming, setConfirming] = useState(false)
  const [rejecting, setRejecting] = useState(false)
  const [note, setNote] = useState('')
  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ['run', run.id] })
    queryClient.invalidateQueries({ queryKey: ['runs'] })
    queryClient.invalidateQueries({ queryKey: ['notifications'] })
    queryClient.invalidateQueries({ queryKey: ['conversation'] })
    queryClient.invalidateQueries({ queryKey: ['findings'] })
  }
  const approve = useMutation({
    mutationFn: () => api.post<ToolRun>(`/tool-runs/${run.id}/approve`, { note }),
    onSuccess: (r) => {
      toast.success(`Run approved — ${titleCase(r.status)}`)
      setConfirming(false)
      invalidate()
      onDone?.()
    },
    onError: (e) => toast.error(errorMessage(e)),
  })
  const reject = useMutation({
    mutationFn: () => api.post<ToolRun>(`/tool-runs/${run.id}/reject`, { note }),
    onSuccess: () => {
      toast.info('Run declined')
      setRejecting(false)
      invalidate()
      onDone?.()
    },
    onError: (e) => toast.error(errorMessage(e)),
  })
  if (run.status !== 'pending_approval') return null
  return (
    <>
      <div className="flex flex-wrap gap-2">
        <Button size="sm" variant="primary" icon={Check} onClick={() => setConfirming(true)}>Approve &amp; run</Button>
        <Button size="sm" variant="ghost" icon={X} onClick={() => setRejecting(true)}>Decline</Button>
      </div>
      <ConfirmDialog
        open={confirming}
        title={`Confirm ${run.tool_name}`}
        confirmLabel="Approve and run"
        loading={approve.isPending}
        onCancel={() => setConfirming(false)}
        onConfirm={() => approve.mutate()}
      >
        <p>This tool can affect the environment it targets. Confirm only if the investigation's authorized scope covers it.</p>
        <CodeBlock>{JSON.stringify(run.arguments, null, 2)}</CodeBlock>
        <Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Approval note (optional), e.g. change ticket or RoE reference" className="min-h-16 text-xs" />
      </ConfirmDialog>
      <ConfirmDialog
        open={rejecting}
        title={`Decline ${run.tool_name}?`}
        confirmLabel="Decline run"
        tone="danger"
        loading={reject.isPending}
        onCancel={() => setRejecting(false)}
        onConfirm={() => reject.mutate()}
      >
        <p>The run will not execute. This decision is recorded in the audit log.</p>
        <Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Reason (optional)" className="min-h-16 text-xs" />
      </ConfirmDialog>
    </>
  )
}

export function RunDetail({ runId, onClose }: { runId: string | null; onClose: () => void }) {
  const query = useRun(runId)
  const run = query.data
  return (
    <Modal open={!!runId} onClose={onClose} title={run ? `${run.tool_name} · ${shortId(run.id)}` : 'Tool run'} wide>
      {query.isLoading ? <LoadingState /> : query.error ? <ErrorState error={query.error} /> : run ? (
        <div className="space-y-5">
          <div className="flex flex-wrap items-center gap-2">
            <StatusBadge status={run.status} />
            {run.requires_approval ? <Badge tone="warning">Requires confirmation</Badge> : null}
            <Badge>{titleCase(run.origin)}</Badge>
          </div>
          {run.status === 'pending_approval' ? (
            <Alert tone="warning" title="Waiting for confirmation">
              Nothing has executed yet. Review the arguments below.
            </Alert>
          ) : null}
          {run.error_message ? <Alert tone={run.status === 'unavailable' ? 'info' : 'danger'}>{run.error_message}</Alert> : null}
          <RunDecisionButtons run={run} />
          <KeyValue
            items={[
              ['Investigation', run.investigation_reference],
              ['Requested', `${formatDateTime(run.created_at)} by ${run.requested_by.email}`],
              ['Decision', run.approved_by ? `${run.status === 'rejected' ? 'Declined' : 'Approved'} by ${run.approved_by.email} ${formatDateTime(run.approval_decided_at)}${run.approval_note ? ` — ${run.approval_note}` : ''}` : '—'],
              ['Started', formatDateTime(run.started_at)],
              ['Finished', formatDateTime(run.finished_at)],
              ['Time limit', `${run.timeout_seconds}s`],
              ['Raw output', run.raw_output_evidence_id ? <span className="font-mono text-xs">evidence {shortId(run.raw_output_evidence_id)}</span> : '—'],
            ]}
          />
          <div>
            <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-fg-subtle">Validated arguments</p>
            <CodeBlock>{JSON.stringify(run.arguments, null, 2)}</CodeBlock>
          </div>
          {Object.keys(run.output_summary).length ? (
            <div>
              <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-fg-subtle">Actual output summary</p>
              <CodeBlock>{JSON.stringify(run.output_summary, null, 2)}</CodeBlock>
            </div>
          ) : null}
          {run.execution_log.length ? (
            <div>
              <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-fg-subtle">Execution log</p>
              <CodeBlock>{run.execution_log.map((l) => `${new Date(l.at * 1000).toLocaleTimeString()}  ${l.message}`).join('\n')}</CodeBlock>
            </div>
          ) : null}
          {run.status === 'succeeded' ? (
            <Card>
              <CardHeader title="Findings from this run" />
              <FindingsTable runId={run.id} investigationId={run.investigation_id} />
            </Card>
          ) : null}
        </div>
      ) : null}
    </Modal>
  )
}

export function RunsTable({ investigationId, workspace, initialRunId }: { investigationId?: string; workspace?: WorkspaceKey; initialRunId?: string | null }) {
  const [page, setPage] = useState(1)
  const [selected, setSelected] = useState<string | null>(initialRunId ?? null)
  const query = useQuery({
    queryKey: ['runs', investigationId, workspace, page],
    queryFn: () => api.get<Page<ToolRun>>('/tool-runs', { investigation_id: investigationId, workspace, page, page_size: 20 }),
    refetchInterval: (q) => (q.state.data?.items.some((r) => ACTIVE.includes(r.status)) ? 2000 : false),
  })
  return (
    <>
      <DataTable
        rows={query.data?.items}
        loading={query.isLoading}
        error={query.error}
        onRetry={() => query.refetch()}
        rowKey={(r) => r.id}
        onRowClick={(r) => setSelected(r.id)}
        dense
        empty={<EmptyState icon={Play} title="No tool runs yet" description="Runs appear here when a tool is requested from a workspace or by the AI assistant." />}
        columns={[
          { key: 'tool', header: 'Tool', render: (r) => <span className="font-mono text-xs">{r.tool_name}</span> },
          { key: 'inv', header: 'Investigation', render: (r) => <span className="font-mono text-xs">{r.investigation_reference}</span> },
          { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
          { key: 'origin', header: 'Origin', render: (r) => <span className="text-xs">{titleCase(r.origin)}</span> },
          { key: 'by', header: 'Requested by', render: (r) => <span className="text-xs">{r.requested_by.email}</span> },
          { key: 'findings', header: 'Findings', render: (r) => <span className="text-xs tabular-nums">{String(r.output_summary.finding_count ?? '—')}</span> },
          { key: 'when', header: 'Requested', render: (r) => <span className="whitespace-nowrap text-xs text-fg-muted">{formatRelative(r.created_at)}</span> },
        ]}
      />
      {query.data ? <Pagination page={page} pageSize={query.data.page_size} total={query.data.total} onPage={setPage} /> : null}
      <RunDetail runId={selected} onClose={() => setSelected(null)} />
    </>
  )
}

function propType(schema: Tool['arguments_schema'], key: string) {
  const prop = schema.properties?.[key] ?? {}
  const resolved = prop.anyOf?.find((p) => p.type !== 'null') ?? prop
  return { ...prop, ...resolved }
}

function ToolForm({ tool, investigationId, onDone }: { tool: Tool; investigationId: string; onDone: (run: ToolRun) => void }) {
  const [values, setValues] = useState<Record<string, string>>({})
  const evidence = useQuery({
    queryKey: ['evidence', investigationId, false],
    queryFn: () => api.get<Evidence[]>(`/investigations/${investigationId}/evidence`, { include_derived: false }),
  })
  const run = useMutation({
    mutationFn: () => {
      const args: Record<string, unknown> = {}
      for (const key of Object.keys(tool.arguments_schema.properties ?? {})) {
        const raw = values[key]
        if (raw === undefined || raw === '') continue
        const t = propType(tool.arguments_schema, key).type
        args[key] = t === 'integer' || t === 'number' ? Number(raw) : t === 'boolean' ? raw === 'true' : raw
      }
      return api.post<ToolRun>('/tool-runs', { investigation_id: investigationId, tool: tool.name, arguments: args })
    },
    onSuccess: onDone,
  })
  const keys = Object.keys(tool.arguments_schema.properties ?? {})
  const required = new Set(tool.arguments_schema.required ?? [])
  return (
    <div className="space-y-4">
      <p className="text-sm text-fg-muted">{tool.purpose}</p>
      {tool.requires_approval !== 'never' ? (
        <Alert tone="warning">This tool requires explicit confirmation before it executes.</Alert>
      ) : null}
      {run.isError ? <Alert tone="danger">{errorMessage(run.error)}</Alert> : null}
      {keys.map((key) => {
        const prop = propType(tool.arguments_schema, key)
        const label = `${prop.title ?? titleCase(key)}${required.has(key) ? ' *' : ''}`
        if (key === 'evidence_id') {
          return (
            <Field key={key} label={label} hint="Only evidence in this investigation can be selected; the tool checks the evidence kind.">
              <Select value={values[key] ?? ''} onChange={(e) => setValues({ ...values, [key]: e.target.value })}>
                <option value="">Select evidence</option>
                {evidence.data?.map((ev) => (
                  <option key={ev.id} value={ev.id}>
                    {ev.original_filename} · {titleCase(ev.kind)}
                  </option>
                ))}
              </Select>
            </Field>
          )
        }
        if (prop.enum) {
          return (
            <Field key={key} label={label} hint={prop.description}>
              <Select value={values[key] ?? String(prop.default ?? '')} onChange={(e) => setValues({ ...values, [key]: e.target.value })}>
                {prop.enum.map((option) => (
                  <option key={option} value={option}>{option}</option>
                ))}
              </Select>
            </Field>
          )
        }
        return (
          <Field key={key} label={label} hint={prop.description}>
            <Input
              type={prop.type === 'integer' || prop.type === 'number' ? 'number' : 'text'}
              value={values[key] ?? ''}
              placeholder={prop.default !== undefined ? String(prop.default) : ''}
              onChange={(e) => setValues({ ...values, [key]: e.target.value })}
            />
          </Field>
        )
      })}
      <p className="text-xs text-fg-subtle">
        Time limit {tool.timeout_seconds}s · output: {tool.output_format}
      </p>
      <div className="flex justify-end">
        <Button variant="primary" icon={tool.requires_approval !== 'never' ? ShieldAlert : Play} loading={run.isPending} onClick={() => run.mutate()}>
          {tool.requires_approval !== 'never' ? 'Request run' : 'Run tool'}
        </Button>
      </div>
    </div>
  )
}

export function ToolCatalog({ workspace, investigationId, writable }: { workspace?: WorkspaceKey; investigationId: string | null; writable: boolean }) {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [active, setActive] = useState<Tool | null>(null)
  const [lastRun, setLastRun] = useState<string | null>(null)
  const tools = useQuery({ queryKey: ['tools', workspace], queryFn: () => api.get<Tool[]>('/tools', { workspace }) })
  if (tools.isLoading) return <LoadingState />
  if (tools.error) return <ErrorState error={tools.error} onRetry={() => tools.refetch()} />
  if (!tools.data?.length) return <EmptyState title="No tools registered for this workspace" />
  return (
    <>
      <div className="grid gap-3 p-4 md:grid-cols-2">
        {tools.data.map((tool) => (
          <div key={tool.name} className="flex flex-col rounded-md border border-line bg-surface-2 p-3.5">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="text-sm font-medium">{tool.title}</p>
                <p className="font-mono text-[11px] text-fg-subtle">{tool.name}</p>
              </div>
              <div className="flex flex-wrap gap-1">
                <StatusBadge status={tool.available ? 'available' : 'not_configured'} />
                {tool.requires_approval !== 'never' ? <Badge tone="warning">Confirmation</Badge> : null}
              </div>
            </div>
            <p className="mt-2 flex-1 text-xs text-fg-muted">{tool.purpose}</p>
            {!tool.available ? (
              <div className="mt-3">
                <NotConfigured title="Integration not configured" detail={tool.availability_detail} howTo="See Settings → Integrations for setup instructions." />
              </div>
            ) : null}
            <div className="mt-3 flex items-center justify-between gap-2">
              <span className="text-[11px] text-fg-subtle">{tool.permitted ? 'You may run this tool' : `Requires ${tool.permissions.join(', ')}`}</span>
              <Button
                size="sm"
                icon={Play}
                disabled={!tool.permitted || !investigationId || !writable}
                title={!investigationId ? 'Select an investigation first' : undefined}
                onClick={() => setActive(tool)}
              >
                {investigationId ? 'Configure' : 'Select a case'}
              </Button>
            </div>
          </div>
        ))}
      </div>
      <Modal open={!!active} onClose={() => setActive(null)} title={active?.title ?? ''}>
        {active && investigationId ? (
          <ToolForm
            tool={active}
            investigationId={investigationId}
            onDone={(run) => {
              setActive(null)
              setLastRun(run.id)
              queryClient.invalidateQueries({ queryKey: ['runs'] })
              queryClient.invalidateQueries({ queryKey: ['findings'] })
              queryClient.invalidateQueries({ queryKey: ['investigation', investigationId] })
              if (run.status === 'pending_approval') toast.info('Run created and waiting for your confirmation')
              else if (run.status === 'unavailable') toast.error(run.error_message)
              else toast.success(`Run ${titleCase(run.status)}`)
            }}
          />
        ) : null}
      </Modal>
      <RunDetail runId={lastRun} onClose={() => setLastRun(null)} />
    </>
  )
}

export function ToolsCard({ workspace, investigationId, writable }: { workspace?: WorkspaceKey; investigationId: string | null; writable: boolean }) {
  return (
    <Card>
      <CardHeader title="Tools" subtitle="Registered tools only. Arguments are validated and scope-checked on the server; consequential tools wait for confirmation." />
      <CardBody className="p-0">
        <ToolCatalog workspace={workspace} investigationId={investigationId} writable={writable} />
      </CardBody>
    </Card>
  )
}
