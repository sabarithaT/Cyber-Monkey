import { useQuery } from '@tanstack/react-query'
import { api } from '../api/client'
import type { InvestigationSummary } from '../api/models'
import type { Page, WorkspaceKey } from '../api/types'
import { Select } from './ui/Form'

export function useInvestigations(workspace?: WorkspaceKey) {
  return useQuery({
    queryKey: ['investigations', 'picker', workspace ?? 'all'],
    queryFn: () => api.get<Page<InvestigationSummary>>('/investigations', { page_size: 100, workspace }),
  })
}

export function InvestigationPicker({
  value,
  onChange,
  workspace,
  allowNone = false,
  className,
}: {
  value: string
  onChange: (id: string) => void
  workspace?: WorkspaceKey
  allowNone?: boolean
  className?: string
}) {
  const query = useInvestigations(workspace)
  const items = query.data?.items ?? []
  return (
    <Select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className={className}
      aria-label="Investigation"
      disabled={query.isLoading}
    >
      <option value="">{query.isLoading ? 'Loading investigations…' : allowNone ? 'No investigation selected' : 'Select an investigation'}</option>
      {items.map((inv) => (
        <option key={inv.id} value={inv.id}>
          {inv.reference} · {inv.title}
          {inv.is_demo ? ' (demo)' : ''}
        </option>
      ))}
    </Select>
  )
}
