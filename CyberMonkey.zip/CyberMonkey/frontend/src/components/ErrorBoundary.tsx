import { AlertOctagon } from 'lucide-react'
import { Component, type ErrorInfo, type ReactNode } from 'react'

interface State {
  error: Error | null
}

/** Catches rendering errors in a page so the rest of the application stays usable. */
export class ErrorBoundary extends Component<{ children: ReactNode; resetKey?: string }, State> {
  override state: State = { error: null }

  static getDerivedStateFromError(error: Error): State {
    return { error }
  }

  override componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('Page render failed', error, info.componentStack)
  }

  override componentDidUpdate(prev: { resetKey?: string }) {
    if (prev.resetKey !== this.props.resetKey && this.state.error) this.setState({ error: null })
  }

  override render() {
    if (!this.state.error) return this.props.children
    return (
      <div className="flex flex-col items-center gap-2 px-6 py-16 text-center" role="alert">
        <AlertOctagon className="size-8 text-rose-400" />
        <p className="text-sm font-medium">This page failed to render</p>
        <p className="max-w-lg text-xs text-fg-muted">{this.state.error.message}</p>
        <button type="button" className="mt-2 text-sm text-accent hover:underline" onClick={() => this.setState({ error: null })}>
          Try again
        </button>
      </div>
    )
  }
}
