import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Download, FileUp, ShieldCheck } from 'lucide-react'
import { useState, type FormEvent } from 'react'
import { api, downloadFile, errorMessage } from '../api/client'
import type { Evidence, EvidenceDetail } from '../api/models'
import { useAuth } from '../auth/AuthContext'
import { formatBytes, formatDateTime, titleCase } from '../lib/format'
import { Badge } from './ui/Badge'
import { Button } from './ui/Button'
import { CardHeader, CodeBlock, KeyValue } from './ui/Card'
import { Field, Input, Select, TextField } from './ui/Form'
import { Modal } from './ui/Modal'
import { Alert, EmptyState } from './ui/States'
import { DataTable } from './ui/Table'
import { useToast } from './ui/Toast'

export const EVIDENCE_KINDS: { value: string; label: string; workspace: string; hint: string }[] = [
  { value: 'log', label: 'Security log', workspace: 'soc', hint: 'Text or JSON logs; also findings exports for SOC import.' },
  { value: 'scan_report', label: 'Scan report', workspace: 'pentest', hint: 'Results exported from an authorized assessment tool.' },
  { value: 'osint_record', label: 'OSINT record', workspace: 'osint', hint: 'Public-source collection results (text or JSON).' },
  { value: 'malware_sample', label: 'Malware sample', workspace: 'malware', hint: 'Stored read-only, never executed, never downloadable.' },
  { value: 'sandbox_report', label: 'Sandbox report', workspace: 'malware', hint: 'JSON report from your isolated sandbox.' },
  { value: 'disk_image', label: 'Disk image', workspace: 'forensics', hint: 'Forensic disk image (stored read-only).' },
  { value: 'memory_image', label: 'Memory image', workspace: 'forensics', hint: 'Memory capture (stored read-only).' },
  { value: 'forensic_report', label: 'Forensic report', workspace: 'forensics', hint: 'Output of a forensic suite (text or JSON).' },
  { value: 'pcap', label: 'Packet capture', workspace: 'network', hint: 'pcap or pcapng captured on an authorized network.' },
  { value: 'ids_alerts', label: 'IDS alerts', workspace: 'network', hint: 'Alert export from your IDS (JSON).' },
  { value: 'other', label: 'Other evidence', workspace: 'forensics', hint: 'Any other evidence item.' },
]

function UploadForm({ investigationId, workspace, onDone }: { investigationId: string; workspace?: string; onDone: () => void }) {
  const { can } = useAuth()
  const toast = useToast()
  const queryClient = useQueryClient()
  const kinds = EVIDENCE_KINDS.filter((k) => can(`${k.workspace}:operate`) && (!workspace || k.workspace === workspace))
  const [kind, setKind] = useState(kinds[0]?.value ?? '')
  const [file, setFile] = useState<File | null>(null)
  const [source, setSource] = useState('')
  const [acquired, setAcquired] = useState('')
  const upload = useMutation({
    mutationFn: () => {
      const form = new FormData()
      form.append('file', file!)
      form.append('kind', kind)
      form.append('source_description', source)
      if (acquired) form.append('acquired_at', new Date(acquired).toISOString())
      return api.upload<Evidence>(`/investigations/${investigationId}/evidence`, form)
    },
    onSuccess: (ev) => {
      toast.success(`Stored ${ev.original_filename} (sha256 ${ev.sha256.slice(0, 12)}…)`)
      queryClient.invalidateQueries({ queryKey: ['evidence', investigationId] })
      queryClient.invalidateQueries({ queryKey: ['investigation', investigationId] })
      onDone()
    },
  })
  if (!kinds.length || !can('evidence:upload')) {
    return <Alert tone="info">Uploading evidence requires the evidence:upload permission and operate access to a workspace.</Alert>
  }
  const selected = EVIDENCE_KINDS.find((k) => k.value === kind)

  function submit(event: FormEvent) {
    event.preventDefault()
    if (file) upload.mutate()
  }

  return (
    <form className="space-y-4" onSubmit={submit}>
      {upload.isError ? <Alert tone="danger">{errorMessage(upload.error)}</Alert> : null}
      <Field label="Evidence kind" hint={selected?.hint}>
        <Select value={kind} onChange={(e) => setKind(e.target.value)}>
          {kinds.map((k) => (
            <option key={k.value} value={k.value}>{k.label}</option>
          ))}
        </Select>
      </Field>
      <Field label="File" hint="Hashes (MD5, SHA-1, SHA-256) are computed on upload; content is checked against the kind.">
        <Input type="file" onChange={(e) => setFile(e.target.files?.[0] ?? null)} className="py-1.5" />
      </Field>
      <TextField label="Source / provenance" value={source} onChange={(e) => setSource(e.target.value)} placeholder="Where and how this was obtained" />
      <TextField label="Acquired at (optional)" type="datetime-local" value={acquired} onChange={(e) => setAcquired(e.target.value)} />
      <div className="flex justify-end gap-2">
        <Button variant="ghost" onClick={onDone}>Cancel</Button>
        <Button type="submit" variant="primary" icon={FileUp} loading={upload.isPending} disabled={!file}>Upload evidence</Button>
      </div>
    </form>
  )
}

function EvidenceDetailModal({ evidenceId, onClose }: { evidenceId: string | null; onClose: () => void }) {
  const toast = useToast()
  const { can } = useAuth()
  const queryClient = useQueryClient()
  const query = useQuery({
    queryKey: ['evidence-detail', evidenceId],
    queryFn: () => api.get<EvidenceDetail>(`/evidence/${evidenceId}`),
    enabled: !!evidenceId,
  })
  const verify = useMutation({
    mutationFn: () => api.post<{ match: boolean; computed_sha256?: string; reason?: string }>(`/evidence/${evidenceId}/verify`),
    onSuccess: (r) => {
      if (r.match) toast.success('Integrity verified: SHA-256 matches the value recorded at registration')
      else toast.error(`Integrity check FAILED: ${r.reason ?? 'hash mismatch'}`)
      queryClient.invalidateQueries({ queryKey: ['evidence-detail', evidenceId] })
    },
    onError: (e) => toast.error(errorMessage(e)),
  })
  const ev = query.data
  return (
    <Modal open={!!evidenceId} onClose={onClose} title={ev?.original_filename ?? 'Evidence'} wide>
      {ev ? (
        <div className="space-y-5">
          <div className="flex flex-wrap gap-2">
            <Badge tone="info">{titleCase(ev.kind)}</Badge>
            <Badge>{ev.is_original ? 'Original evidence' : 'Derived tool output'}</Badge>
            <Badge>{ev.detected_type}</Badge>
          </div>
          <KeyValue
            items={[
              ['Size', formatBytes(ev.size_bytes)],
              ['SHA-256', <span className="break-all font-mono text-xs">{ev.sha256}</span>],
              ['SHA-1', <span className="break-all font-mono text-xs">{ev.sha1}</span>],
              ['MD5', <span className="break-all font-mono text-xs">{ev.md5}</span>],
              ['Source', ev.source_description || '—'],
              ['Acquired', formatDateTime(ev.acquired_at)],
              ['Uploaded', `${formatDateTime(ev.created_at)} by ${ev.uploaded_by?.email ?? 'platform'}`],
              ['Produced by run', ev.produced_by_run_id ? <span className="font-mono text-xs">{ev.produced_by_run_id}</span> : '—'],
            ]}
          />
          <div className="flex flex-wrap gap-2">
            <Button size="sm" icon={ShieldCheck} loading={verify.isPending} onClick={() => verify.mutate()}>Verify integrity</Button>
            {ev.downloadable && can('evidence:download') ? (
              <Button size="sm" icon={Download} onClick={() => downloadFile(`/evidence/${ev.id}/download`, ev.original_filename).catch((e) => toast.error(errorMessage(e)))}>
                Download
              </Button>
            ) : (
              <span className="self-center text-xs text-fg-subtle">
                {ev.kind === 'malware_sample' ? 'Malware samples cannot be downloaded through the web application.' : 'Download requires evidence:download.'}
              </span>
            )}
          </div>
          <section>
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-fg-subtle">Custody history</h3>
            <ol className="space-y-1.5 border-l border-line pl-4">
              {ev.events.map((e) => (
                <li key={e.id} className="text-xs">
                  <span className="font-medium text-fg">{titleCase(e.action)}</span>{' '}
                  <span className="text-fg-muted">· {formatDateTime(e.created_at)} · {e.actor?.email ?? 'platform'}</span>
                  {Object.keys(e.details).length ? <CodeBlock className="mt-1 max-h-24">{JSON.stringify(e.details)}</CodeBlock> : null}
                </li>
              ))}
            </ol>
          </section>
        </div>
      ) : null}
    </Modal>
  )
}

export function EvidencePanel({ investigationId, workspace, writable }: { investigationId: string; workspace?: string; writable: boolean }) {
  const [uploading, setUploading] = useState(false)
  const [selected, setSelected] = useState<string | null>(null)
  const [showDerived, setShowDerived] = useState(false)
  const query = useQuery({
    queryKey: ['evidence', investigationId, showDerived],
    queryFn: () => api.get<Evidence[]>(`/investigations/${investigationId}/evidence`, { include_derived: showDerived }),
  })
  const rows = workspace ? query.data?.filter((e) => EVIDENCE_KINDS.find((k) => k.value === e.kind)?.workspace === workspace || e.kind === 'tool_output') : query.data
  return (
    <>
      <CardHeader
        title="Evidence"
        subtitle="Stored read-only with hashes and a custody trail. Analysis never modifies originals."
        actions={
          <>
            <label className="flex items-center gap-1.5 text-xs text-fg-muted">
              <input type="checkbox" className="accent-teal-400" checked={showDerived} onChange={(e) => setShowDerived(e.target.checked)} />
              Include tool output
            </label>
            {writable ? (
              <Button size="sm" variant="primary" icon={FileUp} onClick={() => setUploading(true)}>Upload</Button>
            ) : null}
          </>
        }
      />
      <DataTable
        rows={rows}
        loading={query.isLoading}
        error={query.error}
        onRetry={() => query.refetch()}
        rowKey={(e) => e.id}
        onRowClick={(e) => setSelected(e.id)}
        dense
        empty={<EmptyState icon={FileUp} title="No evidence yet" description="Upload logs, captures, samples, images or exported results to analyze them here." />}
        columns={[
          { key: 'name', header: 'File', render: (e) => <span className="font-medium">{e.original_filename}</span> },
          { key: 'kind', header: 'Kind', render: (e) => <Badge tone={e.is_original ? 'info' : 'neutral'}>{titleCase(e.kind)}</Badge> },
          { key: 'size', header: 'Size', render: (e) => <span className="text-xs tabular-nums">{formatBytes(e.size_bytes)}</span> },
          { key: 'hash', header: 'SHA-256', render: (e) => <span className="font-mono text-xs text-fg-muted">{e.sha256.slice(0, 16)}…</span> },
          { key: 'when', header: 'Registered', render: (e) => <span className="text-xs text-fg-muted">{formatDateTime(e.created_at)}</span> },
        ]}
      />
      <Modal open={uploading} onClose={() => setUploading(false)} title="Upload evidence">
        <UploadForm investigationId={investigationId} workspace={workspace} onDone={() => setUploading(false)} />
      </Modal>
      <EvidenceDetailModal evidenceId={selected} onClose={() => setSelected(null)} />
    </>
  )
}
