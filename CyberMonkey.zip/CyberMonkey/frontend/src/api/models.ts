// TypeScript mirrors of the investigation, evidence, tool, finding, threat-intelligence,
// report and assistant schemas (see /api/docs for the source of truth).
import type { Severity, WorkspaceKey } from './types'

export interface UserRef {
  id: string
  email: string
  full_name: string
}

export type SeverityCounts = Record<Severity, number>

export interface ScopeTarget {
  id: string
  target_type: 'ip' | 'cidr' | 'hostname'
  value: string
  authorization_reference: string
  authorized_by: UserRef
  valid_from: string
  valid_until: string | null
  notes: string
  created_at: string
  active: boolean
}

export interface InvestigationSummary {
  id: string
  reference: string
  title: string
  primary_workspace: WorkspaceKey
  status: 'open' | 'in_progress' | 'closed'
  is_demo: boolean
  owner: UserRef
  created_at: string
  updated_at: string
  finding_counts: SeverityCounts
  run_count: number
  evidence_count: number
}

export interface InvestigationDetail extends InvestigationSummary {
  description: string
  closed_at: string | null
  members: { user: UserRef; access_level: 'viewer' | 'contributor'; added_at: string }[]
  scope_targets: ScopeTarget[]
  my_access: 'owner' | 'contributor' | 'viewer' | 'manager'
}

export interface Evidence {
  id: string
  investigation_id: string
  kind: string
  original_filename: string
  size_bytes: number
  md5: string
  sha1: string
  sha256: string
  detected_type: string
  source_description: string
  acquired_at: string | null
  uploaded_by: UserRef | null
  is_original: boolean
  parent_evidence_id: string | null
  produced_by_run_id: string | null
  notes: string
  metadata: Record<string, unknown>
  created_at: string
  downloadable: boolean
}

export interface EvidenceEvent {
  id: string
  action: string
  actor: UserRef | null
  run_id: string | null
  details: Record<string, unknown>
  created_at: string
}

export interface EvidenceDetail extends Evidence {
  events: EvidenceEvent[]
}

export interface SchemaProperty {
  type?: string
  title?: string
  description?: string
  enum?: string[]
  format?: string
  default?: unknown
  anyOf?: SchemaProperty[]
  maxLength?: number
  minimum?: number
  maximum?: number
}

export interface JsonSchema {
  type?: string
  properties?: Record<string, SchemaProperty>
  required?: string[]
  title?: string
}

export interface Tool {
  name: string
  workspace: WorkspaceKey
  title: string
  purpose: string
  permissions: string[]
  permitted: boolean
  requires_approval: 'always' | 'never' | 'conditional'
  timeout_seconds: number
  output_format: string
  side_effects: string
  available: boolean
  availability_detail: string
  integrations: string[]
  arguments_schema: JsonSchema
  example_requests: string[]
}

export type RunStatus =
  | 'pending_approval'
  | 'queued'
  | 'running'
  | 'succeeded'
  | 'failed'
  | 'timed_out'
  | 'rejected'
  | 'unavailable'

export interface ToolRun {
  id: string
  investigation_id: string
  investigation_reference: string
  workspace: WorkspaceKey
  tool_name: string
  arguments: Record<string, unknown>
  status: RunStatus
  origin: string
  requires_approval: boolean
  requested_by: UserRef
  approved_by: UserRef | null
  approval_decided_at: string | null
  approval_note: string
  timeout_seconds: number
  started_at: string | null
  finished_at: string | null
  exit_code: number | null
  error_message: string
  output_summary: Record<string, unknown>
  raw_output_evidence_id: string | null
  execution_log: { at: number; message: string }[]
  conversation_id: string | null
  created_at: string
}

export interface FindingReference {
  id: string
  ref_type: 'cve' | 'attack_technique'
  external_id: string
  title: string
  url: string
  cvss_score: number | null
  severity: string | null
  source: string
  match_basis: string
  validation_status: 'candidate' | 'supported' | 'confirmed' | 'rejected'
  tactics: string[]
}

export interface EvidenceRef {
  evidence_id?: string
  locator?: string
  excerpt?: string
}

export interface Finding {
  id: string
  investigation_id: string
  investigation_reference: string
  workspace: WorkspaceKey
  source_tool: string
  run_id: string | null
  origin: 'tool' | 'rule' | 'import' | 'analyst'
  rule_id: string | null
  finding_type: string
  title: string
  description: string
  severity: Severity
  confidence: 'low' | 'medium' | 'high'
  affected_asset: string
  observed_at: string | null
  status: 'open' | 'investigating' | 'resolved' | 'false_positive'
  validation_status: 'unverified' | 'supported' | 'confirmed' | 'rejected'
  details: Record<string, unknown>
  evidence_refs: EvidenceRef[]
  remediation: { text: string; source: string }[]
  indicators: { id: string; type: string; value: string; relation: string; context: string }[]
  references: FindingReference[]
  created_at: string
  updated_at: string
}

export interface Note {
  id: string
  body: string
  finding_id: string | null
  author: UserRef
  created_at: string
}

export interface TimelineEntry {
  at: string
  kind: 'finding' | 'log_event' | 'run' | 'evidence' | 'note'
  title: string
  detail: string
  severity: Severity | null
  workspace: WorkspaceKey | null
  ref_id: string
}

export interface IndicatorRow {
  id: string
  type: string
  value: string
  is_internal: boolean
  first_seen: string
  last_seen: string
  finding_count: number
  investigation_count: number
  workspaces: WorkspaceKey[]
  reputation: Record<string, unknown>
}

export interface IndicatorDetail extends IndicatorRow {
  findings: Finding[]
}

export interface Correlation {
  indicator_id: string
  type: string
  value: string
  is_internal: boolean
  workspaces: WorkspaceKey[]
  finding_ids: string[]
  other_investigations: { id: string; reference: string }[]
  correlated: boolean
  reasons: string[]
}

export interface ReferenceRow {
  id: string
  ref_type: 'cve' | 'attack_technique'
  external_id: string
  title: string
  description: string
  cvss_score: number | null
  cvss_vector: string | null
  severity: string | null
  url: string
  source: string
  fetched_at: string
  finding_count: number
  data: Record<string, unknown>
}

export interface RiskComponent {
  key: 'cve' | 'attack' | 'ioc'
  label: string
  value: number | null
  status: 'evaluated' | 'missing'
  weight: number
  explanation: string
  contributors: Record<string, unknown>[]
  excluded: Record<string, unknown>[]
}

export interface RiskAssessment {
  id: string
  investigation_id: string
  score: number | null
  lower_bound: number
  upper_bound: number
  coverage: number
  finding_count: number
  weights: Record<string, number>
  components: { formula: string; items: RiskComponent[]; missing: string[]; interpretation: string }
  computed_at: string
}

export type ReportStatus = 'draft' | 'in_review' | 'changes_requested' | 'approved'

export interface ReportSummary {
  id: string
  investigation_id: string
  investigation_reference: string
  version: number
  title: string
  status: ReportStatus
  generation_mode: 'llm' | 'template'
  llm_provider: string | null
  llm_model: string | null
  generated_by: UserRef
  reviewed_by: UserRef | null
  created_at: string
  reviewed_at: string | null
  risk_score: number | null
  finding_count: number
  citation_issue_count: number
  is_demo: boolean
}

export interface ReportFinding {
  id: string
  cite: string
  title: string
  severity: Severity
  confidence: string
  validation_status: string
  status: string
  origin: string
  workspace: WorkspaceKey
  source_tool: string
  affected_asset: string
  observed_at: string | null
  description: string
  evidence_refs: EvidenceRef[]
  indicators: { type: string; value: string }[]
  references: { type: string; id: string; title: string; url: string; validation: string; cvss?: number | null }[]
  remediation: { text: string; source: string }[]
}

export interface ReportContent {
  investigation: { id: string; reference: string; title: string; description: string; is_demo: boolean; status: string }
  generated_at: string
  generated_by: string
  scope: {
    description: string
    authorized_targets: { type: string; value: string; authorization: string; authorized_by: string; valid_until: string | null }[]
    workspaces_involved: string[]
  }
  data_sources: {
    tool_runs: {
      id: string
      tool: string
      workspace: string
      status: string
      requested_by: string
      approved_by: string | null
      finished_at: string | null
    }[]
    evidence: {
      id: string
      filename: string
      kind: string
      sha256: string
      size_bytes: number
      acquired_at: string | null
      source: string
      original: boolean
    }[]
  }
  severity_counts: SeverityCounts
  findings: ReportFinding[]
  excluded_finding_count: number
  indicators: {
    type: string
    value: string
    internal: boolean
    workspaces: string[]
    finding_ids: string[]
    correlated: boolean
    reasons: string[]
  }[]
  cve_references: {
    id: string
    title: string
    url: string
    validation: string
    cvss: number | null
    enriched: boolean
    finding_ids: string[]
  }[]
  attack_references: { id: string; title: string; url: string; validation: string; tactics: string[]; finding_ids: string[] }[]
  risk: {
    score: number | null
    lower_bound: number
    upper_bound: number
    coverage: number
    components: RiskComponent[]
    formula: string
    interpretation: string
  }
  limitations: string[]
  analyst_notes: { author: string; at: string; body: string; finding: string | null }[]
}

export interface ReportNarrative {
  executive_summary: string
  technical_findings: string
  risk_assessment: string
  recommended_mitigations: { text: string; finding_ids: string[] }[]
  citation_issues: string[]
  generated_with: 'llm' | 'template'
  llm_error?: string
}

export interface ReportDetail extends ReportSummary {
  content: ReportContent
  narrative: ReportNarrative
  analyst_notes: string
  submitted_at: string | null
  review_comment: string
}

export interface PlanStep {
  index: number
  action: string
  workspace: WorkspaceKey | null
  tool: string | null
  tool_title: string | null
  arguments: Record<string, unknown>
  required_permissions: string[]
  approval_required: boolean
  status: string
  detail: string
  run_id: string | null
  result: Record<string, unknown> | null
}

export interface EvidenceReference {
  cite: string
  finding_id: string
  title: string
  severity: Severity
  evidence: EvidenceRef[]
}

export interface Explanation {
  mode: 'llm' | 'template'
  provider?: string
  model?: string
  text: string
  cited: string[]
  citation_issues: string[]
  evidence_references: EvidenceReference[]
}

export interface Orchestration {
  intent?: { workspace: string | null; task: string; router: string; rationale: string; router_error: string | null }
  clarification?: string | null
  plan?: PlanStep[]
  execution_status?: string
  explanation?: Explanation | null
  evidence_references?: EvidenceReference[]
  errors?: string[]
  notices?: string[]
  source_run?: { id: string; tool: string; status: string; summary: Record<string, unknown> }
  investigation_id?: string | null
  llm?: { configured: boolean; provider: string; model: string | null; detail: string }
}

export interface AssistantMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  orchestration: Orchestration
  created_at: string
}

export interface ConversationSummary {
  id: string
  title: string
  investigation_id: string | null
  created_at: string
  updated_at: string
}

export interface Conversation extends ConversationSummary {
  messages: AssistantMessage[]
}

export interface DashboardSummary {
  generated_at: string
  has_demo_data: boolean
  investigations: { total: number; open: number; closed: number }
  findings_by_severity: SeverityCounts
  open_findings: number
  runs_by_status: Partial<Record<RunStatus, number>>
  recent_runs: {
    id: string
    tool: string
    workspace: WorkspaceKey
    status: RunStatus
    investigation_id: string
    investigation_reference: string
    requested_by: string
    created_at: string
    finished_at: string | null
  }[]
  recent_alerts: {
    id: string
    title: string
    severity: Severity
    workspace: WorkspaceKey
    source_tool: string
    investigation_id: string
    investigation_reference: string
    observed_at: string
    status: string
  }[]
  recent_iocs: { id: string; type: string; value: string; last_seen: string; finding_count: number }[]
  latest_reports: { id: string; title: string; status: ReportStatus; version: number; investigation_reference: string; created_at: string }[]
  recent_activity: { id: number; occurred_at: string; actor: string; action: string; result: string }[]
  activity_scope: 'all' | 'own'
  workspace_activity: { workspace: WorkspaceKey; runs_30d: number; findings_30d: number }[]
}
