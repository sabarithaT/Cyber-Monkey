// Thin fetch wrapper for the Cyber Monkey API.
//
// The browser authenticates with the HttpOnly session cookie set at login (it is never
// readable from JavaScript). Every request carries the X-CM-Client header, which the
// backend requires on cookie-authenticated writes as a CSRF defence.

export const API_BASE = '/api/v1'

export interface ApiErrorBody {
  code: string
  message: string
  details?: unknown
}

export class ApiError extends Error {
  readonly status: number
  readonly code: string
  readonly details: unknown

  constructor(status: number, body: ApiErrorBody) {
    super(body.message)
    this.status = status
    this.code = body.code
    this.details = body.details
  }
}

type Listener = () => void
const unauthorizedListeners = new Set<Listener>()

/** Subscribe to "session is no longer valid" events (401 from any request). */
export function onUnauthorized(listener: Listener): () => void {
  unauthorizedListeners.add(listener)
  return () => unauthorizedListeners.delete(listener)
}

type Query = Record<string, string | number | boolean | undefined | null>

export function buildQuery(params?: Query): string {
  if (!params) return ''
  const search = new URLSearchParams()
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== '') search.set(key, String(value))
  }
  const text = search.toString()
  return text ? `?${text}` : ''
}

async function parseError(response: Response): Promise<ApiError> {
  let body: ApiErrorBody = { code: 'http_error', message: response.statusText || 'Request failed' }
  try {
    const json = (await response.json()) as { error?: ApiErrorBody }
    if (json?.error) body = json.error
  } catch {
    // non-JSON error body; keep the status text
  }
  return new ApiError(response.status, body)
}

export async function request<T>(
  method: string,
  path: string,
  options: { query?: Query; body?: unknown; form?: FormData; signal?: AbortSignal } = {},
): Promise<T> {
  const headers: Record<string, string> = { 'X-CM-Client': 'web', Accept: 'application/json' }
  let body: BodyInit | undefined
  if (options.form) {
    body = options.form
  } else if (options.body !== undefined) {
    headers['Content-Type'] = 'application/json'
    body = JSON.stringify(options.body)
  }
  const response = await fetch(`${API_BASE}${path}${buildQuery(options.query)}`, {
    method,
    headers,
    body,
    credentials: 'same-origin',
    signal: options.signal,
  })
  if (!response.ok) {
    const error = await parseError(response)
    if (response.status === 401 && !path.startsWith('/auth/login')) {
      unauthorizedListeners.forEach((listener) => listener())
    }
    throw error
  }
  if (response.status === 204) return undefined as T
  const type = response.headers.get('content-type') ?? ''
  if (type.includes('application/json')) return (await response.json()) as T
  return (await response.blob()) as T
}

export const api = {
  get: <T>(path: string, query?: Query, signal?: AbortSignal) => request<T>('GET', path, { query, signal }),
  post: <T>(path: string, body?: unknown) => request<T>('POST', path, { body }),
  put: <T>(path: string, body?: unknown) => request<T>('PUT', path, { body }),
  patch: <T>(path: string, body?: unknown) => request<T>('PATCH', path, { body }),
  delete: <T>(path: string) => request<T>('DELETE', path),
  upload: <T>(path: string, form: FormData) => request<T>('POST', path, { form }),
}

/** Download a binary response (e.g. a PDF) and hand it to the browser as a file. */
export async function downloadFile(path: string, filename: string): Promise<void> {
  const blob = await request<Blob>('GET', path)
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  link.remove()
  URL.revokeObjectURL(url)
}

export function errorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    if (error.code === 'validation_failed' && Array.isArray(error.details) && error.details.length) {
      const first = error.details[0] as { loc?: (string | number)[]; msg?: string }
      const field = (first.loc ?? []).filter((part) => part !== 'body' && part !== 'query').join('.')
      const msg = (first.msg ?? '').replace(/^Value error, /, '')
      return field ? `${field}: ${msg}` : msg || error.message
    }
    return error.message
  }
  if (error instanceof Error) return error.message
  return 'Something went wrong'
}
