// TypeScript mirrors of the backend response schemas (see /api/docs for the source of truth).

export type WorkspaceKey = 'soc' | 'pentest' | 'osint' | 'malware' | 'forensics' | 'network'
export type Severity = 'info' | 'low' | 'medium' | 'high' | 'critical'

export interface Page<T> {
  items: T[]
  total: number
  page: number
  page_size: number
}

export interface RoleSummary {
  id: number
  slug: string
  name: string
}

export interface User {
  id: string
  email: string
  full_name: string
  is_active: boolean
  last_login_at: string | null
  created_at: string
  roles: RoleSummary[]
  direct_permissions: string[]
}

export interface Me extends User {
  permissions: string[]
  workspaces: WorkspaceKey[]
}

export interface LoginResponse {
  access_token: string
  token_type: string
  expires_at: string
  user: Me
}

export interface Permission {
  id: number
  code: string
  scope: string
  action: string
  description: string
}

export interface Role {
  id: number
  slug: string
  name: string
  description: string
  is_system: boolean
  permissions: string[]
  user_count: number
}

export interface AuditLogEntry {
  id: number
  occurred_at: string
  actor_id: string | null
  actor_email: string
  action: string
  resource_type: string
  resource_id: string
  result: 'success' | 'failure' | 'denied'
  ip_address: string
  user_agent: string
  details: Record<string, unknown>
}

export interface Message {
  message: string
}
