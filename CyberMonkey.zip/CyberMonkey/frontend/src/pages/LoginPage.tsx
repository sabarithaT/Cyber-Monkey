import { ShieldCheck } from 'lucide-react'
import { useState, type FormEvent } from 'react'
import { Navigate, useLocation, useNavigate } from 'react-router-dom'
import { errorMessage } from '../api/client'
import { useAuth } from '../auth/AuthContext'
import { Button } from '../components/ui/Button'
import { TextField } from '../components/ui/Form'
import { Alert, LoadingState } from '../components/ui/States'
import { Logo } from '../layout/Sidebar'

export function LoginPage() {
  const { user, loading, login } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const from = (location.state as { from?: string } | null)?.from ?? '/'

  if (loading) return <LoadingState label="Checking session…" />
  if (user) return <Navigate to={from} replace />

  async function onSubmit(event: FormEvent) {
    event.preventDefault()
    setError(null)
    setSubmitting(true)
    try {
      await login(email, password)
      navigate(from, { replace: true })
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="flex min-h-full items-center justify-center px-4 py-12">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex justify-center">
          <Logo />
        </div>
        <div className="rounded-lg border border-line bg-surface p-6 shadow-xl">
          <h1 className="text-lg font-semibold">Sign in</h1>
          <p className="mt-1 text-sm text-fg-muted">Role-based access to the unified security operations platform.</p>
          <form className="mt-6 space-y-4" onSubmit={onSubmit} noValidate>
            {error ? <Alert tone="danger">{error}</Alert> : null}
            <TextField
              label="Email"
              type="email"
              autoComplete="username"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <TextField
              label="Password"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <Button type="submit" variant="primary" className="w-full" loading={submitting} disabled={!email || !password}>
              Sign in
            </Button>
          </form>
        </div>
        <p className="mt-6 flex items-start gap-2 text-xs leading-relaxed text-fg-subtle">
          <ShieldCheck className="mt-0.5 size-4 shrink-0" />
          Activity is audit-logged. Accounts lock temporarily after repeated failed sign-ins. Accounts are created by an
          administrator.
        </p>
      </div>
    </div>
  )
}
