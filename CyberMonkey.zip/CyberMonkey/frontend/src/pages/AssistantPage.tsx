import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Bot, MessageSquarePlus, Send, Trash2, User as UserIcon } from 'lucide-react'
import { useEffect, useRef, useState, type FormEvent } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { api, errorMessage } from '../api/client'
import type { AssistantMessage, Conversation, ConversationSummary, Evidence, Orchestration, PlanStep } from '../api/models'
import { FindingDetail } from '../components/FindingDetail'
import { InvestigationPicker } from '../components/InvestigationPicker'
import { RunDecisionButtons, RunDetail, useRun } from '../components/RunPanels'
import { Badge, SeverityBadge, StatusBadge } from '../components/ui/Badge'
import { Button } from '../components/ui/Button'
import { Card, CodeBlock, PageHeader } from '../components/ui/Card'
import { Select, Textarea } from '../components/ui/Form'
import { ConfirmDialog } from '../components/ui/Modal'
import { Alert, EmptyState, LoadingState } from '../components/ui/States'
import { useToast } from '../components/ui/Toast'
import { formatRelative, titleCase } from '../lib/format'

const EXAMPLES = [
  'Analyze the imported scan results, identify the most critical findings, correlate them with known vulnerabilities, and generate a security report.',
  'Profile the suspicious sample and calculate its hashes',
  'Correlate indicators across workspaces and compute the risk score',
  'What can you do?',
]

const STEP_TONE: Record<string, string> = {
  done: 'succeeded',
  awaiting_approval: 'pending_approval',
  deferred: 'queued',
  continued: 'succeeded',
  needs_input: 'changes_requested',
  denied: 'denied',
}

function StepRun({ runId }: { runId: string }) {
  const run = useRun(runId)
  const [open, setOpen] = useState(false)
  if (!run.data) return null
  return (
    <div className="mt-2 flex flex-wrap items-center gap-2">
      <StatusBadge status={run.data.status} />
      <button type="button" className="text-xs text-accent hover:underline" onClick={() => setOpen(true)}>Run details</button>
      <RunDecisionButtons run={run.data} />
      <RunDetail runId={open ? runId : null} onClose={() => setOpen(false)} />
    </div>
  )
}

function StepView({ step }: { step: PlanStep }) {
  const result = step.result as Record<string, unknown> | null
  return (
    <li className="rounded-md border border-line bg-canvas/60 p-3">
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs tabular-nums text-fg-subtle">Step {step.index + 1}</span>
        <span className="text-sm font-medium">{step.tool_title ?? titleCase(step.action)}</span>
        {step.tool ? <span className="font-mono text-[11px] text-fg-subtle">{step.tool}</span> : null}
        <StatusBadge status={STEP_TONE[step.status] ?? step.status} label={titleCase(step.status)} />
        {step.approval_required ? <Badge tone="warning">Confirmation required</Badge> : null}
        {step.workspace ? <Badge>{step.workspace}</Badge> : null}
      </div>
      {step.detail ? <p className="mt-1.5 text-xs text-fg-muted">{step.detail}</p> : null}
      {step.required_permissions.length ? (
        <p className="mt-1 text-[11px] text-fg-subtle">Permissions: {step.required_permissions.join(', ')}</p>
      ) : null}
      {step.tool && Object.keys(step.arguments).length ? (
        <CodeBlock className="mt-2 max-h-28">{JSON.stringify(step.arguments, null, 2)}</CodeBlock>
      ) : null}
      {step.run_id ? <StepRun runId={step.run_id} /> : null}
      {result && step.action === 'assess_risk' ? (
        <p className="mt-2 text-xs text-fg">
          Score {result.score === null ? 'not available' : `${Math.round(Number(result.score) * 100)}/100`} · coverage{' '}
          {Math.round(Number(result.coverage) * 100)}% · range {Math.round(Number(result.lower_bound) * 100)}–{Math.round(Number(result.upper_bound) * 100)}
        </p>
      ) : null}
      {result && step.action === 'correlate' ? (
        <div className="mt-2 text-xs">
          <p>{String(result.correlated)} of {String(result.indicators)} indicator(s) correlated.</p>
          <ul className="mt-1 space-y-0.5 text-fg-muted">
            {(result.items as { indicator: string; reasons: string[] }[]).map((i) => (
              <li key={i.indicator}><span className="font-mono">{i.indicator}</span> — {i.reasons.join('; ')}</li>
            ))}
          </ul>
        </div>
      ) : null}
      {result && step.action === 'generate_report' ? (
        <p className="mt-2 text-xs">
          <Link to={`/reports/${String(result.report_id)}`} className="text-accent hover:underline">Open report v{String(result.version)}</Link>
          <span className="text-fg-subtle"> · draft for review · narrative {String(result.mode)} · {String(result.citation_issues)} citation issue(s)</span>
        </p>
      ) : null}
      {result && step.action === 'capabilities' ? (
        <div className="mt-2 text-xs text-fg-muted">
          <p>Workspaces: {(result.workspaces as string[]).join(', ') || 'none'}</p>
          <p>Actions: {(result.actions as string[]).map(titleCase).join(', ')}</p>
          <ul className="mt-1 space-y-0.5">
            {(result.tools as { tool: string; title: string; available: boolean; permitted: boolean }[]).map((t) => (
              <li key={t.tool}>
                <span className="font-mono">{t.tool}</span> — {t.title} {t.available ? '' : '(not configured)'} {t.permitted ? '' : '(not permitted)'}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </li>
  )
}

function OrchestrationView({ record, onFinding }: { record: Orchestration; onFinding: (id: string) => void }) {
  return (
    <div className="mt-3 space-y-3">
      {record.intent ? (
        <div className="flex flex-wrap items-center gap-2 text-[11px] text-fg-subtle">
          <Badge tone={record.intent.router === 'llm' ? 'violet' : 'neutral'}>
            {record.intent.router === 'llm' ? `LLM router${record.llm?.model ? ` · ${record.llm.model}` : ''}` : record.intent.router === 'continuation' ? 'Follow-up' : 'Rule-based router'}
          </Badge>
          {record.intent.workspace ? <span>Workspace: {record.intent.workspace}</span> : null}
          <span>Task: {titleCase(record.intent.task)}</span>
          {record.execution_status ? <StatusBadge status={STEP_TONE[record.execution_status] ?? record.execution_status} label={titleCase(record.execution_status)} /> : null}
        </div>
      ) : null}
      {record.plan?.length ? <ol className="space-y-2">{record.plan.map((s) => <StepView key={s.index} step={s} />)}</ol> : null}
      {record.explanation ? (
        <div className="rounded-md border border-line bg-surface-2 p-3">
          <p className="mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-fg-subtle">
            {record.explanation.mode === 'llm' ? 'AI-generated interpretation of the findings below' : 'Deterministic summary of recorded findings'}
          </p>
          <p className="whitespace-pre-wrap text-sm">{record.explanation.text}</p>
          {record.explanation.citation_issues.length ? (
            <div className="mt-2"><Alert tone="warning" title="Citation check">{record.explanation.citation_issues.join('; ')}</Alert></div>
          ) : null}
        </div>
      ) : null}
      {record.evidence_references?.length ? (
        <div>
          <p className="mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-fg-subtle">Supporting evidence</p>
          <ul className="space-y-1">
            {record.evidence_references.map((ref) => (
              <li key={ref.finding_id} className="flex flex-wrap items-center gap-2 text-xs">
                <SeverityBadge severity={ref.severity} />
                <button type="button" className="font-mono text-accent hover:underline" onClick={() => onFinding(ref.finding_id)}>{ref.cite}</button>
                <span>{ref.title}</span>
                {ref.evidence[0] ? <span className="text-fg-subtle">evidence {ref.evidence[0].evidence_id?.slice(0, 8)} @ {ref.evidence[0].locator}</span> : null}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
      {record.notices?.length ? <Alert tone="info">{record.notices.join(' ')}</Alert> : null}
      {record.errors?.length ? <Alert tone="danger">{record.errors.join(' ')}</Alert> : null}
    </div>
  )
}

function MessageView({ message, onFinding }: { message: AssistantMessage; onFinding: (id: string) => void }) {
  const isUser = message.role === 'user'
  const record = message.orchestration
  const showText = isUser || !record.plan?.length || record.clarification || (record.source_run && !record.plan?.length)
  return (
    <div className={`flex gap-3 ${isUser ? 'flex-row-reverse' : ''}`}>
      <span className={`flex size-8 shrink-0 items-center justify-center rounded-full ${isUser ? 'bg-surface-3' : 'bg-accent-soft text-accent'}`}>
        {isUser ? <UserIcon className="size-4" /> : <Bot className="size-4" />}
      </span>
      <div className={`min-w-0 max-w-3xl flex-1 rounded-lg border px-4 py-3 ${isUser ? 'border-line-strong bg-surface-3' : 'border-line bg-surface'}`}>
        {record.source_run ? (
          <p className="mb-1 text-[11px] uppercase tracking-wide text-fg-subtle">Result of {record.source_run.tool}</p>
        ) : null}
        {showText ? <p className="whitespace-pre-wrap text-sm">{isUser ? message.content : record.clarification ?? message.content}</p> : null}
        {!isUser ? <OrchestrationView record={record} onFinding={onFinding} /> : null}
        <p className="mt-2 text-[10px] text-fg-subtle">{formatRelative(message.created_at)}</p>
      </div>
    </div>
  )
}

export function AssistantPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [params, setParams] = useSearchParams()
  const [text, setText] = useState('')
  const [deleting, setDeleting] = useState<string | null>(null)
  const [finding, setFinding] = useState<string | null>(null)
  const [evidenceId, setEvidenceId] = useState('')
  const conversationId = params.get('conversation')
  const investigationId = params.get('investigation') ?? ''
  const endRef = useRef<HTMLDivElement>(null)

  const status = useQuery({ queryKey: ['assistant-status'], queryFn: () => api.get<{ llm: Orchestration['llm'] }>('/assistant/status') })
  const conversations = useQuery({ queryKey: ['conversations'], queryFn: () => api.get<ConversationSummary[]>('/assistant/conversations') })
  const conversation = useQuery({
    queryKey: ['conversation', conversationId],
    queryFn: () => api.get<Conversation>(`/assistant/conversations/${conversationId}`),
    enabled: !!conversationId,
    refetchInterval: (q) => {
      const last = q.state.data?.messages.at(-1)
      const status = last?.orchestration.execution_status
      return status === 'running' ? 2000 : status === 'awaiting_approval' ? 5000 : false
    },
  })
  const evidence = useQuery({
    queryKey: ['evidence', investigationId, false],
    queryFn: () => api.get<Evidence[]>(`/investigations/${investigationId}/evidence`, { include_derived: false }),
    enabled: !!investigationId,
  })

  useEffect(() => {
    if (conversation.data?.investigation_id && !investigationId) {
      setParams({ conversation: conversation.data.id, investigation: conversation.data.investigation_id }, { replace: true })
    }
  }, [conversation.data, investigationId, setParams])
  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [conversation.data?.messages.length])

  const send = useMutation({
    mutationFn: (message: string) =>
      api.post<{ conversation: ConversationSummary; assistant_message: AssistantMessage }>('/assistant/chat', {
        message,
        conversation_id: conversationId ?? undefined,
        investigation_id: investigationId || undefined,
        evidence_id: evidenceId || undefined,
      }),
    onSuccess: (data) => {
      setText('')
      setParams({ conversation: data.conversation.id, ...(investigationId ? { investigation: investigationId } : {}) })
      queryClient.invalidateQueries({ queryKey: ['conversation', data.conversation.id] })
      queryClient.invalidateQueries({ queryKey: ['conversations'] })
      queryClient.invalidateQueries({ queryKey: ['notifications'] })
    },
    onError: (e) => toast.error(errorMessage(e)),
  })
  const remove = useMutation({
    mutationFn: (id: string) => api.delete(`/assistant/conversations/${id}`),
    onSuccess: (_, id) => {
      setDeleting(null)
      if (id === conversationId) setParams({})
      queryClient.invalidateQueries({ queryKey: ['conversations'] })
    },
  })

  function submit(event: FormEvent) {
    event.preventDefault()
    if (text.trim()) send.mutate(text.trim())
  }

  const llm = status.data?.llm
  return (
    <>
      <PageHeader
        title="AI Assistant"
        description="Describe a security task in plain language. The orchestrator plans it with registered tools only, checks your permissions, arguments and authorized scope, asks for confirmation where required, and explains actual results with evidence citations."
        badge={llm ? <Badge tone={llm.configured ? 'violet' : 'neutral'}>{llm.configured ? `${llm.provider} · ${llm.model}` : 'No LLM configured — rule-based routing'}</Badge> : null}
      />
      <div className="grid gap-4 lg:grid-cols-[16rem_1fr]">
        <Card className="h-fit">
          <div className="border-b border-line p-3">
            <Button size="sm" className="w-full" icon={MessageSquarePlus} onClick={() => setParams(investigationId ? { investigation: investigationId } : {})}>New conversation</Button>
          </div>
          {conversations.isLoading ? <LoadingState /> : conversations.data?.length ? (
            <ul className="max-h-[60vh] overflow-y-auto p-1.5">
              {conversations.data.map((c) => (
                <li key={c.id} className="group flex items-center">
                  <button
                    type="button"
                    onClick={() => setParams({ conversation: c.id, ...(c.investigation_id ? { investigation: c.investigation_id } : {}) })}
                    className={`min-w-0 flex-1 truncate rounded px-2 py-1.5 text-left text-xs ${c.id === conversationId ? 'bg-accent-soft text-accent' : 'text-fg-muted hover:bg-surface-3 hover:text-fg'}`}
                  >
                    {c.title}
                    <span className="block text-[10px] text-fg-subtle">{formatRelative(c.updated_at)}</span>
                  </button>
                  <button type="button" className="p-1 text-fg-subtle opacity-0 hover:text-rose-300 group-hover:opacity-100" aria-label="Delete conversation" onClick={() => setDeleting(c.id)}>
                    <Trash2 className="size-3.5" />
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="p-4 text-xs text-fg-subtle">No conversations yet.</p>
          )}
        </Card>
        <Card className="flex min-h-[70vh] flex-col">
          <div className="flex flex-wrap items-center gap-2 border-b border-line p-3">
            <InvestigationPicker
              value={investigationId}
              onChange={(id) => {
                setEvidenceId('')
                setParams({ ...(conversationId ? { conversation: conversationId } : {}), ...(id ? { investigation: id } : {}) })
              }}
              allowNone
              className="h-8 max-w-md text-xs"
            />
            {investigationId ? (
              <Select value={evidenceId} onChange={(e) => setEvidenceId(e.target.value)} className="h-8 max-w-xs text-xs" aria-label="Evidence">
                <option value="">Evidence: let the assistant choose</option>
                {evidence.data?.map((ev) => (
                  <option key={ev.id} value={ev.id}>{ev.original_filename} · {ev.kind}</option>
                ))}
              </Select>
            ) : (
              <span className="text-xs text-fg-subtle">Select an investigation to run tools, correlate or generate reports.</span>
            )}
          </div>
          <div className="flex-1 space-y-5 overflow-y-auto p-4">
            {!conversationId ? (
              <EmptyState
                icon={Bot}
                title="Start a request"
                description="The assistant only uses registered tools and your real data. It never invents scan results or findings."
                action={
                  <div className="flex max-w-2xl flex-col gap-2">
                    {EXAMPLES.map((e) => (
                      <button key={e} type="button" onClick={() => setText(e)} className="rounded-md border border-line px-3 py-2 text-left text-xs text-fg-muted hover:border-accent/50 hover:text-fg">
                        {e}
                      </button>
                    ))}
                  </div>
                }
              />
            ) : conversation.isLoading ? <LoadingState /> : (
              conversation.data?.messages.map((m) => <MessageView key={m.id} message={m} onFinding={setFinding} />)
            )}
            <div ref={endRef} />
          </div>
          <form onSubmit={submit} className="border-t border-line p-3">
            <div className="flex items-end gap-2">
              <Textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault()
                    if (text.trim()) send.mutate(text.trim())
                  }
                }}
                placeholder="e.g. Summarize the most critical findings and generate a report"
                className="min-h-12 flex-1 resize-none"
                maxLength={4000}
              />
              <Button type="submit" variant="primary" icon={Send} loading={send.isPending} disabled={!text.trim()}>Send</Button>
            </div>
            <p className="mt-1.5 text-[10px] text-fg-subtle">Requests are audit-logged. Consequential actions always require your explicit confirmation.</p>
          </form>
        </Card>
      </div>
      <FindingDetail findingId={finding} onClose={() => setFinding(null)} />
      <ConfirmDialog
        open={!!deleting}
        title="Delete conversation?"
        tone="danger"
        confirmLabel="Delete"
        loading={remove.isPending}
        onCancel={() => setDeleting(null)}
        onConfirm={() => deleting && remove.mutate(deleting)}
      >
        <p>The conversation is removed. Tool runs, findings and reports it created are kept.</p>
      </ConfirmDialog>
    </>
  )
}
