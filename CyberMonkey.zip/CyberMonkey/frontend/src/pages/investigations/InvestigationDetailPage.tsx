import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { FilePlus2, Plus, Trash2, UserPlus } from 'lucide-react'
import { useState } from 'react'
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { api, errorMessage } from '../../api/client'
import type { InvestigationDetail, Note, ReportSummary, TimelineEntry } from '../../api/models'
import type { Page } from '../../api/types'
import { useAuth } from '../../auth/AuthContext'
import { EvidencePanel } from '../../components/EvidencePanel'
import { FindingsTable } from '../../components/FindingsTable'
import { CorrelationPanel, RiskPanel } from '../../components/IntelPanels'
import { RunsTable, ToolsCard } from '../../components/RunPanels'
import { Badge, DemoBadge, SeverityBadge, StatusBadge } from '../../components/ui/Badge'
import { Button } from '../../components/ui/Button'
import { Card, CardBody, CardHeader, KeyValue, PageHeader, StatTile } from '../../components/ui/Card'
import { Field, Select, TextField, Textarea } from '../../components/ui/Form'
import { ConfirmDialog, Modal } from '../../components/ui/Modal'
import { Alert, EmptyState, ErrorState, LoadingState } from '../../components/ui/States'
import { DataTable } from '../../components/ui/Table'
import { Tabs } from '../../components/ui/Tabs'
import { useToast } from '../../components/ui/Toast'
import { formatDateTime, formatRelative, titleCase } from '../../lib/format'
import { WORKSPACE_BY_KEY } from '../../lib/workspaces'

function ScopeSection({ inv, writable }: { inv: InvestigationDetail; writable: boolean }) {
  const { can } = useAuth()
  const toast = useToast()
  const queryClient = useQueryClient()
  const [adding, setAdding] = useState(false)
  const [removing, setRemoving] = useState<string | null>(null)
  const [form, setForm] = useState({ target_type: 'ip', value: '', authorization_reference: '', valid_until: '', notes: '' })
  const add = useMutation({
    mutationFn: () =>
      api.post(`/investigations/${inv.id}/scope`, {
        ...form,
        valid_until: form.valid_until ? new Date(form.valid_until).toISOString() : null,
      }),
    onSuccess: () => {
      toast.success('Authorized target registered')
      setAdding(false)
      setForm({ target_type: 'ip', value: '', authorization_reference: '', valid_until: '', notes: '' })
      queryClient.invalidateQueries({ queryKey: ['investigation', inv.id] })
    },
  })
  const remove = useMutation({
    mutationFn: (id: string) => api.delete(`/investigations/${inv.id}/scope/${id}`),
    onSuccess: () => {
      toast.success('Target removed from scope')
      setRemoving(null)
      queryClient.invalidateQueries({ queryKey: ['investigation', inv.id] })
    },
    onError: (e) => toast.error(errorMessage(e)),
  })
  const canEdit = writable && can('pentest:operate')
  return (
    <Card>
      <CardHeader
        title="Authorized scope"
        subtitle="Active tools refuse any target not covered here. Record who authorized each target and where that authorization is documented."
        actions={canEdit ? <Button size="sm" icon={Plus} onClick={() => setAdding(true)}>Add target</Button> : null}
      />
      <DataTable
        rows={inv.scope_targets}
        rowKey={(t) => t.id}
        dense
        empty={<EmptyState title="No authorized targets" description="Register explicitly authorized lab targets before requesting any active assessment tool." />}
        columns={[
          { key: 't', header: 'Target', render: (t) => <span className="font-mono text-xs">{t.target_type}:{t.value}</span> },
          { key: 'auth', header: 'Authorization', render: (t) => <span className="text-xs">{t.authorization_reference}</span> },
          { key: 'by', header: 'Registered by', render: (t) => <span className="text-xs">{t.authorized_by.email}</span> },
          { key: 'until', header: 'Valid until', render: (t) => <span className="text-xs">{t.valid_until ? formatDateTime(t.valid_until) : 'No expiry'}</span> },
          { key: 'active', header: 'State', render: (t) => <StatusBadge status={t.active ? 'available' : 'disabled'} label={t.active ? 'Active' : 'Expired'} /> },
          ...(canEdit
            ? [{ key: 'x', header: '', render: (t: InvestigationDetail['scope_targets'][number]) => (
                <Button size="sm" variant="ghost" icon={Trash2} aria-label="Remove target" onClick={(e) => { e.stopPropagation(); setRemoving(t.id) }} />
              ) }]
            : []),
        ]}
      />
      <Modal
        open={adding}
        onClose={() => setAdding(false)}
        title="Register authorized target"
        footer={
          <>
            <Button variant="ghost" onClick={() => setAdding(false)}>Cancel</Button>
            <Button variant="primary" loading={add.isPending} disabled={!form.value || form.authorization_reference.length < 5} onClick={() => add.mutate()}>Register target</Button>
          </>
        }
      >
        <div className="space-y-4">
          {add.isError ? <Alert tone="danger">{errorMessage(add.error)}</Alert> : null}
          <Alert tone="warning">Only register systems you own or have written permission to test.</Alert>
          <div className="grid gap-4 sm:grid-cols-[8rem_1fr]">
            <Field label="Type">
              <Select value={form.target_type} onChange={(e) => setForm({ ...form, target_type: e.target.value })}>
                <option value="ip">IP address</option>
                <option value="cidr">CIDR range</option>
                <option value="hostname">Hostname</option>
              </Select>
            </Field>
            <TextField label="Target" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} placeholder="192.168.56.10" />
          </div>
          <Field label="Authorization reference" hint="Who authorized it and where it is recorded (rules of engagement, ticket, lab ownership).">
            <Textarea value={form.authorization_reference} onChange={(e) => setForm({ ...form, authorization_reference: e.target.value })} className="min-h-16" />
          </Field>
          <TextField label="Valid until (optional)" type="datetime-local" value={form.valid_until} onChange={(e) => setForm({ ...form, valid_until: e.target.value })} />
        </div>
      </Modal>
      <ConfirmDialog
        open={!!removing}
        title="Remove target from scope?"
        tone="danger"
        confirmLabel="Remove"
        loading={remove.isPending}
        onCancel={() => setRemoving(null)}
        onConfirm={() => removing && remove.mutate(removing)}
      >
        <p>Tools will no longer be allowed to target it in this investigation.</p>
      </ConfirmDialog>
    </Card>
  )
}

function MembersSection({ inv }: { inv: InvestigationDetail }) {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [email, setEmail] = useState('')
  const [level, setLevel] = useState('contributor')
  const isOwner = inv.my_access === 'owner' || inv.my_access === 'manager'
  const add = useMutation({
    mutationFn: () => api.post(`/investigations/${inv.id}/members`, { email, access_level: level }),
    onSuccess: () => {
      toast.success('Member added')
      setEmail('')
      queryClient.invalidateQueries({ queryKey: ['investigation', inv.id] })
    },
    onError: (e) => toast.error(errorMessage(e)),
  })
  const remove = useMutation({
    mutationFn: (userId: string) => api.delete(`/investigations/${inv.id}/members/${userId}`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['investigation', inv.id] }),
    onError: (e) => toast.error(errorMessage(e)),
  })
  return (
    <Card>
      <CardHeader title="Team" subtitle="Members see this investigation; contributors can add evidence, run tools and write notes." />
      <CardBody className="space-y-3">
        <ul className="space-y-2 text-sm">
          <li className="flex items-center justify-between">
            <span>{inv.owner.full_name} <span className="text-xs text-fg-subtle">{inv.owner.email}</span></span>
            <Badge tone="accent">Owner</Badge>
          </li>
          {inv.members.map((m) => (
            <li key={m.user.id} className="flex items-center justify-between gap-2">
              <span>{m.user.full_name} <span className="text-xs text-fg-subtle">{m.user.email}</span></span>
              <span className="flex items-center gap-2">
                <Badge>{titleCase(m.access_level)}</Badge>
                {isOwner ? <Button size="sm" variant="ghost" icon={Trash2} aria-label="Remove member" onClick={() => remove.mutate(m.user.id)} /> : null}
              </span>
            </li>
          ))}
        </ul>
        {isOwner ? (
          <div className="flex flex-wrap gap-2 border-t border-line pt-3">
            <TextField label="Add member by email" value={email} onChange={(e) => setEmail(e.target.value)} />
            <Field label="Access">
              <Select value={level} onChange={(e) => setLevel(e.target.value)}>
                <option value="contributor">Contributor</option>
                <option value="viewer">Viewer</option>
              </Select>
            </Field>
            <Button size="sm" icon={UserPlus} className="self-end" loading={add.isPending} disabled={!email} onClick={() => add.mutate()}>Add</Button>
          </div>
        ) : null}
      </CardBody>
    </Card>
  )
}

function Overview({ inv, writable }: { inv: InvestigationDetail; writable: boolean }) {
  const toast = useToast()
  const queryClient = useQueryClient()
  const update = useMutation({
    mutationFn: (status: string) => api.patch(`/investigations/${inv.id}`, { status }),
    onSuccess: () => {
      toast.success('Status updated')
      queryClient.invalidateQueries({ queryKey: ['investigation', inv.id] })
    },
    onError: (e) => toast.error(errorMessage(e)),
  })
  const counts = inv.finding_counts
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        <StatTile label="Critical" value={counts.critical} tone={counts.critical ? 'danger' : 'default'} />
        <StatTile label="High" value={counts.high} tone={counts.high ? 'warning' : 'default'} />
        <StatTile label="Medium / Low" value={`${counts.medium} / ${counts.low}`} />
        <StatTile label="Tool runs" value={inv.run_count} />
        <StatTile label="Evidence items" value={inv.evidence_count} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader
            title="Case details"
            actions={
              writable ? (
                <Select value={inv.status} onChange={(e) => update.mutate(e.target.value)} className="h-8 w-auto text-xs" aria-label="Investigation status">
                  <option value="open">Open</option>
                  <option value="in_progress">In progress</option>
                  <option value="closed">Closed</option>
                </Select>
              ) : null
            }
          />
          <CardBody>
            <KeyValue
              items={[
                ['Reference', <span className="font-mono">{inv.reference}</span>],
                ['Primary workspace', WORKSPACE_BY_KEY[inv.primary_workspace]?.label],
                ['Status', <StatusBadge status={inv.status} />],
                ['Your access', titleCase(inv.my_access)],
                ['Created', formatDateTime(inv.created_at)],
                ['Description', <span className="whitespace-pre-wrap text-fg-muted">{inv.description || 'No description recorded.'}</span>],
              ]}
            />
          </CardBody>
        </Card>
        <MembersSection inv={inv} />
      </div>
      <ScopeSection inv={inv} writable={writable} />
    </div>
  )
}

function ReportsSection({ inv, writable }: { inv: InvestigationDetail; writable: boolean }) {
  const { can } = useAuth()
  const toast = useToast()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const reports = useQuery({
    queryKey: ['reports', inv.id],
    queryFn: () => api.get<Page<ReportSummary>>('/reports', { investigation_id: inv.id, page_size: 50 }),
    enabled: can('reports:view'),
  })
  const generate = useMutation({
    mutationFn: () => api.post<{ id: string; version: number }>('/reports', { investigation_id: inv.id }),
    onSuccess: (r) => {
      toast.success(`Report version ${r.version} generated`)
      queryClient.invalidateQueries({ queryKey: ['reports'] })
      navigate(`/reports/${r.id}`)
    },
    onError: (e) => toast.error(errorMessage(e)),
  })
  return (
    <Card>
      <CardHeader
        title="Reports"
        subtitle="Structured from the database first; prose is written from that structure and every claim cites a finding."
        actions={writable && can('reports:generate') ? <Button size="sm" variant="primary" icon={FilePlus2} loading={generate.isPending} onClick={() => generate.mutate()}>Generate report</Button> : null}
      />
      <DataTable
        rows={reports.data?.items}
        loading={reports.isLoading}
        error={reports.error}
        rowKey={(r) => r.id}
        onRowClick={(r) => navigate(`/reports/${r.id}`)}
        dense
        empty={<EmptyState title="No reports yet" description="Generate a report to produce an executive summary, technical findings, risk assessment and mitigations." />}
        columns={[
          { key: 'v', header: 'Version', render: (r) => <span className="tabular-nums">v{r.version}</span> },
          { key: 's', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
          { key: 'm', header: 'Narrative', render: (r) => <Badge tone={r.generation_mode === 'llm' ? 'violet' : 'neutral'}>{r.generation_mode === 'llm' ? `LLM · ${r.llm_model}` : 'Template'}</Badge> },
          { key: 'f', header: 'Findings', render: (r) => <span className="text-xs tabular-nums">{r.finding_count}</span> },
          { key: 'c', header: 'Citation issues', render: (r) => <span className={r.citation_issue_count ? 'text-xs text-amber-300' : 'text-xs text-fg-subtle'}>{r.citation_issue_count}</span> },
          { key: 'g', header: 'Generated', render: (r) => <span className="text-xs text-fg-muted">{formatRelative(r.created_at)} by {r.generated_by.email}</span> },
        ]}
      />
    </Card>
  )
}

function TimelineSection({ investigationId }: { investigationId: string }) {
  const query = useQuery({
    queryKey: ['timeline', investigationId],
    queryFn: () => api.get<TimelineEntry[]>(`/investigations/${investigationId}/timeline`),
  })
  if (query.isLoading) return <LoadingState />
  if (query.error) return <ErrorState error={query.error} onRetry={() => query.refetch()} />
  if (!query.data?.length) return <EmptyState title="Nothing on the timeline yet" />
  return (
    <ol className="relative space-y-4 border-l border-line pl-5">
      {query.data.map((e, i) => (
        <li key={`${e.kind}-${e.ref_id}-${i}`}>
          <span className="absolute -left-[5px] mt-1.5 size-2.5 rounded-full border border-line-strong bg-surface-3" />
          <p className="text-[11px] tabular-nums text-fg-subtle">{formatDateTime(e.at)} · {titleCase(e.kind)}{e.workspace ? ` · ${e.workspace}` : ''}</p>
          <p className="mt-0.5 flex flex-wrap items-center gap-2 text-sm">
            {e.severity && e.kind === 'finding' ? <SeverityBadge severity={e.severity} /> : null}
            {e.title}
          </p>
          {e.detail ? <p className="text-xs text-fg-muted">{e.detail}</p> : null}
        </li>
      ))}
    </ol>
  )
}

function NotesSection({ investigationId, writable }: { investigationId: string; writable: boolean }) {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [body, setBody] = useState('')
  const notes = useQuery({ queryKey: ['notes', investigationId, 'all'], queryFn: () => api.get<Note[]>(`/investigations/${investigationId}/notes`) })
  const add = useMutation({
    mutationFn: () => api.post(`/investigations/${investigationId}/notes`, { body }),
    onSuccess: () => {
      setBody('')
      toast.success('Note added')
      queryClient.invalidateQueries({ queryKey: ['notes'] })
      queryClient.invalidateQueries({ queryKey: ['timeline', investigationId] })
    },
    onError: (e) => toast.error(errorMessage(e)),
  })
  return (
    <Card>
      <CardHeader title="Investigation notes" subtitle="Analyst notes are included in generated reports." />
      <CardBody className="space-y-3">
        {writable ? (
          <div className="space-y-2">
            <Textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder="Record an observation, decision or next step" />
            <Button size="sm" variant="primary" disabled={!body.trim()} loading={add.isPending} onClick={() => add.mutate()}>Add note</Button>
          </div>
        ) : null}
        {notes.data?.length ? (
          notes.data.map((n) => (
            <div key={n.id} className="rounded-md border border-line bg-surface-2 p-3 text-sm">
              <p className="text-[11px] text-fg-subtle">{n.author.full_name} · {formatDateTime(n.created_at)}{n.finding_id ? ' · on a finding' : ''}</p>
              <p className="mt-1 whitespace-pre-wrap">{n.body}</p>
            </div>
          ))
        ) : (
          <p className="text-xs text-fg-subtle">No notes yet.</p>
        )}
      </CardBody>
    </Card>
  )
}

export function InvestigationDetailPage() {
  const { id = '' } = useParams()
  const [params, setParams] = useSearchParams()
  const query = useQuery({ queryKey: ['investigation', id], queryFn: () => api.get<InvestigationDetail>(`/investigations/${id}`) })
  const tab = params.get('tab') ?? 'overview'
  if (query.isLoading) return <LoadingState />
  if (query.error) return <ErrorState error={query.error} onRetry={() => query.refetch()} />
  const inv = query.data!
  const writable = inv.my_access !== 'viewer'
  const findingTotal = Object.values(inv.finding_counts).reduce((a, b) => a + b, 0)
  const tabs = [
    { key: 'overview', label: 'Overview' },
    { key: 'evidence', label: 'Evidence', count: inv.evidence_count },
    { key: 'tools', label: 'Tools' },
    { key: 'runs', label: 'Runs', count: inv.run_count },
    { key: 'findings', label: 'Findings', count: findingTotal },
    { key: 'indicators', label: 'Indicators' },
    { key: 'risk', label: 'Risk' },
    { key: 'reports', label: 'Reports' },
    { key: 'timeline', label: 'Timeline' },
    { key: 'notes', label: 'Notes' },
  ]
  return (
    <>
      <p className="mb-2 text-xs text-fg-subtle">
        <Link to="/investigations" className="hover:text-fg">Investigations</Link> / <span className="font-mono">{inv.reference}</span>
      </p>
      <PageHeader
        title={inv.title}
        badge={<>{inv.is_demo ? <DemoBadge /> : null}<StatusBadge status={inv.status} /></>}
        description={`${inv.reference} · ${WORKSPACE_BY_KEY[inv.primary_workspace]?.label} · owned by ${inv.owner.full_name}`}
        actions={
          <Link to={`/assistant?investigation=${inv.id}`} className="inline-flex h-9 items-center rounded-md border border-line-strong bg-surface-3 px-4 text-sm hover:bg-line">
            Ask the AI assistant
          </Link>
        }
      />
      {!writable ? <div className="mb-4"><Alert tone="info">You have view-only access to this investigation.</Alert></div> : null}
      <Tabs items={tabs} active={tab} onChange={(key) => setParams({ tab: key })} />
      {tab === 'overview' ? <Overview inv={inv} writable={writable} /> : null}
      {tab === 'evidence' ? <Card><EvidencePanel investigationId={inv.id} writable={writable} /></Card> : null}
      {tab === 'tools' ? <ToolsCard investigationId={inv.id} writable={writable} /> : null}
      {tab === 'runs' ? <Card><CardHeader title="Tool runs" subtitle="Every requested run with its approval decision, arguments, timing and actual output." /><RunsTable investigationId={inv.id} initialRunId={params.get('run')} /></Card> : null}
      {tab === 'findings' ? <Card><FindingsTable investigationId={inv.id} /></Card> : null}
      {tab === 'indicators' ? <Card><CorrelationPanel investigationId={inv.id} /></Card> : null}
      {tab === 'risk' ? <Card><RiskPanel investigationId={inv.id} /></Card> : null}
      {tab === 'reports' ? <ReportsSection inv={inv} writable={writable} /> : null}
      {tab === 'timeline' ? <Card><CardBody><TimelineSection investigationId={inv.id} /></CardBody></Card> : null}
      {tab === 'notes' ? <NotesSection investigationId={inv.id} writable={writable} /> : null}
    </>
  )
}
