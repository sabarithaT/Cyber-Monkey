import { useMutation, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api, errorMessage } from '../../api/client'
import type { InvestigationDetail } from '../../api/models'
import type { WorkspaceKey } from '../../api/types'
import { useAuth } from '../../auth/AuthContext'
import { Button } from '../../components/ui/Button'
import { Field, Select, TextField, Textarea } from '../../components/ui/Form'
import { Modal } from '../../components/ui/Modal'
import { Alert } from '../../components/ui/States'
import { useToast } from '../../components/ui/Toast'
import { WORKSPACES } from '../../lib/workspaces'

export function CreateInvestigationModal({
  open,
  onClose,
  defaultWorkspace,
  navigateOnCreate = true,
  onCreated,
}: {
  open: boolean
  onClose: () => void
  defaultWorkspace?: WorkspaceKey
  navigateOnCreate?: boolean
  onCreated?: (inv: InvestigationDetail) => void
}) {
  const { user } = useAuth()
  const toast = useToast()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const allowed = WORKSPACES.filter((w) => user?.workspaces.includes(w.key))
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [workspace, setWorkspace] = useState<WorkspaceKey>(defaultWorkspace ?? allowed[0]?.key ?? 'soc')
  const create = useMutation({
    mutationFn: () => api.post<InvestigationDetail>('/investigations', { title, description, primary_workspace: workspace }),
    onSuccess: (inv) => {
      toast.success(`Created ${inv.reference}`)
      queryClient.invalidateQueries({ queryKey: ['investigations'] })
      setTitle('')
      setDescription('')
      onClose()
      onCreated?.(inv)
      if (navigateOnCreate) navigate(`/investigations/${inv.id}`)
    },
  })
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="New investigation"
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button variant="primary" loading={create.isPending} disabled={title.trim().length < 3} onClick={() => create.mutate()}>
            Create investigation
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        {create.isError ? <Alert tone="danger">{errorMessage(create.error)}</Alert> : null}
        <TextField label="Title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Lab web server assessment" />
        <Field label="Primary workspace" hint="Findings from every workspace can still be added to this investigation.">
          <Select value={workspace} onChange={(e) => setWorkspace(e.target.value as WorkspaceKey)}>
            {allowed.map((w) => (
              <option key={w.key} value={w.key}>{w.label}</option>
            ))}
          </Select>
        </Field>
        <Field label="Scope and description" hint="What is being investigated or assessed, and under what authorization.">
          <Textarea value={description} onChange={(e) => setDescription(e.target.value)} />
        </Field>
      </div>
    </Modal>
  )
}
