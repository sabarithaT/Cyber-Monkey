import { useQuery } from '@tanstack/react-query'
import { FolderPlus, FolderSearch } from 'lucide-react'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../../api/client'
import type { InvestigationSummary } from '../../api/models'
import type { Page } from '../../api/types'
import { useAuth } from '../../auth/AuthContext'
import { DemoBadge, StatusBadge } from '../../components/ui/Badge'
import { Button } from '../../components/ui/Button'
import { Card, CardHeader, PageHeader } from '../../components/ui/Card'
import { Checkbox, SearchInput, Select } from '../../components/ui/Form'
import { EmptyState } from '../../components/ui/States'
import { DataTable, Pagination } from '../../components/ui/Table'
import { formatRelative } from '../../lib/format'
import { useDebounced } from '../../lib/useDebounced'
import { WORKSPACE_BY_KEY, WORKSPACES } from '../../lib/workspaces'
import { CreateInvestigationModal } from './CreateInvestigationModal'

export function SeverityStrip({ counts }: { counts: InvestigationSummary['finding_counts'] }) {
  const order = ['critical', 'high', 'medium', 'low', 'info'] as const
  const colors = { critical: 'bg-sev-critical', high: 'bg-sev-high', medium: 'bg-sev-medium', low: 'bg-sev-low', info: 'bg-sev-info' }
  const total = order.reduce((n, s) => n + counts[s], 0)
  if (!total) return <span className="text-xs text-fg-subtle">No findings</span>
  return (
    <div className="flex items-center gap-2">
      <div className="flex h-2 w-24 overflow-hidden rounded bg-canvas" aria-hidden="true">
        {order.map((s) => (counts[s] ? <div key={s} className={colors[s]} style={{ width: `${(counts[s] / total) * 100}%` }} /> : null))}
      </div>
      <span className="text-xs tabular-nums text-fg-muted" title={order.map((s) => `${s}: ${counts[s]}`).join(', ')}>
        {counts.critical + counts.high > 0 ? `${counts.critical + counts.high} high+ / ` : ''}
        {total}
      </span>
    </div>
  )
}

export function InvestigationsPage() {
  const { can } = useAuth()
  const navigate = useNavigate()
  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [status, setStatus] = useState('')
  const [workspace, setWorkspace] = useState('')
  const [mine, setMine] = useState(false)
  const [creating, setCreating] = useState(false)
  const debounced = useDebounced(search)
  useEffect(() => {
    setPage(1)
  }, [debounced, status, workspace, mine])
  const query = useQuery({
    queryKey: ['investigations', page, debounced, status, workspace, mine],
    queryFn: () =>
      api.get<Page<InvestigationSummary>>('/investigations', { page, page_size: 20, search: debounced, status, workspace, mine }),
  })

  return (
    <>
      <PageHeader
        title="Investigations"
        description="Cases shared by every workspace. Each holds its authorized scope, evidence, tool runs, findings, risk scores and reports."
        actions={can('investigations:create') ? <Button variant="primary" icon={FolderPlus} onClick={() => setCreating(true)}>New investigation</Button> : null}
      />
      <Card>
        <CardHeader
          title="Cases you can access"
          actions={
            <>
              <SearchInput value={search} onChange={setSearch} placeholder="Search title or reference" />
              <Select value={status} onChange={(e) => setStatus(e.target.value)} className="h-8 w-auto text-xs" aria-label="Status">
                <option value="">Any status</option>
                <option value="open">Open</option>
                <option value="in_progress">In progress</option>
                <option value="closed">Closed</option>
              </Select>
              <Select value={workspace} onChange={(e) => setWorkspace(e.target.value)} className="h-8 w-auto text-xs" aria-label="Workspace">
                <option value="">All workspaces</option>
                {WORKSPACES.map((w) => (
                  <option key={w.key} value={w.key}>{w.label}</option>
                ))}
              </Select>
              <Checkbox label={<span className="text-xs">Owned by me</span>} checked={mine} onChange={(e) => setMine(e.target.checked)} />
            </>
          }
        />
        <DataTable
          rows={query.data?.items}
          loading={query.isLoading}
          error={query.error}
          onRetry={() => query.refetch()}
          rowKey={(i) => i.id}
          onRowClick={(i) => navigate(`/investigations/${i.id}`)}
          empty={
            <EmptyState
              icon={FolderSearch}
              title="No investigations"
              description="Create an investigation to start collecting evidence, running tools and correlating findings."
              action={can('investigations:create') ? <Button size="sm" variant="primary" onClick={() => setCreating(true)}>New investigation</Button> : undefined}
            />
          }
          columns={[
            {
              key: 'ref',
              header: 'Investigation',
              render: (i) => (
                <div>
                  <p className="font-medium">
                    {i.title} {i.is_demo ? <DemoBadge /> : null}
                  </p>
                  <p className="font-mono text-[11px] text-fg-subtle">{i.reference}</p>
                </div>
              ),
            },
            { key: 'ws', header: 'Workspace', render: (i) => <span className="text-xs">{WORKSPACE_BY_KEY[i.primary_workspace]?.label}</span> },
            { key: 'status', header: 'Status', render: (i) => <StatusBadge status={i.status} /> },
            { key: 'findings', header: 'Findings', render: (i) => <SeverityStrip counts={i.finding_counts} /> },
            { key: 'activity', header: 'Runs / evidence', render: (i) => <span className="text-xs tabular-nums text-fg-muted">{i.run_count} / {i.evidence_count}</span> },
            { key: 'owner', header: 'Owner', render: (i) => <span className="text-xs">{i.owner.full_name}</span> },
            { key: 'updated', header: 'Updated', render: (i) => <span className="whitespace-nowrap text-xs text-fg-muted">{formatRelative(i.updated_at)}</span> },
          ]}
        />
        {query.data ? <Pagination page={page} pageSize={query.data.page_size} total={query.data.total} onPage={setPage} /> : null}
      </Card>
      <CreateInvestigationModal open={creating} onClose={() => setCreating(false)} />
    </>
  )
}
