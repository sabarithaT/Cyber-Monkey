import { useSearchParams } from 'react-router-dom'
import { useAuth } from '../auth/AuthContext'
import { PageHeader } from '../components/ui/Card'
import { NoAccess } from '../components/ui/States'
import { Tabs } from '../components/ui/Tabs'
import { IntegrationsTab } from './admin/IntegrationsTab'
import { ProfileTab } from './admin/ProfileTab'
import { RolesTab } from './admin/RolesTab'
import { UsersTab } from './admin/UsersTab'

export function SettingsPage() {
  const { can } = useAuth()
  const [params, setParams] = useSearchParams()
  const tabs = [
    { key: 'profile', label: 'Profile' },
    ...(can('users:manage') ? [{ key: 'users', label: 'Users' }] : []),
    ...(can('roles:manage') ? [{ key: 'roles', label: 'Roles & permissions' }] : []),
    { key: 'integrations', label: 'Integrations' },
  ]
  const active = tabs.some((t) => t.key === params.get('tab')) ? params.get('tab')! : 'profile'

  return (
    <>
      <PageHeader title="Settings" description="Your account, user administration, roles and integration status." />
      <Tabs items={tabs} active={active} onChange={(key) => setParams({ tab: key })} />
      {active === 'profile' ? <ProfileTab /> : null}
      {active === 'users' ? (can('users:manage') ? <UsersTab /> : <NoAccess permission="users:manage" />) : null}
      {active === 'roles' ? <RolesTab /> : null}
      {active === 'integrations' ? <IntegrationsTab /> : null}
    </>
  )
}
