import { useMutation } from '@tanstack/react-query'
import { useState, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { api, errorMessage } from '../../api/client'
import { useAuth } from '../../auth/AuthContext'
import { Button } from '../../components/ui/Button'
import { Card, CardBody, CardHeader, KeyValue } from '../../components/ui/Card'
import { TextField } from '../../components/ui/Form'
import { Badge } from '../../components/ui/Badge'
import { Alert } from '../../components/ui/States'
import { formatDateTime } from '../../lib/format'

export function ProfileTab() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [current, setCurrent] = useState('')
  const [next, setNext] = useState('')
  const [confirm, setConfirm] = useState('')
  const mutation = useMutation({
    mutationFn: () => api.post('/auth/change-password', { current_password: current, new_password: next }),
    onSuccess: async () => {
      await logout()
      navigate('/login')
    },
  })
  if (!user) return null
  const mismatch = confirm.length > 0 && next !== confirm

  function onSubmit(event: FormEvent) {
    event.preventDefault()
    if (!mismatch) mutation.mutate()
  }

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card>
        <CardHeader title="Your account" />
        <CardBody>
          <KeyValue
            items={[
              ['Name', user.full_name],
              ['Email', user.email],
              ['Roles', user.roles.length ? user.roles.map((r) => <Badge key={r.id} className="mr-1">{r.name}</Badge>) : 'None'],
              ['Workspaces', user.workspaces.length ? user.workspaces.join(', ') : 'None'],
              ['Last sign-in', formatDateTime(user.last_login_at)],
              ['Permissions', <span className="font-mono text-xs text-fg-muted">{user.permissions.length} effective permissions</span>],
            ]}
          />
        </CardBody>
      </Card>
      <Card>
        <CardHeader title="Change password" subtitle="All of your sessions are signed out after a change." />
        <CardBody>
          <form className="space-y-4" onSubmit={onSubmit}>
            {mutation.isError ? <Alert tone="danger">{errorMessage(mutation.error)}</Alert> : null}
            <TextField label="Current password" type="password" autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} />
            <TextField
              label="New password"
              type="password"
              autoComplete="new-password"
              hint="At least 12 characters with three of: lowercase, uppercase, digit, symbol."
              value={next}
              onChange={(e) => setNext(e.target.value)}
            />
            <TextField
              label="Confirm new password"
              type="password"
              autoComplete="new-password"
              error={mismatch ? 'Passwords do not match' : undefined}
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
            />
            <Button type="submit" variant="primary" loading={mutation.isPending} disabled={!current || !next || mismatch}>
              Change password
            </Button>
          </form>
        </CardBody>
      </Card>
    </div>
  )
}
