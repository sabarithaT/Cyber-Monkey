import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Plus, Trash2 } from 'lucide-react'
import { useMemo, useState } from 'react'
import { api, errorMessage } from '../../api/client'
import type { Permission, Role } from '../../api/types'
import { useAuth } from '../../auth/AuthContext'
import { Badge } from '../../components/ui/Badge'
import { Button } from '../../components/ui/Button'
import { Card, CardBody, CardHeader } from '../../components/ui/Card'
import { TextField } from '../../components/ui/Form'
import { ConfirmDialog, Modal } from '../../components/ui/Modal'
import { Alert, ErrorState, LoadingState, NoAccess } from '../../components/ui/States'
import { useToast } from '../../components/ui/Toast'

const WORKSPACE_SCOPES = ['soc', 'pentest', 'osint', 'malware', 'forensics', 'network']
const ACTIONS = ['view', 'operate', 'execute']

function PermissionMatrix({
  permissions,
  selected,
  onChange,
  readOnly,
}: {
  permissions: Permission[]
  selected: Set<string>
  onChange: (next: Set<string>) => void
  readOnly?: boolean
}) {
  const platform = permissions.filter((p) => !WORKSPACE_SCOPES.includes(p.scope))
  const toggle = (code: string) => {
    const next = new Set(selected)
    if (next.has(code)) next.delete(code)
    else next.add(code)
    onChange(next)
  }
  return (
    <div className="space-y-4">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[28rem] text-sm">
          <thead>
            <tr className="text-[11px] uppercase tracking-wide text-fg-subtle">
              <th className="py-1.5 text-left font-medium">Workspace</th>
              {ACTIONS.map((a) => (
                <th key={a} className="py-1.5 text-center font-medium">{a}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {WORKSPACE_SCOPES.map((scope) => (
              <tr key={scope} className="border-t border-line/60">
                <td className="py-1.5 font-mono text-xs">{scope}</td>
                {ACTIONS.map((action) => {
                  const code = `${scope}:${action}`
                  return (
                    <td key={code} className="py-1.5 text-center">
                      <input
                        type="checkbox"
                        aria-label={code}
                        className="size-4 accent-teal-400"
                        disabled={readOnly}
                        checked={selected.has(code)}
                        onChange={() => toggle(code)}
                      />
                    </td>
                  )
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div>
        <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-fg-subtle">Platform permissions</p>
        <div className="grid gap-x-4 gap-y-1.5 sm:grid-cols-2">
          {platform.map((p) => (
            <label key={p.code} className="flex items-start gap-2 text-xs" title={p.description}>
              <input
                type="checkbox"
                className="mt-0.5 size-4 accent-teal-400"
                disabled={readOnly}
                checked={selected.has(p.code)}
                onChange={() => toggle(p.code)}
              />
              <span>
                <span className="font-mono text-fg">{p.code}</span>
                <span className="block text-fg-subtle">{p.description}</span>
              </span>
            </label>
          ))}
        </div>
      </div>
    </div>
  )
}

function RoleEditor({ role, permissions, onDone }: { role: Role | 'new'; permissions: Permission[]; onDone: () => void }) {
  const queryClient = useQueryClient()
  const toast = useToast()
  const isNew = role === 'new'
  const [name, setName] = useState(isNew ? '' : role.name)
  const [description, setDescription] = useState(isNew ? '' : role.description)
  const [selected, setSelected] = useState<Set<string>>(new Set(isNew ? [] : role.permissions))
  const [confirmDelete, setConfirmDelete] = useState(false)
  const lockedPermissions = !isNew && role.slug === 'administrator'

  const save = useMutation({
    mutationFn: () => {
      const body = { name, description, permission_codes: [...selected] }
      if (isNew) return api.post<Role>('/roles', body)
      return api.patch<Role>(`/roles/${role.id}`, lockedPermissions ? { name, description } : body)
    },
    onSuccess: () => {
      toast.success(isNew ? 'Role created' : 'Role updated; affected users must sign in again')
      queryClient.invalidateQueries({ queryKey: ['roles'] })
      onDone()
    },
  })
  const remove = useMutation({
    mutationFn: () => api.delete(`/roles/${(role as Role).id}`),
    onSuccess: () => {
      toast.success('Role deleted')
      queryClient.invalidateQueries({ queryKey: ['roles'] })
      onDone()
    },
    onError: (e) => toast.error(errorMessage(e)),
  })

  return (
    <Modal
      open
      wide
      onClose={onDone}
      title={isNew ? 'Create role' : `Edit role: ${role.name}`}
      footer={
        <>
          {!isNew && !role.is_system ? (
            <Button variant="ghost" icon={Trash2} className="mr-auto text-rose-300" onClick={() => setConfirmDelete(true)}>
              Delete role
            </Button>
          ) : null}
          <Button variant="ghost" onClick={onDone}>Cancel</Button>
          <Button variant="primary" loading={save.isPending} disabled={name.trim().length < 2} onClick={() => save.mutate()}>
            {isNew ? 'Create role' : 'Save changes'}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        {save.isError ? <Alert tone="danger">{errorMessage(save.error)}</Alert> : null}
        {lockedPermissions ? <Alert tone="info">The Administrator role always holds every permission.</Alert> : null}
        <div className="grid gap-4 sm:grid-cols-2">
          <TextField label="Name" value={name} onChange={(e) => setName(e.target.value)} />
          <TextField label="Description" value={description} onChange={(e) => setDescription(e.target.value)} />
        </div>
        <PermissionMatrix permissions={permissions} selected={selected} onChange={setSelected} readOnly={lockedPermissions} />
      </div>
      <ConfirmDialog
        open={confirmDelete}
        title="Delete role?"
        tone="danger"
        confirmLabel="Delete role"
        loading={remove.isPending}
        onCancel={() => setConfirmDelete(false)}
        onConfirm={() => remove.mutate()}
      >
        <p>This permanently deletes the role. Roles that are still assigned to users cannot be deleted.</p>
      </ConfirmDialog>
    </Modal>
  )
}

export function RolesTab() {
  const { can } = useAuth()
  const [editing, setEditing] = useState<Role | 'new' | null>(null)
  const roles = useQuery({ queryKey: ['roles'], queryFn: () => api.get<Role[]>('/roles') })
  const permissions = useQuery({
    queryKey: ['permissions'],
    queryFn: () => api.get<Permission[]>('/permissions'),
    enabled: can('roles:manage'),
  })
  const sorted = useMemo(() => [...(roles.data ?? [])].sort((a, b) => Number(b.is_system) - Number(a.is_system)), [roles.data])

  if (!can('roles:manage')) return <NoAccess permission="roles:manage" />
  if (roles.isLoading || permissions.isLoading) return <LoadingState />
  if (roles.error || permissions.error) return <ErrorState error={roles.error ?? permissions.error} onRetry={() => { roles.refetch(); permissions.refetch() }} />

  return (
    <>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <p className="max-w-2xl text-sm text-fg-muted">
          A role is a named bundle of permissions. Workspace permissions (view, operate, execute) decide which workspaces and
          actions a user can access; platform permissions cover cross-cutting features. Every check is enforced by the
          backend.
        </p>
        <Button variant="primary" size="sm" icon={Plus} onClick={() => setEditing('new')}>New role</Button>
      </div>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {sorted.map((role) => (
          <Card key={role.id}>
            <CardHeader
              title={role.name}
              subtitle={role.description}
              actions={
                <>
                  {role.is_system ? <Badge>System</Badge> : <Badge tone="accent">Custom</Badge>}
                  <Button size="sm" onClick={() => setEditing(role)}>Edit</Button>
                </>
              }
            />
            <CardBody className="space-y-2 text-xs text-fg-muted">
              <p>
                <span className="tabular-nums text-fg">{role.permissions.length}</span> permissions ·{' '}
                <span className="tabular-nums text-fg">{role.user_count}</span> users
              </p>
              <div className="flex flex-wrap gap-1">
                {WORKSPACE_SCOPES.filter((ws) => role.permissions.some((p) => p.startsWith(`${ws}:`))).map((ws) => (
                  <Badge key={ws} tone="info">{ws}</Badge>
                ))}
              </div>
            </CardBody>
          </Card>
        ))}
      </div>
      {editing ? <RoleEditor role={editing} permissions={permissions.data ?? []} onDone={() => setEditing(null)} /> : null}
    </>
  )
}
