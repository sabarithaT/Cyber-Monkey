import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { KeyRound, UserPlus } from 'lucide-react'
import { useEffect, useState } from 'react'
import { api, errorMessage } from '../../api/client'
import type { Page, Permission, Role, User } from '../../api/types'
import { useAuth } from '../../auth/AuthContext'
import { Badge, StatusBadge } from '../../components/ui/Badge'
import { Button } from '../../components/ui/Button'
import { Card, CardHeader } from '../../components/ui/Card'
import { Checkbox, SearchInput, TextField } from '../../components/ui/Form'
import { Modal } from '../../components/ui/Modal'
import { Alert } from '../../components/ui/States'
import { DataTable, Pagination } from '../../components/ui/Table'
import { useToast } from '../../components/ui/Toast'
import { formatDateTime } from '../../lib/format'
import { useDebounced } from '../../lib/useDebounced'

function RoleChecklist({ roles, selected, onChange }: { roles: Role[]; selected: number[]; onChange: (ids: number[]) => void }) {
  return (
    <div className="grid gap-2 sm:grid-cols-2">
      {roles.map((role) => (
        <Checkbox
          key={role.id}
          label={role.name}
          description={role.description}
          checked={selected.includes(role.id)}
          onChange={(e) => onChange(e.target.checked ? [...selected, role.id] : selected.filter((id) => id !== role.id))}
        />
      ))}
    </div>
  )
}

function CreateUserModal({ open, onClose, roles }: { open: boolean; onClose: () => void; roles: Role[] }) {
  const queryClient = useQueryClient()
  const toast = useToast()
  const [form, setForm] = useState({ email: '', full_name: '', password: '' })
  const [roleIds, setRoleIds] = useState<number[]>([])
  const mutation = useMutation({
    mutationFn: () => api.post<User>('/users', { ...form, role_ids: roleIds }),
    onSuccess: (user) => {
      toast.success(`User ${user.email} created`)
      queryClient.invalidateQueries({ queryKey: ['users'] })
      setForm({ email: '', full_name: '', password: '' })
      setRoleIds([])
      onClose()
    },
  })
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Create user"
      wide
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button variant="primary" loading={mutation.isPending} onClick={() => mutation.mutate()} disabled={!form.email || !form.full_name || !form.password}>
            Create user
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        {mutation.isError ? <Alert tone="danger">{errorMessage(mutation.error)}</Alert> : null}
        <div className="grid gap-4 sm:grid-cols-2">
          <TextField label="Full name" value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} />
          <TextField label="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        </div>
        <TextField
          label="Initial password"
          type="password"
          autoComplete="new-password"
          hint="At least 12 characters with three of: lowercase, uppercase, digit, symbol. Share it with the user through a secure channel."
          value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
        />
        <div>
          <p className="mb-2 text-xs font-medium text-fg-muted">Roles</p>
          <RoleChecklist roles={roles} selected={roleIds} onChange={setRoleIds} />
        </div>
      </div>
    </Modal>
  )
}

function EditUserModal({ user, onClose, roles, permissions }: { user: User | null; onClose: () => void; roles: Role[]; permissions: Permission[] }) {
  const queryClient = useQueryClient()
  const toast = useToast()
  const { user: me } = useAuth()
  const [roleIds, setRoleIds] = useState<number[]>([])
  const [direct, setDirect] = useState<string[]>([])
  const [newPassword, setNewPassword] = useState('')

  useEffect(() => {
    if (user) {
      setRoleIds(user.roles.map((r) => r.id))
      setDirect(user.direct_permissions)
      setNewPassword('')
    }
  }, [user])

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['users'] })
  const saveRoles = useMutation({
    mutationFn: () => api.put<User>(`/users/${user!.id}/roles`, { role_ids: roleIds }),
    onSuccess: () => { toast.success('Roles updated; the user must sign in again'); invalidate() },
    onError: (e) => toast.error(errorMessage(e)),
  })
  const savePerms = useMutation({
    mutationFn: () => api.put<User>(`/users/${user!.id}/permissions`, { permission_codes: direct }),
    onSuccess: () => { toast.success('Direct permissions updated'); invalidate() },
    onError: (e) => toast.error(errorMessage(e)),
  })
  const toggleActive = useMutation({
    mutationFn: () => api.patch<User>(`/users/${user!.id}`, { is_active: !user!.is_active }),
    onSuccess: (u) => { toast.success(u.is_active ? 'User activated' : 'User deactivated'); invalidate(); onClose() },
    onError: (e) => toast.error(errorMessage(e)),
  })
  const resetPassword = useMutation({
    mutationFn: () => api.post(`/users/${user!.id}/reset-password`, { new_password: newPassword }),
    onSuccess: () => { toast.success('Password reset'); setNewPassword('') },
    onError: (e) => toast.error(errorMessage(e)),
  })

  if (!user) return null
  const isSelf = me?.id === user.id
  const scopes = Array.from(new Set(permissions.map((p) => p.scope)))

  return (
    <Modal open={!!user} onClose={onClose} title={`Manage ${user.full_name}`} wide>
      <div className="space-y-6">
        <section>
          <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-fg-subtle">Roles</h3>
          <RoleChecklist roles={roles} selected={roleIds} onChange={setRoleIds} />
          <Button className="mt-3" size="sm" variant="primary" loading={saveRoles.isPending} onClick={() => saveRoles.mutate()}>
            Save roles
          </Button>
        </section>
        <section>
          <h3 className="mb-1 text-xs font-semibold uppercase tracking-wide text-fg-subtle">Direct permissions</h3>
          <p className="mb-3 text-xs text-fg-muted">Granted in addition to the user's roles. Use sparingly; prefer roles.</p>
          <div className="max-h-64 space-y-3 overflow-y-auto rounded-md border border-line p-3">
            {scopes.map((scope) => (
              <div key={scope}>
                <p className="mb-1 font-mono text-[11px] text-fg-subtle">{scope}</p>
                <div className="grid gap-1.5 sm:grid-cols-3">
                  {permissions.filter((p) => p.scope === scope).map((p) => (
                    <Checkbox
                      key={p.code}
                      label={<span className="font-mono text-xs">{p.action}</span>}
                      title={p.description}
                      checked={direct.includes(p.code)}
                      onChange={(e) => setDirect(e.target.checked ? [...direct, p.code] : direct.filter((c) => c !== p.code))}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
          <Button className="mt-3" size="sm" variant="primary" loading={savePerms.isPending} onClick={() => savePerms.mutate()}>
            Save direct permissions
          </Button>
        </section>
        <section className="grid gap-4 sm:grid-cols-2">
          <div>
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-fg-subtle">Reset password</h3>
            <TextField label="New password" type="password" autoComplete="new-password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
            <Button className="mt-3" size="sm" icon={KeyRound} loading={resetPassword.isPending} disabled={!newPassword} onClick={() => resetPassword.mutate()}>
              Reset password
            </Button>
          </div>
          <div>
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-fg-subtle">Account status</h3>
            <p className="mb-3 text-xs text-fg-muted">
              {isSelf ? 'You cannot deactivate your own account.' : 'Deactivated users cannot sign in and existing sessions stop working.'}
            </p>
            <Button size="sm" variant={user.is_active ? 'danger' : 'primary'} disabled={isSelf} loading={toggleActive.isPending} onClick={() => toggleActive.mutate()}>
              {user.is_active ? 'Deactivate user' : 'Activate user'}
            </Button>
          </div>
        </section>
      </div>
    </Modal>
  )
}

export function UsersTab() {
  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const debounced = useDebounced(search)
  const [creating, setCreating] = useState(false)
  const [editing, setEditing] = useState<User | null>(null)
  const { can } = useAuth()

  useEffect(() => {
    setPage(1)
  }, [debounced])

  const users = useQuery({ queryKey: ['users', page, debounced], queryFn: () => api.get<Page<User>>('/users', { page, page_size: 20, search: debounced }) })
  const roles = useQuery({ queryKey: ['roles'], queryFn: () => api.get<Role[]>('/roles') })
  const permissions = useQuery({ queryKey: ['permissions'], queryFn: () => api.get<Permission[]>('/permissions'), enabled: can('roles:manage') })

  return (
    <Card>
      <CardHeader
        title="Users"
        subtitle="Accounts, their roles and direct permission grants."
        actions={
          <>
            <SearchInput value={search} onChange={setSearch} placeholder="Search name or email" />
            <Button size="sm" variant="primary" icon={UserPlus} onClick={() => setCreating(true)}>New user</Button>
          </>
        }
      />
      <DataTable
        rows={users.data?.items}
        loading={users.isLoading}
        error={users.error}
        onRetry={() => users.refetch()}
        rowKey={(u) => u.id}
        onRowClick={(u) => setEditing(u)}
        columns={[
          { key: 'name', header: 'User', render: (u) => (<div><p className="font-medium">{u.full_name}</p><p className="text-xs text-fg-muted">{u.email}</p></div>) },
          { key: 'roles', header: 'Roles', render: (u) => (<div className="flex flex-wrap gap-1">{u.roles.length ? u.roles.map((r) => <Badge key={r.id}>{r.name}</Badge>) : <span className="text-xs text-fg-subtle">None</span>}</div>) },
          { key: 'direct', header: 'Direct grants', render: (u) => <span className="text-xs tabular-nums text-fg-muted">{u.direct_permissions.length}</span> },
          { key: 'status', header: 'Status', render: (u) => <StatusBadge status={u.is_active ? 'available' : 'disabled'} label={u.is_active ? 'Active' : 'Inactive'} /> },
          { key: 'last', header: 'Last sign-in', render: (u) => <span className="text-xs text-fg-muted">{formatDateTime(u.last_login_at)}</span> },
        ]}
      />
      {users.data ? <Pagination page={page} pageSize={users.data.page_size} total={users.data.total} onPage={setPage} /> : null}
      <CreateUserModal open={creating} onClose={() => setCreating(false)} roles={roles.data ?? []} />
      <EditUserModal user={editing} onClose={() => setEditing(null)} roles={roles.data ?? []} permissions={permissions.data ?? []} />
    </Card>
  )
}
