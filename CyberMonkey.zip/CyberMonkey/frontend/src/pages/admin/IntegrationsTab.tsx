import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { api, errorMessage } from '../../api/client'
import { useAuth } from '../../auth/AuthContext'
import { Badge, StatusBadge } from '../../components/ui/Badge'
import { Button } from '../../components/ui/Button'
import { Card, CardHeader } from '../../components/ui/Card'
import { ErrorState, LoadingState } from '../../components/ui/States'
import { useToast } from '../../components/ui/Toast'

export interface Integration {
  key: string
  label: string
  category: string
  description: string
  configure: string
  enabled: boolean
  available: boolean
  status: string
  detail: string
  secret_env_var: string | null
}

const CATEGORY_LABELS: Record<string, string> = {
  tool: 'Security tools',
  intel: 'Threat intelligence',
  osint: 'OSINT sources',
  ai: 'AI providers',
  sandbox: 'Malware sandbox',
}

export function IntegrationsTab() {
  const { can } = useAuth()
  const toast = useToast()
  const queryClient = useQueryClient()
  const query = useQuery({ queryKey: ['integrations'], queryFn: () => api.get<Integration[]>('/integrations') })
  const toggle = useMutation({
    mutationFn: (item: Integration) => api.patch<Integration>(`/integrations/${item.key}`, { enabled: !item.enabled }),
    onSuccess: (item) => {
      toast.success(`${item.label} ${item.enabled ? 'enabled' : 'disabled'}`)
      queryClient.invalidateQueries({ queryKey: ['integrations'] })
    },
    onError: (e) => toast.error(errorMessage(e)),
  })

  if (query.isLoading) return <LoadingState />
  if (query.error) return <ErrorState error={query.error} onRetry={() => query.refetch()} />
  const groups = Object.keys(CATEGORY_LABELS)

  return (
    <div className="space-y-6">
      <p className="max-w-3xl text-sm text-fg-muted">
        Status is checked live. Secrets (API keys, tokens) are read only from environment variables on the server and are
        never stored in the database or shown here. An unavailable integration is reported as such; Cyber Monkey never
        simulates its output.
      </p>
      {groups.map((group) => {
        const items = query.data!.filter((i) => i.category === group)
        if (!items.length) return null
        return (
          <Card key={group}>
            <CardHeader title={CATEGORY_LABELS[group]} />
            <ul className="divide-y divide-line/60">
              {items.map((item) => (
                <li key={item.key} className="flex flex-wrap items-start gap-4 px-4 py-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-medium">{item.label}</p>
                      <StatusBadge status={item.status} />
                      {item.secret_env_var ? <Badge className="font-mono">{item.secret_env_var}</Badge> : null}
                    </div>
                    <p className="mt-0.5 text-xs text-fg-muted">{item.description}</p>
                    <p className="mt-1 text-xs text-fg-subtle">{item.detail}</p>
                    {!item.available && item.status !== 'disabled' ? (
                      <p className="mt-1 text-xs text-fg-subtle">
                        <span className="text-fg-muted">How to configure:</span> {item.configure}
                      </p>
                    ) : null}
                  </div>
                  {can('integrations:manage') ? (
                    <Button size="sm" variant="ghost" loading={toggle.isPending && toggle.variables?.key === item.key} onClick={() => toggle.mutate(item)}>
                      {item.enabled ? 'Disable' : 'Enable'}
                    </Button>
                  ) : null}
                </li>
              ))}
            </ul>
          </Card>
        )
      })}
    </div>
  )
}
