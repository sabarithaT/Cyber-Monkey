import { useQuery } from '@tanstack/react-query'
import { ExternalLink, Radar } from 'lucide-react'
import { useEffect, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { api } from '../api/client'
import type { IndicatorDetail, IndicatorRow, ReferenceRow } from '../api/models'
import type { Page } from '../api/types'
import { Badge, SeverityBadge } from '../components/ui/Badge'
import { Card, CardHeader, KeyValue, PageHeader } from '../components/ui/Card'
import { Checkbox, SearchInput, Select } from '../components/ui/Form'
import { Modal } from '../components/ui/Modal'
import { EmptyState, LoadingState } from '../components/ui/States'
import { DataTable, Pagination } from '../components/ui/Table'
import { Tabs } from '../components/ui/Tabs'
import { formatDateTime, formatRelative } from '../lib/format'
import { useDebounced } from '../lib/useDebounced'

function IndicatorModal({ id, onClose }: { id: string | null; onClose: () => void }) {
  const query = useQuery({ queryKey: ['ioc', id], queryFn: () => api.get<IndicatorDetail>(`/threat-intelligence/iocs/${id}`), enabled: !!id })
  const ioc = query.data
  return (
    <Modal open={!!id} onClose={onClose} title={ioc ? `${ioc.type}: ${ioc.value}` : 'Indicator'} wide>
      {query.isLoading ? <LoadingState /> : ioc ? (
        <div className="space-y-4">
          <KeyValue
            items={[
              ['Scope', ioc.is_internal ? 'Internal / private (never sent to external reputation services)' : 'External'],
              ['First seen', formatDateTime(ioc.first_seen)],
              ['Last seen', formatDateTime(ioc.last_seen)],
              ['Seen in', `${ioc.finding_count} finding(s), ${ioc.investigation_count} investigation(s), workspaces: ${ioc.workspaces.join(', ')}`],
              ['Reputation', Object.keys(ioc.reputation).length ? JSON.stringify(ioc.reputation) : 'No external reputation lookup recorded'],
            ]}
          />
          <p className="text-xs text-fg-subtle">Appearing in several places makes an indicator worth prioritizing, not proven malicious.</p>
          <ul className="divide-y divide-line/60 rounded-md border border-line">
            {ioc.findings.map((f) => (
              <li key={f.id} className="flex flex-wrap items-center gap-2 px-3 py-2 text-sm">
                <SeverityBadge severity={f.severity} />
                <Link to={`/investigations/${f.investigation_id}?tab=findings`} className="hover:text-accent">{f.title}</Link>
                <span className="text-xs text-fg-subtle">{f.investigation_reference} · {f.workspace} · {f.source_tool}</span>
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </Modal>
  )
}

function IndicatorsTab() {
  const [page, setPage] = useState(1)
  const [type, setType] = useState('')
  const [search, setSearch] = useState('')
  const [correlated, setCorrelated] = useState(false)
  const [selected, setSelected] = useState<string | null>(null)
  const debounced = useDebounced(search)
  useEffect(() => {
    setPage(1)
  }, [type, debounced, correlated])
  const query = useQuery({
    queryKey: ['iocs', page, type, debounced, correlated],
    queryFn: () => api.get<Page<IndicatorRow>>('/threat-intelligence/iocs', { page, page_size: 25, type, search: debounced, correlated_only: correlated }),
  })
  return (
    <Card>
      <CardHeader
        title="Indicators of compromise"
        subtitle="Normalized indicators extracted from findings you can access."
        actions={
          <>
            <SearchInput value={search} onChange={setSearch} placeholder="Search indicator value" />
            <Select value={type} onChange={(e) => setType(e.target.value)} className="h-8 w-auto text-xs" aria-label="Indicator type">
              <option value="">All types</option>
              {['ipv4', 'ipv6', 'domain', 'url', 'email', 'md5', 'sha1', 'sha256'].map((t) => <option key={t} value={t}>{t}</option>)}
            </Select>
            <Checkbox label={<span className="text-xs">Correlated only</span>} checked={correlated} onChange={(e) => setCorrelated(e.target.checked)} />
          </>
        }
      />
      <DataTable
        rows={query.data?.items}
        loading={query.isLoading}
        error={query.error}
        onRetry={() => query.refetch()}
        rowKey={(i) => i.id}
        onRowClick={(i) => setSelected(i.id)}
        empty={<EmptyState icon={Radar} title="No indicators" description="Indicators appear as tools and imports produce findings." />}
        columns={[
          { key: 'v', header: 'Indicator', render: (i) => <span className="font-mono text-xs">{i.value}</span> },
          { key: 't', header: 'Type', render: (i) => <Badge>{i.type}</Badge> },
          { key: 's', header: 'Scope', render: (i) => (i.is_internal ? <Badge>internal</Badge> : <Badge tone="info">external</Badge>) },
          { key: 'ws', header: 'Workspaces', render: (i) => <span className="text-xs">{i.workspaces.join(', ')}</span> },
          {
            key: 'n',
            header: 'Sightings',
            render: (i) => (
              <span className={`text-xs tabular-nums ${i.investigation_count > 1 || i.workspaces.length > 1 ? 'text-amber-200' : ''}`}>
                {i.finding_count} findings · {i.investigation_count} cases
              </span>
            ),
          },
          { key: 'l', header: 'Last seen', render: (i) => <span className="text-xs text-fg-muted">{formatRelative(i.last_seen)}</span> },
        ]}
      />
      {query.data ? <Pagination page={page} pageSize={query.data.page_size} total={query.data.total} onPage={setPage} /> : null}
      <IndicatorModal id={selected} onClose={() => setSelected(null)} />
    </Card>
  )
}

function ReferencesTab({ refType }: { refType: 'cve' | 'attack_technique' }) {
  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const debounced = useDebounced(search)
  useEffect(() => {
    setPage(1)
  }, [debounced, refType])
  const query = useQuery({
    queryKey: ['references', refType, page, debounced],
    queryFn: () => api.get<Page<ReferenceRow>>('/threat-intelligence/references', { ref_type: refType, page, page_size: 25, search: debounced }),
  })
  return (
    <Card>
      <CardHeader
        title={refType === 'cve' ? 'CVE references' : 'MITRE ATT&CK techniques'}
        subtitle={
          refType === 'cve'
            ? 'CVE identifiers named in evidence. CVSS scores come from NVD enrichment; unenriched entries have no score.'
            : 'Techniques mapped from findings, from the local ATT&CK catalogue.'
        }
        actions={<SearchInput value={search} onChange={setSearch} placeholder="Search ID or title" />}
      />
      <DataTable
        rows={query.data?.items}
        loading={query.isLoading}
        error={query.error}
        onRetry={() => query.refetch()}
        rowKey={(r) => r.id}
        empty={<EmptyState title="No references yet" />}
        columns={[
          {
            key: 'id',
            header: 'ID',
            render: (r) => (
              <a href={r.url} target="_blank" rel="noreferrer noopener" className="inline-flex items-center gap-1 font-mono text-xs text-accent hover:underline">
                {r.external_id} <ExternalLink className="size-3" />
              </a>
            ),
          },
          { key: 't', header: 'Title', render: (r) => <span className="text-xs">{r.title !== r.external_id ? r.title : <span className="text-fg-subtle">—</span>}</span> },
          ...(refType === 'cve'
            ? [
                { key: 'cvss', header: 'CVSS', render: (r: ReferenceRow) => (r.cvss_score !== null ? <span className="tabular-nums">{r.cvss_score}</span> : <span className="text-xs text-fg-subtle">not enriched</span>) },
                { key: 'sev', header: 'NVD severity', render: (r: ReferenceRow) => <span className="text-xs">{r.severity ?? '—'}</span> },
              ]
            : [{ key: 'tac', header: 'Tactics', render: (r: ReferenceRow) => <span className="text-xs">{((r.data.tactic_names as string[]) ?? []).join(', ')}</span> }]),
          { key: 'src', header: 'Source', render: (r) => <Badge>{r.source}</Badge> },
          { key: 'f', header: 'Findings', render: (r) => <span className="text-xs tabular-nums">{r.finding_count}</span> },
        ]}
      />
      {query.data ? <Pagination page={page} pageSize={query.data.page_size} total={query.data.total} onPage={setPage} /> : null}
    </Card>
  )
}

function AttackCatalogTab() {
  const [q, setQ] = useState('')
  const debounced = useDebounced(q)
  const query = useQuery({
    queryKey: ['attack-catalog', debounced],
    queryFn: () => api.get<{ source: string; total: number; items: { id: string; name: string; tactics: string[]; url: string }[] }>('/threat-intelligence/attack/techniques', { q: debounced }),
  })
  return (
    <Card>
      <CardHeader
        title="ATT&CK catalogue"
        subtitle={query.data ? `Source: ${query.data.source} · ${query.data.total} matching technique(s)` : undefined}
        actions={<SearchInput value={q} onChange={setQ} placeholder="Search techniques" />}
      />
      <DataTable
        rows={query.data?.items}
        loading={query.isLoading}
        error={query.error}
        rowKey={(t) => t.id}
        dense
        columns={[
          { key: 'id', header: 'ID', render: (t) => <a href={t.url} target="_blank" rel="noreferrer noopener" className="font-mono text-xs text-accent hover:underline">{t.id}</a> },
          { key: 'n', header: 'Technique', render: (t) => <span className="text-sm">{t.name}</span> },
          { key: 't', header: 'Tactics', render: (t) => <span className="text-xs text-fg-muted">{t.tactics.join(', ')}</span> },
        ]}
      />
    </Card>
  )
}

export function ThreatIntelPage() {
  const [params, setParams] = useSearchParams()
  const tab = params.get('tab') ?? 'iocs'
  return (
    <>
      <PageHeader
        title="Threat Intelligence"
        description="The shared engine that normalizes indicators from every workspace, correlates them across workspaces and investigations, attaches CVE and ATT&CK references with their validation state, and feeds the risk score."
      />
      <Tabs
        items={[
          { key: 'iocs', label: 'Indicators' },
          { key: 'cve', label: 'CVE references' },
          { key: 'attack', label: 'ATT&CK mappings' },
          { key: 'catalog', label: 'ATT&CK catalogue' },
        ]}
        active={tab}
        onChange={(key) => setParams({ tab: key })}
      />
      {tab === 'iocs' ? <IndicatorsTab /> : null}
      {tab === 'cve' ? <ReferencesTab refType="cve" /> : null}
      {tab === 'attack' ? <ReferencesTab refType="attack_technique" /> : null}
      {tab === 'catalog' ? <AttackCatalogTab /> : null}
    </>
  )
}
