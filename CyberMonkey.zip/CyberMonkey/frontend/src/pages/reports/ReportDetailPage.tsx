import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { CheckCircle2, Download, RefreshCw, Send, Undo2 } from 'lucide-react'
import { useEffect, useState, type ReactNode } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { api, downloadFile, errorMessage } from '../../api/client'
import type { ReportDetail } from '../../api/models'
import { useAuth } from '../../auth/AuthContext'
import { FindingDetail } from '../../components/FindingDetail'
import { Badge, DemoBadge, SeverityBadge, StatusBadge } from '../../components/ui/Badge'
import { Button } from '../../components/ui/Button'
import { Card, CardBody, CardHeader, KeyValue, PageHeader } from '../../components/ui/Card'
import { Textarea } from '../../components/ui/Form'
import { Modal } from '../../components/ui/Modal'
import { Alert, ErrorState, LoadingState } from '../../components/ui/States'
import { useToast } from '../../components/ui/Toast'
import { formatDateTime } from '../../lib/format'

function Cited({ text, onCite, cites }: { text: string; onCite: (cite: string) => void; cites: Set<string> }) {
  const parts = text.split(/(\[?F-[0-9a-f]{8}\]?)/g)
  return (
    <p className="whitespace-pre-wrap text-sm leading-relaxed">
      {parts.map((part, i) => {
        const cite = part.replace(/[[\]]/g, '')
        if (/^F-[0-9a-f]{8}$/.test(cite)) {
          return cites.has(cite) ? (
            <button key={i} type="button" onClick={() => onCite(cite)} className="mx-0.5 rounded bg-accent-soft px-1 font-mono text-xs text-accent hover:underline">{cite}</button>
          ) : (
            <span key={i} className="mx-0.5 rounded bg-rose-500/15 px-1 font-mono text-xs text-rose-300" title="Not a finding in this report">{cite}</span>
          )
        }
        return <span key={i}>{part}</span>
      })}
    </p>
  )
}

function Section({ number, title, children }: { number: number; title: string; children: ReactNode }) {
  return (
    <Card>
      <CardHeader title={`${number}. ${title}`} />
      <CardBody className="space-y-4">{children}</CardBody>
    </Card>
  )
}

export function ReportDetailPage() {
  const { id = '' } = useParams()
  const { user, can } = useAuth()
  const toast = useToast()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const [notes, setNotes] = useState('')
  const [deciding, setDeciding] = useState<'approve' | 'request-changes' | null>(null)
  const [comment, setComment] = useState('')
  const [finding, setFinding] = useState<string | null>(null)
  const query = useQuery({ queryKey: ['report', id], queryFn: () => api.get<ReportDetail>(`/reports/${id}`) })
  useEffect(() => {
    setNotes(query.data?.analyst_notes ?? '')
  }, [query.data?.analyst_notes])
  const refresh = (data: ReportDetail) => {
    queryClient.setQueryData(['report', data.id], data)
    queryClient.invalidateQueries({ queryKey: ['reports'] })
    queryClient.invalidateQueries({ queryKey: ['notifications'] })
  }
  const save = useMutation({ mutationFn: () => api.patch<ReportDetail>(`/reports/${id}`, { analyst_notes: notes }), onSuccess: (d) => { refresh(d); toast.success('Notes saved') }, onError: (e) => toast.error(errorMessage(e)) })
  const submit = useMutation({ mutationFn: () => api.post<ReportDetail>(`/reports/${id}/submit`), onSuccess: (d) => { refresh(d); toast.success('Submitted for review') }, onError: (e) => toast.error(errorMessage(e)) })
  const decide = useMutation({
    mutationFn: () => api.post<ReportDetail>(`/reports/${id}/${deciding}`, { comment }),
    onSuccess: (d) => {
      refresh(d)
      setDeciding(null)
      setComment('')
      toast.success(d.status === 'approved' ? 'Report approved' : 'Changes requested')
    },
  })
  const regenerate = useMutation({
    mutationFn: () => api.post<ReportDetail>(`/reports/${id}/regenerate`),
    onSuccess: (d) => {
      queryClient.invalidateQueries({ queryKey: ['reports'] })
      toast.success(`Version ${d.version} generated from current data`)
      navigate(`/reports/${d.id}`)
    },
    onError: (e) => toast.error(errorMessage(e)),
  })

  if (query.isLoading) return <LoadingState />
  if (query.error) return <ErrorState error={query.error} onRetry={() => query.refetch()} />
  const r = query.data!
  const c = r.content
  const n = r.narrative
  const cites = new Set(c.findings.map((f) => f.cite))
  const openCite = (cite: string) => setFinding(c.findings.find((f) => f.cite === cite)?.id ?? null)
  const editable = r.status === 'draft' || r.status === 'changes_requested'
  const canReview = can('reports:review') && r.status === 'in_review' && r.generated_by.id !== user?.id

  return (
    <>
      <p className="mb-2 text-xs text-fg-subtle">
        <Link to="/reports" className="hover:text-fg">Reports</Link> / <Link to={`/investigations/${r.investigation_id}?tab=reports`} className="font-mono hover:text-fg">{r.investigation_reference}</Link> / v{r.version}
      </p>
      <PageHeader
        title={r.title}
        badge={<>{r.is_demo ? <DemoBadge /> : null}<StatusBadge status={r.status} /><Badge tone={r.generation_mode === 'llm' ? 'violet' : 'neutral'}>{r.generation_mode === 'llm' ? `LLM narrative · ${r.llm_provider} ${r.llm_model}` : 'Template narrative (no LLM)'}</Badge></>}
        description={`Generated ${formatDateTime(c.generated_at)} by ${c.generated_by}. Structured content is built from the database; the narrative is written from it and checked for citations.`}
        actions={
          <>
            <Button icon={Download} onClick={() => downloadFile(`/reports/${r.id}/pdf`, `${r.investigation_reference}-v${r.version}.pdf`).catch((e) => toast.error(errorMessage(e)))}>Export PDF</Button>
            {can('reports:generate') ? <Button icon={RefreshCw} loading={regenerate.isPending} onClick={() => regenerate.mutate()}>Regenerate</Button> : null}
            {editable ? <Button variant="primary" icon={Send} loading={submit.isPending} onClick={() => submit.mutate()}>Submit for review</Button> : null}
            {canReview ? (
              <>
                <Button variant="ghost" icon={Undo2} onClick={() => setDeciding('request-changes')}>Request changes</Button>
                <Button variant="primary" icon={CheckCircle2} onClick={() => setDeciding('approve')}>Approve</Button>
              </>
            ) : null}
          </>
        }
      />
      <div className="mb-6 space-y-2">
        {r.status !== 'approved' ? <Alert tone="warning">This report has not been approved by a reviewer. Exported PDFs carry a DRAFT watermark.</Alert> : null}
        {r.status === 'in_review' && r.generated_by.id === user?.id ? <Alert tone="info">Waiting for a reviewer other than you (segregation of duties).</Alert> : null}
        {r.review_comment ? <Alert tone={r.status === 'approved' ? 'success' : 'warning'} title={`Reviewer comment (${r.reviewed_by?.email ?? ''})`}>{r.review_comment}</Alert> : null}
        {n.citation_issues.length ? <Alert tone="danger" title="Citation check found problems">{n.citation_issues.join('; ')}</Alert> : null}
        {n.llm_error ? <Alert tone="info">The LLM narrative failed ({n.llm_error}); the deterministic template was used instead.</Alert> : null}
      </div>
      <div className="space-y-6">
        <Section number={1} title="Executive Summary">
          <Cited text={n.executive_summary} cites={cites} onCite={openCite} />
        </Section>
        <Section number={2} title="Technical Findings">
          <Cited text={n.technical_findings} cites={cites} onCite={openCite} />
          {c.findings.length ? (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[40rem] text-left text-sm">
                <thead className="text-[11px] uppercase tracking-wide text-fg-subtle">
                  <tr className="border-b border-line"><th className="py-2 pr-3">ID</th><th className="py-2 pr-3">Severity</th><th className="py-2 pr-3">Finding</th><th className="py-2 pr-3">Asset</th><th className="py-2 pr-3">Source</th><th className="py-2">Validation</th></tr>
                </thead>
                <tbody>
                  {c.findings.map((f) => (
                    <tr key={f.id} className="border-b border-line/60">
                      <td className="py-2 pr-3"><button type="button" className="font-mono text-xs text-accent hover:underline" onClick={() => setFinding(f.id)}>{f.cite}</button></td>
                      <td className="py-2 pr-3"><SeverityBadge severity={f.severity} /></td>
                      <td className="py-2 pr-3">{f.title}</td>
                      <td className="py-2 pr-3 text-xs">{f.affected_asset || '—'}</td>
                      <td className="py-2 pr-3 text-xs">{f.source_tool} <span className="text-fg-subtle">({f.origin})</span></td>
                      <td className="py-2 text-xs"><StatusBadge status={f.validation_status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : <p className="text-sm text-fg-subtle">No active findings.</p>}
        </Section>
        <Section number={3} title="Risk Assessment">
          <Cited text={n.risk_assessment} cites={cites} onCite={openCite} />
          <div className="grid gap-3 md:grid-cols-3">
            {c.risk.components.map((comp) => (
              <div key={comp.key} className="rounded-md border border-line bg-surface-2 p-3 text-xs">
                <p className="font-medium text-fg">{comp.label} · weight {comp.weight.toFixed(2)}</p>
                <p className="mt-1 text-lg tabular-nums text-accent">{comp.value === null ? 'missing' : comp.value.toFixed(2)}</p>
                <p className="mt-1 text-fg-muted">{comp.explanation}</p>
              </div>
            ))}
          </div>
          <p className="text-xs text-fg-muted">
            {c.risk.formula} → score {c.risk.score === null ? 'not available' : `${Math.round(c.risk.score * 100)}/100`}, coverage {Math.round(c.risk.coverage * 100)}%, possible range {Math.round(c.risk.lower_bound * 100)}–{Math.round(c.risk.upper_bound * 100)}. {c.risk.interpretation}
          </p>
          {c.cve_references.length || c.attack_references.length ? (
            <div className="flex flex-wrap gap-1.5">
              {c.cve_references.map((cve) => <Badge key={cve.id} className="font-mono">{cve.id} {cve.cvss !== null ? `· ${cve.cvss}` : '· not enriched'} · {cve.validation}</Badge>)}
              {c.attack_references.map((t) => <Badge key={t.id} tone="info" className="font-mono">{t.id} {t.title} · {t.validation}</Badge>)}
            </div>
          ) : null}
        </Section>
        <Section number={4} title="Recommended Mitigations">
          {n.recommended_mitigations.length ? (
            <ol className="list-decimal space-y-2 pl-5 text-sm">
              {n.recommended_mitigations.map((m, i) => (
                <li key={i}>
                  {m.text}{' '}
                  {m.finding_ids.map((fid) => (
                    <button key={fid} type="button" className="mx-0.5 rounded bg-accent-soft px-1 font-mono text-xs text-accent hover:underline" onClick={() => openCite(fid.replace(/[[\]]/g, ''))}>{fid}</button>
                  ))}
                </li>
              ))}
            </ol>
          ) : <p className="text-sm text-fg-subtle">No mitigations could be derived from the recorded evidence.</p>}
        </Section>
        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader title="Scope and data sources" />
            <CardBody className="space-y-3">
              <KeyValue
                items={[
                  ['Scope', <span className="whitespace-pre-wrap">{c.scope.description}</span>],
                  ['Authorized targets', c.scope.authorized_targets.length ? c.scope.authorized_targets.map((t) => `${t.type}:${t.value}`).join(', ') : 'None registered'],
                  ['Workspaces', c.scope.workspaces_involved.join(', ') || '—'],
                  ['Tool runs', c.data_sources.tool_runs.map((t) => `${t.tool} (${t.status})`).join(', ') || 'None'],
                  ['Evidence', c.data_sources.evidence.filter((e) => e.original).map((e) => `${e.filename} [sha256 ${e.sha256.slice(0, 12)}…]`).join(', ') || 'None'],
                ]}
              />
            </CardBody>
          </Card>
          <Card>
            <CardHeader title="Limitations and missing information" />
            <CardBody>
              {c.limitations.length ? <ul className="list-disc space-y-1.5 pl-5 text-sm text-fg-muted">{c.limitations.map((l) => <li key={l}>{l}</li>)}</ul> : <p className="text-sm text-fg-subtle">None recorded.</p>}
            </CardBody>
          </Card>
        </div>
        <Card>
          <CardHeader title="Analyst notes" subtitle={editable ? 'Editable until the report is submitted for review.' : 'Locked: regenerate to create a new version.'} />
          <CardBody className="space-y-3">
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} disabled={!editable} placeholder="Notes for the reviewer and readers of this report" />
            {editable ? <Button size="sm" loading={save.isPending} onClick={() => save.mutate()}>Save notes</Button> : null}
            {c.analyst_notes.length ? (
              <div className="space-y-1 border-t border-line pt-3">
                <p className="text-xs font-semibold uppercase tracking-wide text-fg-subtle">Investigation notes included</p>
                {c.analyst_notes.map((note, i) => <p key={i} className="text-xs text-fg-muted">{formatDateTime(note.at)} {note.author}{note.finding ? ` on ${note.finding}` : ''}: {note.body}</p>)}
              </div>
            ) : null}
          </CardBody>
        </Card>
      </div>
      <Modal
        open={!!deciding}
        onClose={() => setDeciding(null)}
        title={deciding === 'approve' ? 'Approve report' : 'Request changes'}
        footer={
          <>
            <Button variant="ghost" onClick={() => setDeciding(null)}>Cancel</Button>
            <Button variant="primary" loading={decide.isPending} disabled={deciding === 'request-changes' && !comment.trim()} onClick={() => decide.mutate()}>
              {deciding === 'approve' ? 'Approve' : 'Send back'}
            </Button>
          </>
        }
      >
        <div className="space-y-3">
          {decide.isError ? <Alert tone="danger">{errorMessage(decide.error)}</Alert> : null}
          <p className="text-sm text-fg-muted">
            {deciding === 'approve' ? 'Confirm that you checked the findings and citations against the evidence.' : 'Explain what must change before approval.'}
          </p>
          <Textarea value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Reviewer comment" />
        </div>
      </Modal>
      <FindingDetail findingId={finding} onClose={() => setFinding(null)} />
    </>
  )
}
