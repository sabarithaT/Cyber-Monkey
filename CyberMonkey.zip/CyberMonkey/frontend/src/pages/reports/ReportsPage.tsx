import { useQuery } from '@tanstack/react-query'
import { FileText } from 'lucide-react'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../../api/client'
import type { ReportSummary } from '../../api/models'
import type { Page } from '../../api/types'
import { Badge, DemoBadge, StatusBadge } from '../../components/ui/Badge'
import { Card, CardHeader, PageHeader } from '../../components/ui/Card'
import { Select } from '../../components/ui/Form'
import { EmptyState } from '../../components/ui/States'
import { DataTable, Pagination } from '../../components/ui/Table'
import { formatRelative } from '../../lib/format'

export function ReportsPage() {
  const navigate = useNavigate()
  const [page, setPage] = useState(1)
  const [status, setStatus] = useState('')
  useEffect(() => {
    setPage(1)
  }, [status])
  const query = useQuery({
    queryKey: ['reports', 'all', page, status],
    queryFn: () => api.get<Page<ReportSummary>>('/reports', { page, page_size: 20, status }),
  })
  return (
    <>
      <PageHeader
        title="Reports"
        description="Report history across your investigations. Generate new reports from an investigation's Reports tab or ask the AI assistant."
      />
      <Card>
        <CardHeader
          title="All reports"
          actions={
            <Select value={status} onChange={(e) => setStatus(e.target.value)} className="h-8 w-auto text-xs" aria-label="Status">
              <option value="">Any status</option>
              <option value="draft">Draft</option>
              <option value="in_review">In review</option>
              <option value="changes_requested">Changes requested</option>
              <option value="approved">Approved</option>
            </Select>
          }
        />
        <DataTable
          rows={query.data?.items}
          loading={query.isLoading}
          error={query.error}
          onRetry={() => query.refetch()}
          rowKey={(r) => r.id}
          onRowClick={(r) => navigate(`/reports/${r.id}`)}
          empty={<EmptyState icon={FileText} title="No reports yet" description="Reports are generated from investigation data; none exist until you create one." />}
          columns={[
            { key: 't', header: 'Report', render: (r) => <div><p className="font-medium">{r.title} {r.is_demo ? <DemoBadge /> : null}</p><p className="font-mono text-[11px] text-fg-subtle">{r.investigation_reference} · v{r.version}</p></div> },
            { key: 's', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
            { key: 'm', header: 'Narrative', render: (r) => <Badge tone={r.generation_mode === 'llm' ? 'violet' : 'neutral'}>{r.generation_mode === 'llm' ? `LLM · ${r.llm_model}` : 'Template'}</Badge> },
            { key: 'r', header: 'Risk', render: (r) => <span className="tabular-nums text-xs">{r.risk_score === null ? '—' : Math.round(r.risk_score * 100)}</span> },
            { key: 'f', header: 'Findings', render: (r) => <span className="tabular-nums text-xs">{r.finding_count}</span> },
            { key: 'g', header: 'Generated', render: (r) => <span className="text-xs text-fg-muted">{formatRelative(r.created_at)} · {r.generated_by.email}</span> },
            { key: 'rv', header: 'Reviewed by', render: (r) => <span className="text-xs">{r.reviewed_by?.email ?? '—'}</span> },
          ]}
        />
        {query.data ? <Pagination page={page} pageSize={query.data.page_size} total={query.data.total} onPage={setPage} /> : null}
      </Card>
    </>
  )
}
