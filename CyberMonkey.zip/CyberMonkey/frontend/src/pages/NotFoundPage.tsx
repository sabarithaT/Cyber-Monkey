import { Compass } from 'lucide-react'
import { Link } from 'react-router-dom'
import { EmptyState } from '../components/ui/States'

export function NotFoundPage() {
  return (
    <EmptyState
      icon={Compass}
      title="Page not found"
      description="The page you requested does not exist or you do not have access to it."
      action={
        <Link to="/" className="text-sm text-accent hover:underline">
          Go to the overview dashboard
        </Link>
      }
    />
  )
}
