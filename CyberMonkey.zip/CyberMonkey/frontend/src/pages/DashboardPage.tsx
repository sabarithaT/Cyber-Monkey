import { useQuery } from '@tanstack/react-query'
import { Activity, FolderPlus, Gauge } from 'lucide-react'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { api } from '../api/client'
import type { DashboardSummary } from '../api/models'
import { useAuth } from '../auth/AuthContext'
import { DemoBadge, SeverityBadge, StatusBadge } from '../components/ui/Badge'
import { Button } from '../components/ui/Button'
import { Card, CardBody, CardHeader, PageHeader, StatTile } from '../components/ui/Card'
import { Alert, EmptyState, ErrorState, LoadingState } from '../components/ui/States'
import { formatRelative, titleCase } from '../lib/format'
import { WORKSPACE_BY_KEY } from '../lib/workspaces'
import { CreateInvestigationModal } from './investigations/CreateInvestigationModal'

const SEV_COLORS: Record<string, string> = {
  critical: '#f43f5e',
  high: '#f97316',
  medium: '#eab308',
  low: '#3b82f6',
  info: '#64748b',
}

function List<T>({ items, empty, render }: { items: T[]; empty: string; render: (item: T) => React.ReactNode }) {
  if (!items.length) return <p className="px-4 py-6 text-center text-xs text-fg-subtle">{empty}</p>
  return <ul className="divide-y divide-line/60">{items.map(render)}</ul>
}

export function DashboardPage() {
  const { user, can } = useAuth()
  const [creating, setCreating] = useState(false)
  const query = useQuery({
    queryKey: ['dashboard'],
    queryFn: () => api.get<DashboardSummary>('/dashboard/summary'),
    refetchInterval: 30_000,
  })
  if (query.isLoading) return <LoadingState />
  if (query.error) return <ErrorState error={query.error} onRetry={() => query.refetch()} />
  const d = query.data!
  const severityData = (['critical', 'high', 'medium', 'low', 'info'] as const).map((s) => ({ severity: s, count: d.findings_by_severity[s] }))
  const totalFindings = severityData.reduce((n, s) => n + s.count, 0)
  const runsTotal = Object.values(d.runs_by_status).reduce((n, v) => n + (v ?? 0), 0)
  const empty = d.investigations.total === 0

  return (
    <>
      <PageHeader
        title="Overview Dashboard"
        description={`Live figures from the database for the investigations and workspaces you can access. Updated ${formatRelative(d.generated_at)}.`}
        badge={d.has_demo_data ? <DemoBadge /> : null}
        actions={can('investigations:create') ? <Button variant="primary" icon={FolderPlus} onClick={() => setCreating(true)}>New investigation</Button> : null}
      />
      {d.has_demo_data ? (
        <div className="mb-4"><Alert tone="info">Some of the data below comes from a demonstration investigation built from bundled sample files. It is labelled wherever it appears.</Alert></div>
      ) : null}
      {empty ? (
        <Card className="mb-6">
          <EmptyState
            icon={Gauge}
            title={`Welcome, ${user?.full_name.split(' ')[0] ?? ''}`}
            description={
              <>
                No investigations yet, so every metric is zero. Create an investigation, upload evidence or an exported results file,
                run a tool, then compute risk and generate a report. The AI assistant can do these steps from a natural-language request.
              </>
            }
            action={can('investigations:create') ? <Button size="sm" variant="primary" onClick={() => setCreating(true)}>Create the first investigation</Button> : undefined}
          />
        </Card>
      ) : null}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-6">
        <StatTile label="Investigations" value={d.investigations.total} hint={`${d.investigations.closed} closed`} />
        <StatTile label="Open investigations" value={d.investigations.open} tone="accent" />
        <StatTile label="Open findings" value={d.open_findings} hint={`${totalFindings} active in total`} />
        <StatTile label="Critical + high" value={d.findings_by_severity.critical + d.findings_by_severity.high} tone={d.findings_by_severity.critical ? 'danger' : 'warning'} />
        <StatTile label="Tool runs" value={runsTotal} hint={`${d.runs_by_status.succeeded ?? 0} succeeded`} />
        <StatTile label="Awaiting approval" value={d.runs_by_status.pending_approval ?? 0} tone={(d.runs_by_status.pending_approval ?? 0) > 0 ? 'warning' : 'default'} />
      </div>
      <div className="mt-6 grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader title="Findings by severity" subtitle="Active findings (false positives excluded)." />
          <CardBody>
            {totalFindings ? (
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={severityData} margin={{ left: -20, right: 8 }}>
                    <CartesianGrid stroke="#233044" vertical={false} />
                    <XAxis dataKey="severity" tickFormatter={titleCase} stroke="#93a1b5" fontSize={12} tickLine={false} />
                    <YAxis allowDecimals={false} stroke="#93a1b5" fontSize={12} tickLine={false} axisLine={false} />
                    <Tooltip cursor={{ fill: 'rgba(45,212,191,0.06)' }} contentStyle={{ background: '#151d29', border: '1px solid #2f3e55', borderRadius: 6, fontSize: 12 }} />
                    <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                      {severityData.map((s) => (
                        <Cell key={s.severity} fill={SEV_COLORS[s.severity]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <EmptyState title="No findings recorded" description="Severity counts appear once tools or imports produce findings." />
            )}
          </CardBody>
        </Card>
        <Card>
          <CardHeader title="Tool execution status" />
          <CardBody>
            {runsTotal ? (
              <ul className="space-y-2">
                {Object.entries(d.runs_by_status).map(([status, n]) => (
                  <li key={status} className="flex items-center justify-between text-sm">
                    <StatusBadge status={status} />
                    <span className="tabular-nums">{n}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-xs text-fg-subtle">No tools have been run yet.</p>
            )}
          </CardBody>
        </Card>
      </div>
      <div className="mt-6 grid gap-6 lg:grid-cols-2 xl:grid-cols-3">
        <Card>
          <CardHeader title="Recent high-priority findings" subtitle="Medium severity and above" />
          <List
            items={d.recent_alerts}
            empty="No medium-or-higher findings."
            render={(a) => (
              <li key={a.id} className="px-4 py-2.5">
                <div className="flex items-center gap-2">
                  <SeverityBadge severity={a.severity} />
                  <Link to={`/investigations/${a.investigation_id}?tab=findings`} className="min-w-0 truncate text-sm hover:text-accent">{a.title}</Link>
                </div>
                <p className="mt-0.5 text-[11px] text-fg-subtle">{a.investigation_reference} · {a.source_tool} · {formatRelative(a.observed_at)}</p>
              </li>
            )}
          />
        </Card>
        <Card>
          <CardHeader title="Recent tool runs" />
          <List
            items={d.recent_runs}
            empty="No tool runs yet."
            render={(r) => (
              <li key={r.id} className="flex items-center justify-between gap-2 px-4 py-2.5">
                <div className="min-w-0">
                  <Link to={`/investigations/${r.investigation_id}?tab=runs&run=${r.id}`} className="font-mono text-xs hover:text-accent">{r.tool}</Link>
                  <p className="text-[11px] text-fg-subtle">{r.investigation_reference} · {r.requested_by} · {formatRelative(r.created_at)}</p>
                </div>
                <StatusBadge status={r.status} />
              </li>
            )}
          />
        </Card>
        <Card>
          <CardHeader title="Recent indicators" />
          <List
            items={d.recent_iocs}
            empty="No indicators extracted yet."
            render={(i) => (
              <li key={i.id} className="flex items-center justify-between gap-2 px-4 py-2.5">
                <span className="min-w-0 truncate font-mono text-xs">{i.type}:{i.value}</span>
                <span className="text-[11px] text-fg-subtle">{i.finding_count} finding(s)</span>
              </li>
            )}
          />
        </Card>
        <Card>
          <CardHeader title="Latest reports" />
          <List
            items={d.latest_reports}
            empty={can('reports:view') ? 'No reports generated yet.' : 'Viewing reports requires reports:view.'}
            render={(r) => (
              <li key={r.id} className="flex items-center justify-between gap-2 px-4 py-2.5">
                <div className="min-w-0">
                  <Link to={`/reports/${r.id}`} className="block truncate text-sm hover:text-accent">{r.title}</Link>
                  <p className="text-[11px] text-fg-subtle">v{r.version} · {formatRelative(r.created_at)}</p>
                </div>
                <StatusBadge status={r.status} />
              </li>
            )}
          />
        </Card>
        <Card>
          <CardHeader title="Workspace activity" subtitle="Last 30 days" />
          <List
            items={d.workspace_activity}
            empty="You have no workspace access."
            render={(w) => (
              <li key={w.workspace} className="flex items-center justify-between px-4 py-2.5 text-sm">
                <Link to={WORKSPACE_BY_KEY[w.workspace].path} className="hover:text-accent">{WORKSPACE_BY_KEY[w.workspace].label}</Link>
                <span className="text-xs tabular-nums text-fg-muted">{w.runs_30d} runs · {w.findings_30d} findings</span>
              </li>
            )}
          />
        </Card>
        <Card>
          <CardHeader title="Recent audit activity" subtitle={d.activity_scope === 'all' ? 'All users' : 'Your own activity'} />
          <List
            items={d.recent_activity}
            empty="No activity recorded."
            render={(a) => (
              <li key={a.id} className="flex items-center justify-between gap-2 px-4 py-2">
                <div className="min-w-0">
                  <p className="flex items-center gap-1.5 font-mono text-xs"><Activity className="size-3 text-fg-subtle" />{a.action}</p>
                  <p className="text-[11px] text-fg-subtle">{a.actor || '—'} · {formatRelative(a.occurred_at)}</p>
                </div>
                <StatusBadge status={a.result} />
              </li>
            )}
          />
        </Card>
      </div>
      <CreateInvestigationModal open={creating} onClose={() => setCreating(false)} />
    </>
  )
}
