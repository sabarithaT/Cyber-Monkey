import { useQuery } from '@tanstack/react-query'
import { useEffect, useState } from 'react'
import { api } from '../api/client'
import type { AuditLogEntry, Page } from '../api/types'
import { StatusBadge } from '../components/ui/Badge'
import { Card, CardHeader, CodeBlock, KeyValue, PageHeader } from '../components/ui/Card'
import { Input, Select } from '../components/ui/Form'
import { Modal } from '../components/ui/Modal'
import { EmptyState } from '../components/ui/States'
import { DataTable, Pagination } from '../components/ui/Table'
import { formatDateTime } from '../lib/format'
import { useDebounced } from '../lib/useDebounced'

const ACTION_PREFIXES = [
  ['', 'All actions'],
  ['auth.', 'Authentication'],
  ['authz.', 'Authorization denials'],
  ['user.', 'User changes'],
  ['role.', 'Role changes'],
  ['investigation.', 'Investigations'],
  ['tool_run.', 'Tool executions'],
  ['evidence.', 'Evidence'],
  ['report.', 'Reports'],
  ['integration.', 'Integration configuration'],
  ['assistant.', 'AI assistant'],
] as const

export function AuditLogsPage() {
  const [page, setPage] = useState(1)
  const [action, setAction] = useState('')
  const [result, setResult] = useState('')
  const [resourceId, setResourceId] = useState('')
  const [selected, setSelected] = useState<AuditLogEntry | null>(null)
  const debouncedResource = useDebounced(resourceId.trim())

  useEffect(() => {
    setPage(1)
  }, [action, result, debouncedResource])

  const query = useQuery({
    queryKey: ['audit-logs', page, action, result, debouncedResource],
    queryFn: () =>
      api.get<Page<AuditLogEntry>>('/audit-logs', {
        page,
        page_size: 50,
        action,
        result,
        resource_id: debouncedResource,
      }),
  })

  return (
    <>
      <PageHeader
        title="Audit Logs"
        description="Security-relevant activity: sign-ins, authorization denials, administrative changes, tool executions, approvals, evidence access and report generation. Secrets are redacted before storage."
      />
      <Card>
        <CardHeader
          title="Events"
          subtitle={query.data ? `${query.data.total} matching events` : undefined}
          actions={
            <>
              <Select value={action} onChange={(e) => setAction(e.target.value)} className="h-8 w-auto text-xs" aria-label="Action">
                {ACTION_PREFIXES.map(([value, label]) => (
                  <option key={value} value={value}>{label}</option>
                ))}
              </Select>
              <Select value={result} onChange={(e) => setResult(e.target.value)} className="h-8 w-auto text-xs" aria-label="Result">
                <option value="">Any result</option>
                <option value="success">Success</option>
                <option value="failure">Failure</option>
                <option value="denied">Denied</option>
              </Select>
              <Input value={resourceId} onChange={(e) => setResourceId(e.target.value)} placeholder="Resource ID" className="h-8 w-44 text-xs" aria-label="Resource ID" />
            </>
          }
        />
        <DataTable
          dense
          rows={query.data?.items}
          loading={query.isLoading}
          error={query.error}
          onRetry={() => query.refetch()}
          rowKey={(row) => String(row.id)}
          onRowClick={setSelected}
          empty={<EmptyState title="No audit events match these filters" />}
          columns={[
            { key: 'time', header: 'Time', render: (r) => <span className="whitespace-nowrap text-xs tabular-nums text-fg-muted">{formatDateTime(r.occurred_at)}</span> },
            { key: 'actor', header: 'Actor', render: (r) => <span className="text-xs">{r.actor_email || '—'}</span> },
            { key: 'action', header: 'Action', render: (r) => <span className="font-mono text-xs">{r.action}</span> },
            { key: 'resource', header: 'Resource', render: (r) => <span className="font-mono text-xs text-fg-muted">{r.resource_type ? `${r.resource_type}:${r.resource_id.slice(0, 12)}` : '—'}</span> },
            { key: 'result', header: 'Result', render: (r) => <StatusBadge status={r.result} /> },
            { key: 'ip', header: 'IP', render: (r) => <span className="font-mono text-xs text-fg-subtle">{r.ip_address || '—'}</span> },
          ]}
        />
        {query.data ? <Pagination page={page} pageSize={query.data.page_size} total={query.data.total} onPage={setPage} /> : null}
      </Card>
      <Modal open={!!selected} onClose={() => setSelected(null)} title="Audit event" wide>
        {selected ? (
          <div className="space-y-4">
            <KeyValue
              items={[
                ['Event ID', <span className="font-mono">{selected.id}</span>],
                ['Time', formatDateTime(selected.occurred_at)],
                ['Actor', selected.actor_email || '—'],
                ['Action', <span className="font-mono">{selected.action}</span>],
                ['Resource', <span className="font-mono">{selected.resource_type ? `${selected.resource_type} ${selected.resource_id}` : '—'}</span>],
                ['Result', <StatusBadge status={selected.result} />],
                ['IP address', selected.ip_address || '—'],
                ['User agent', <span className="text-xs text-fg-muted">{selected.user_agent || '—'}</span>],
              ]}
            />
            <div>
              <p className="mb-1.5 text-xs font-medium uppercase tracking-wide text-fg-subtle">Details</p>
              <CodeBlock>{JSON.stringify(selected.details, null, 2)}</CodeBlock>
            </div>
          </div>
        ) : null}
      </Modal>
    </>
  )
}
