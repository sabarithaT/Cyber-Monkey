import { FolderPlus } from 'lucide-react'
import { useEffect, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import type { WorkspaceKey } from '../api/types'
import { useAuth } from '../auth/AuthContext'
import { EvidencePanel } from '../components/EvidencePanel'
import { FindingsTable } from '../components/FindingsTable'
import { InvestigationPicker, useInvestigations } from '../components/InvestigationPicker'
import { RunsTable, ToolsCard } from '../components/RunPanels'
import { DemoBadge } from '../components/ui/Badge'
import { Button } from '../components/ui/Button'
import { Card, CardBody, CardHeader, PageHeader } from '../components/ui/Card'
import { Alert } from '../components/ui/States'
import { Tabs } from '../components/ui/Tabs'
import { WORKSPACE_BY_KEY } from '../lib/workspaces'
import { CreateInvestigationModal } from './investigations/CreateInvestigationModal'

const GUIDANCE: Record<WorkspaceKey, { title: string; points: string[] }> = {
  soc: {
    title: 'SOC monitoring workflow',
    points: [
      'Upload authorized security logs or a SIEM findings export as evidence (kind: Security log).',
      'Import structured findings to triage alerts with severity, status and validation.',
      'Correlate extracted indicators with other workspaces and compute the investigation risk score.',
      'Live SIEM connectors are integration points for later work: nothing here is shown as a live alert unless it was imported.',
    ],
  },
  pentest: {
    title: 'Authorized assessment workflow',
    points: [
      'Register explicitly authorized lab targets in the investigation scope, with who authorized them.',
      'Run your scanner on the lab network, then import its export (kind: Scan report) to normalize the results into findings.',
      'Cyber Monkey does not scan networks itself in this version; consequential tools always require confirmation.',
    ],
  },
  osint: {
    title: 'OSINT workflow',
    points: [
      'Record public-source collection results as OSINT evidence and import them as findings with their source.',
      'Only correlate; a shared indicator is a lead to verify, not a confirmed association.',
    ],
  },
  malware: {
    title: 'Malware analysis workflow',
    points: [
      'Upload a sample: it is stored read-only, hashed, never executed and never downloadable.',
      'Run the static file profile (hashes, type, entropy) and import reports from your isolated sandbox.',
      'Cyber Monkey never runs samples; import the JSON report from your own isolated sandbox instead.',
    ],
  },
  forensics: {
    title: 'Digital forensics workflow',
    points: [
      'Register evidence with its source and acquisition time; hashes are computed on upload.',
      'Verify integrity at any time; every access, analysis and download is recorded in the custody history.',
      'Import results from your forensic suite to organize artifacts into findings and the investigation timeline.',
    ],
  },
  network: {
    title: 'Network monitoring workflow',
    points: [
      'Upload IDS alert exports or traffic-analysis results captured on networks you are authorized to monitor.',
      'Imported indicators are correlated with OSINT, malware and SOC findings across workspaces.',
    ],
  },
}

export function WorkspacePage({ workspace }: { workspace: WorkspaceKey }) {
  const meta = WORKSPACE_BY_KEY[workspace]
  const { can } = useAuth()
  const [params, setParams] = useSearchParams()
  const [creating, setCreating] = useState(false)
  const cases = useInvestigations()
  const selected = params.get('investigation') ?? ''
  const tab = params.get('tab') ?? 'tools'
  const selectedCase = cases.data?.items.find((i) => i.id === selected)

  useEffect(() => {
    if (!selected && cases.data?.items.length) {
      const preferred = cases.data.items.find((i) => i.primary_workspace === workspace) ?? cases.data.items[0]
      setParams({ investigation: preferred.id, tab }, { replace: true })
    }
  }, [selected, cases.data, workspace, setParams, tab])

  const Icon = meta.icon
  const guide = GUIDANCE[workspace]
  return (
    <>
      <PageHeader
        title={<span className="flex items-center gap-2"><Icon className="size-6 text-accent" />{meta.label}</span>}
        description={meta.description}
        actions={can('investigations:create') ? <Button icon={FolderPlus} onClick={() => setCreating(true)}>New investigation</Button> : null}
      />
      <div className="mb-6 grid gap-4 lg:grid-cols-[1fr_22rem]">
        <Card>
          <CardHeader title="Working investigation" subtitle="Tools, evidence and findings below are scoped to the selected case." />
          <CardBody className="flex flex-wrap items-center gap-3">
            <InvestigationPicker value={selected} onChange={(id) => setParams({ investigation: id, tab })} className="max-w-xl" />
            {selectedCase ? (
              <>
                {selectedCase.is_demo ? <DemoBadge /> : null}
                <Link to={`/investigations/${selectedCase.id}`} className="text-sm text-accent hover:underline">Open case</Link>
              </>
            ) : null}
          </CardBody>
        </Card>
        <Card>
          <CardHeader title={guide.title} />
          <CardBody>
            <ul className="list-disc space-y-1.5 pl-4 text-xs text-fg-muted">
              {guide.points.map((p) => <li key={p}>{p}</li>)}
            </ul>
          </CardBody>
        </Card>
      </div>
      {!cases.isLoading && !cases.data?.items.length ? (
        <Alert tone="info" title="No investigation yet">Create an investigation to use this workspace's tools.</Alert>
      ) : null}
      {selected ? (
        <>
          <Tabs
            items={[
              { key: 'tools', label: 'Tools' },
              { key: 'evidence', label: 'Evidence' },
              { key: 'findings', label: 'Findings' },
              { key: 'runs', label: 'Run history' },
            ]}
            active={tab}
            onChange={(key) => setParams({ investigation: selected, tab: key })}
          />
          {tab === 'tools' ? <ToolsCard workspace={workspace} investigationId={selected} writable /> : null}
          {tab === 'evidence' ? <Card><EvidencePanel investigationId={selected} workspace={workspace} writable /></Card> : null}
          {tab === 'findings' ? (
            <Card>
              <FindingsTable investigationId={selected} workspace={workspace} emptyHint={`No ${meta.short} findings in this investigation yet. Run a tool or import results.`} />
            </Card>
          ) : null}
          {tab === 'runs' ? <Card><RunsTable investigationId={selected} workspace={workspace} /></Card> : null}
        </>
      ) : null}
      <CreateInvestigationModal
        open={creating}
        onClose={() => setCreating(false)}
        defaultWorkspace={workspace}
        navigateOnCreate={false}
        onCreated={(inv) => setParams({ investigation: inv.id, tab: 'tools' })}
      />
    </>
  )
}
