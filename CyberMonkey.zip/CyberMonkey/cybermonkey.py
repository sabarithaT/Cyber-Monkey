#!/usr/bin/env python3
"""Cyber Monkey launcher — one command to set up and run the development stack.

    python cybermonkey.py setup     # install everything, create the database and an administrator
    python cybermonkey.py start     # start database + backend + frontend, open http://localhost:5173
    python cybermonkey.py admin     # create another administrator account

Requirements: Python 3.12 (the embedded PostgreSQL package ships wheels for 3.12) and
Node.js 20+. If you already run PostgreSQL, pass --database-url to `setup` and any
Python >= 3.12 works.

Only the Python standard library is used here, so this runs before anything is installed.
"""

from __future__ import annotations

import argparse
import getpass
import os
import re
import secrets
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BACKEND = ROOT / "backend"
FRONTEND = ROOT / "frontend"
ENV_FILE = BACKEND / ".env"
VENV = BACKEND / ".venv"
IS_WINDOWS = os.name == "nt"
VENV_PYTHON = VENV / ("Scripts/python.exe" if IS_WINDOWS else "bin/python")


# --- output helpers ------------------------------------------------------------------------


def step(message: str) -> None:
    print(f"\n==> {message}", flush=True)


def fail(message: str) -> None:
    print(f"\nERROR: {message}", file=sys.stderr, flush=True)
    raise SystemExit(1)


def run(cmd: list[str], *, cwd: Path | None = None, env: dict[str, str] | None = None, capture: bool = False) -> str:
    result = subprocess.run(
        cmd, cwd=cwd, env=env, text=True,
        stdout=subprocess.PIPE if capture else None, stderr=subprocess.STDOUT if capture else None,
    )
    if result.returncode != 0:
        if capture and result.stdout:
            print(result.stdout[-3000:])
        fail(f"Command failed ({result.returncode}): {' '.join(cmd)}")
    return result.stdout or ""


# --- environment discovery ---------------------------------------------------------------


def find_python312() -> list[str] | None:
    if sys.version_info[:2] == (3, 12):
        return [sys.executable]
    candidates = [["py", "-3.12"]] if IS_WINDOWS else [["python3.12"]]
    for cmd in candidates:
        if shutil.which(cmd[0]):
            probe = subprocess.run([*cmd, "-c", "import sys; print(sys.version_info[:2] == (3, 12))"], capture_output=True, text=True)
            if probe.returncode == 0 and probe.stdout.strip() == "True":
                return cmd
    return None


def npm() -> str:
    path = shutil.which("npm")
    if not path:
        fail("Node.js (with npm) was not found. Install Node.js 20 or newer from https://nodejs.org/ and rerun.")
    return path  # type: ignore[return-value]


# --- .env handling -------------------------------------------------------------------------


def read_env() -> dict[str, str]:
    values: dict[str, str] = {}
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                key, _, value = line.partition("=")
                values[key.strip()] = value.strip()
    return values


def write_env_values(updates: dict[str, str]) -> None:
    lines = ENV_FILE.read_text(encoding="utf-8").splitlines() if ENV_FILE.exists() else [
        "# Local development settings created by cybermonkey.py. Do not commit or share this file.",
    ]
    seen: set[str] = set()
    for index, line in enumerate(lines):
        key = line.partition("=")[0].strip()
        if key in updates and not line.lstrip().startswith("#"):
            lines[index] = f"{key}={updates[key]}"
            seen.add(key)
    lines += [f"{key}={value}" for key, value in updates.items() if key not in seen]
    ENV_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")


def start_embedded_database() -> str:
    output = run([str(VENV_PYTHON), "scripts/dev_postgres.py", "--print"], cwd=BACKEND, capture=True)
    match = re.search(r"^DATABASE_URL=(\S+)$", output, flags=re.M)
    if not match:
        print(output)
        fail("Could not start the embedded PostgreSQL server.")
    return match.group(1)


# --- commands ------------------------------------------------------------------------------


def create_admin(env: dict[str, str]) -> None:
    print("\nCreate the administrator account you will sign in with.")
    print("Password: at least 12 characters with three of lowercase, uppercase, digit, symbol.")
    while True:
        email = input("  Admin email: ").strip()
        name = input("  Full name: ").strip() or "Administrator"
        password = os.environ.get("CM_ADMIN_PASSWORD") or getpass.getpass("  Password (hidden): ")
        if not os.environ.get("CM_ADMIN_PASSWORD") and password != getpass.getpass("  Repeat password: "):
            print("  Passwords do not match; try again.")
            continue
        result = subprocess.run(
            [str(VENV_PYTHON), "-m", "app.cli", "create-admin", "--email", email, "--name", name],
            cwd=BACKEND, env={**env, "BOOTSTRAP_ADMIN_PASSWORD": password}, text=True, capture_output=True,
        )
        message = (result.stdout + result.stderr).strip()
        print(f"  {message.splitlines()[-1] if message else ''}")
        if result.returncode == 0:
            return
        if os.environ.get("CM_ADMIN_PASSWORD"):
            fail("CM_ADMIN_PASSWORD was rejected.")
        print("  Please try again.")


def cmd_setup(args: argparse.Namespace) -> None:
    print("Cyber Monkey setup")
    node = npm()
    if args.database_url:
        python = [sys.executable] if sys.version_info >= (3, 12) else find_python312()
        if python is None:
            fail("Python 3.12 or newer is required.")
    else:
        python = find_python312()
        if python is None:
            fail(
                "Python 3.12 was not found. Install it from https://www.python.org/downloads/ "
                "(the embedded database needs 3.12), or pass --database-url for an existing PostgreSQL server."
            )

    step("Creating the Python environment (backend/.venv)")
    if not VENV_PYTHON.exists():
        run([*python, "-m", "venv", str(VENV)])
    run([str(VENV_PYTHON), "-m", "pip", "install", "--upgrade", "pip", "--quiet"])
    requirements = "requirements.txt" if args.database_url else "requirements-dev.txt"
    step(f"Installing backend packages ({requirements}); this can take a few minutes")
    run([str(VENV_PYTHON), "-m", "pip", "install", "-r", requirements, "--quiet"], cwd=BACKEND)

    step("Preparing the database")
    if args.database_url:
        database_url, embedded = args.database_url, "false"
    else:
        database_url, embedded = start_embedded_database(), "true"
    existing = read_env()
    write_env_values(
        {
            "ENVIRONMENT": existing.get("ENVIRONMENT", "development"),
            "DATABASE_URL": database_url,
            "EMBEDDED_DB": embedded,
            "JWT_SECRET": existing.get("JWT_SECRET") or secrets.token_urlsafe(48),
            "AI_PROVIDER": existing.get("AI_PROVIDER", "none"),
        }
    )
    print(f"  Settings written to {ENV_FILE.relative_to(ROOT)} (a new random JWT secret was generated if none existed).")
    env = {**os.environ, "PYTHONUTF8": "1"}
    run([str(VENV_PYTHON), "-m", "app.cli", "init"], cwd=BACKEND, env=env)

    step("Installing frontend packages (npm install)")
    run([node, "install", "--no-fund", "--no-audit"], cwd=FRONTEND)

    if not args.skip_admin:
        step("Administrator account")
        create_admin(env)
    if args.demo_owner:
        step("Adding the labelled demo investigation")
        run([str(VENV_PYTHON), "-m", "app.cli", "seed-demo", "--owner", args.demo_owner], cwd=BACKEND, env=env)

    print("\nSetup complete. Start Cyber Monkey with:\n\n    python cybermonkey.py start\n")


def wait_for(url: str, timeout: float) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=3) as response:  # noqa: S310 - local URL
                if response.status == 200:
                    return True
        except OSError:
            time.sleep(1)
    return False


def cmd_start(args: argparse.Namespace) -> None:
    if not VENV_PYTHON.exists() or not ENV_FILE.exists() or not (FRONTEND / "node_modules").exists():
        fail("Cyber Monkey is not set up yet. Run: python cybermonkey.py setup")
    env_values = read_env()
    if env_values.get("EMBEDDED_DB", "false") == "true":
        print("Starting the embedded database ...", flush=True)
        write_env_values({"DATABASE_URL": start_embedded_database()})  # its port can change after a reboot
    env = {**os.environ, "PYTHONUTF8": "1"}
    subprocess.run([str(VENV_PYTHON), "-m", "app.cli", "init"], cwd=BACKEND, env=env, check=True,
                   stdout=subprocess.DEVNULL)  # apply any new migrations

    backend_url = f"http://127.0.0.1:{args.backend_port}"
    print(f"Starting the backend on {backend_url} ...", flush=True)
    backend = subprocess.Popen(
        [str(VENV_PYTHON), "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", str(args.backend_port)],
        cwd=BACKEND, env=env,
    )
    processes = [backend]
    try:
        if not wait_for(f"{backend_url}/api/v1/health", 90):
            fail("The backend did not become healthy; see the messages above.")
        print(f"Starting the frontend on http://localhost:{args.frontend_port} ...", flush=True)
        # Run Vite with Node directly rather than through npm: on Windows npm is a batch file,
        # and Ctrl+C would leave a confusing "Terminate batch job (Y/N)?" prompt behind.
        node = shutil.which("node")
        vite = FRONTEND / "node_modules" / "vite" / "bin" / "vite.js"
        command = [node, str(vite)] if node and vite.exists() else [npm(), "run", "dev", "--"]
        frontend = subprocess.Popen(
            [*command, "--port", str(args.frontend_port), "--strictPort"],
            cwd=FRONTEND, env={**os.environ, "CM_BACKEND_URL": backend_url},
        )
        processes.append(frontend)
        print(
            f"\nCyber Monkey is running: open http://localhost:{args.frontend_port}\n"
            f"API documentation: {backend_url}/api/docs\nPress Ctrl+C to stop.\n",
            flush=True,
        )
        while all(p.poll() is None for p in processes):
            time.sleep(1)
        fail("A server stopped unexpectedly; see the messages above.")
    except KeyboardInterrupt:
        print("\nStopping ...")
    finally:
        for process in processes:
            if process.poll() is None:
                process.terminate()
        for process in processes:
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()


def cmd_admin(_: argparse.Namespace) -> None:
    if not VENV_PYTHON.exists() or not ENV_FILE.exists():
        fail("Run `python cybermonkey.py setup` first.")
    if read_env().get("EMBEDDED_DB", "false") == "true":
        write_env_values({"DATABASE_URL": start_embedded_database()})
    create_admin({**os.environ, "PYTHONUTF8": "1"})


def main() -> None:
    parser = argparse.ArgumentParser(prog="python cybermonkey.py", description="Set up and run Cyber Monkey locally.")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("setup", help="install dependencies, prepare the database and create an administrator")
    p.add_argument("--database-url", help="use an existing PostgreSQL (postgresql+psycopg://user:pass@host:5432/db)")
    p.add_argument("--skip-admin", action="store_true", help="do not prompt for an administrator account")
    p.add_argument("--demo-owner", metavar="EMAIL", help="also add the labelled demo investigation for this user")
    p.set_defaults(func=cmd_setup)
    p = sub.add_parser("start", help="start the database, backend and frontend")
    p.add_argument("--backend-port", type=int, default=8000)
    p.add_argument("--frontend-port", type=int, default=5173)
    p.set_defaults(func=cmd_start)
    sub.add_parser("admin", help="create another administrator").set_defaults(func=cmd_admin)
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
