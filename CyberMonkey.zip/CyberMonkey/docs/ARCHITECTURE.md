# Architecture

## Components

| Layer | Technology | Responsibility |
|---|---|---|
| Frontend | React 19, Vite, TypeScript, Tailwind CSS, TanStack Query, Recharts | Role-aware UI; never contacts tools, the model or the database directly |
| API | FastAPI, Pydantic v2 | Versioned REST under `/api/v1`, validation, error envelope, OpenAPI |
| Auth | Argon2id, PyJWT | Login, token revocation, lockout, permission checks on every endpoint |
| AI Orchestrator | `app/services/orchestrator.py` | Routes requests to a plan of registered tools / internal actions |
| LLM layer | `app/ai/provider.py` | Provider-independent interface; Gemini (REST), Ollama (local), or none |
| Tool registry | `app/tools/` | Declares every executable tool: schema, permissions, approval, timeout, scope rule |
| Run engine | `app/services/runs.py` | Request → approval → time-bounded execution → normalization → evidence |
| Threat Intelligence Engine | `app/services/{indicators,correlation,threat_intel,attack,nvd,risk}.py` | IOC normalization, correlation, CVE/ATT&CK references, risk score |
| Report generator | `app/services/reports.py`, `pdf.py` | Structured content → narrative (LLM or template) → review → PDF |
| Persistence | PostgreSQL 16, SQLAlchemy 2, Alembic | 27 tables; JSONB for tool-specific detail |
| Evidence storage | Filesystem under `STORAGE_DIR` | Content-addressed, read-only originals; hashes and custody in the DB |

## Request lifecycle (AI assistant)

1. **Receive** the request (`POST /api/v1/assistant/chat`), rate-limited per user.
2. **Validate the user**: token, active account, `assistant:use`; investigation access if one is selected.
3. **Identify workspace and task**: the LLM router (if configured) or deterministic keyword rules.
   The LLM sees tool schemas and evidence *metadata* only, never evidence content.
4. **Plan**: an ordered list of actions (`run_tool`, `review_findings`, `enrich_cves`, `correlate`,
   `assess_risk`, `generate_report`, `capabilities`).
5. **Select a tool** from the registry; unknown tools are rejected.
6. **Validate arguments** against the tool's strict schema (`extra="forbid"`).
7. **Verify scope**: evidence must belong to the investigation and match the tool's accepted kinds.
   The authorized-scope register and its target-coverage check (`target_in_scope`) are available to
   any tool that acts on network targets.
8. **Confirmation**: tools that require approval create a `pending_approval` run and stop the plan.
9. **Execute** through the run engine on a worker thread with a deadline.
10. **Collect actual output**: summaries and raw output (stored as derived evidence).
11. **Normalize** into findings with evidence locations, indicators and references.
12. **Threat Intelligence Engine**: indicators are upserted and correlated; references are resolved.
13. **Explain**: the LLM (or a deterministic template) summarizes the findings; every cited finding
    ID is checked against the actual set and problems are reported.
14. **Review and report**: the user triages findings and generates a report for review.

Deferred plan steps continue automatically when the tool finishes (post-run hook), and the
result is posted to the same conversation.

## Data model (main tables)

`users`, `roles`, `permissions`, `role_permissions`, `user_roles`, `user_permissions`,
`revoked_tokens`, `investigations`, `investigation_members`, `scope_targets`, `notes`,
`evidence`, `evidence_events`, `tool_runs`, `findings`, `indicators`, `finding_indicators`,
`threat_intel_references`, `finding_references`, `risk_assessments`, `reports`, `audit_logs`,
`integration_configs`, `assistant_conversations`, `assistant_messages`, `log_events`,
`network_flows` (the last two are reserved for future parsers).

### Normalized finding

| Field | Meaning |
|---|---|
| `id`, `investigation_id`, `workspace`, `source_tool`, `run_id` | Identity and provenance |
| `origin` | `tool`, `rule`, `import` or `analyst` — never "AI": the model does not create findings |
| `finding_type`, `title`, `description`, `severity`, `confidence`, `affected_asset`, `observed_at` | The observation |
| `evidence_refs` | Evidence ID + locator (`findings[3]`, `whole file`) + excerpt |
| `indicators` (via `finding_indicators`) | Normalized IOCs with relation and context |
| `references` (via `finding_references`) | CVE / ATT&CK with `match_basis` and validation state |
| `remediation` | Guidance with its source |
| `status`, `validation_status` | Analyst triage state |
| `fingerprint` | De-duplication of re-imported observations |

## Authorization model

* Permission codes: `<workspace>:view|operate|execute` for the six workspaces, plus platform codes
  (`investigations:*`, `findings:triage`, `evidence:*`, `threat_intel:*`, `reports:*`, `audit:view`,
  `users:manage`, `roles:manage`, `integrations:manage`, `assistant:use`, `dashboard:view`).
* Roles are bundles of permissions; users can also hold direct grants. Code checks permission
  codes, never role names.
* Investigation-scoped data additionally requires ownership, membership (viewer/contributor) or
  `investigations:manage_all`. Inaccessible investigations return 404.

## Background execution

Tool runs execute on an in-process thread pool (`TOOL_EXECUTION_MODE=thread`, the default). Runs
left running by a restart are marked failed on startup. A multi-instance deployment would move
this to a job queue; rate limiting would move to a shared store.
