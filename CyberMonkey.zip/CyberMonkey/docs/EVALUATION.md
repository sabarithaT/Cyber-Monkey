# Evaluation plan and kit

**No evaluation has been carried out. Every result below is pending** until the team runs the
protocol under a recorded configuration. Do not report numbers that were not measured.

## Research questions (from the IEEE paper)

| RQ | Question | Measure |
|---|---|---|
| RQ1 | Does one orchestrated interface reduce tool and context switches? | Task completion time; distinct tools/interfaces and switches per task |
| RQ2 | Does the router map requests to the right workspace? | Accuracy and macro-F1 over six workspace classes |
| RQ3 | Does shared correlation make reports more complete and consistent? | Correlation completeness on a seeded linkage task; analyst-rated report quality |
| RQ4 | Can novices complete a basic investigation? | Completion rate and time for novices in both conditions |

## Six representative tasks

| ID | Task | How to run it in Cyber Monkey |
|---|---|---|
| T1 | SOC alert triage | Import a SIEM export (`soc_findings_import`), triage findings, compute risk |
| T2 | Authorized vulnerability scanning | Register the lab target in scope, run your scanner in the lab, import its export (`pentest_findings_import`), enrich CVEs |
| T3 | OSINT investigation | Import collected public-source results (`osint_findings_import`), correlate indicators |
| T4 | Malware sample classification | Upload the sample, run `malware_file_profile`, import the sandbox report |
| T5 | Forensic artifact extraction | Register the image, verify integrity, import forensic-suite results |
| T6 | Network traffic analysis | Import IDS/traffic-analysis results (`network_findings_import`), correlate with T2/T3 |

Conditions: **Cyber Monkey** versus **manual multi-tool baseline** (the same tools used directly).
Ablations from the paper: without the orchestrator (UI only), without correlation (ignore the
Threat Intelligence tab and risk score).

## Kit

| File | Purpose |
|---|---|
| `docs/evaluation/routing_requests.json` | Starter labelled request set (36 requests, 6 per workspace) |
| `backend/scripts/eval_routing.py` | Routes every request and computes accuracy, macro-F1 and per-class precision/recall |
| `docs/evaluation/task_timing_template.csv` | Per-participant timing, completion and context-switch record (RQ1, RQ4) |
| `docs/evaluation/report_quality_rubric.csv` | 1–5 ratings for completeness, accuracy, actionability, unsupported-claim count (RQ3) |

```bash
cd backend
python scripts/eval_routing.py --user admin@example.org --router auto --out routing-results.json
```

`--router rules` forces the deterministic router; `--router auto` uses the configured LLM. The
script prints its configuration (LLM provider and model, dataset, commit) so results can be
reproduced.

**Caveat:** the starter request set was written by the people who built the router, and the
deterministic router matches it trivially. Before measuring RQ2, collect requests written
independently (for example by classmates who have not seen the code), keep them separate from any
tuning, and report results only on that held-out set.

## Configuration to record with every result

* Commit hash; Ollama/Gemini model identifier and quantization; `AI_PROVIDER`.
* Prompts in `app/services/orchestrator.py` and `app/services/reports.py` at that commit.
* ATT&CK catalogue source (built-in subset or full STIX version); NVD fetch dates of CVE records.
* Dataset files and participant counts.

## Statistics

Use paired, non-parametric tests (Wilcoxon signed-rank) for completion times and switch counts
between conditions; report effect sizes alongside p-values. Small samples are expected.

## Results

| Measure | Result |
|---|---|
| Routing accuracy / macro-F1 (RQ2) | Pending |
| Task completion time (RQ1) | Pending |
| Context switches (RQ1) | Pending |
| Correlation completeness (RQ3) | Pending |
| Report quality ratings (RQ3) | Pending |
| Novice usability (RQ4) | Pending |
