# Risk scoring

Implements the IEEE paper's Eq. (2):

```
S = w_c · C(F) + w_m · M(F) + w_i · I(F)        w_c = w_m = w_i = 1/3
```

`F` is the investigation's active finding set: findings marked *false positive* or whose
validation is *rejected* are excluded.

| Component | Definition (normalized to 0–1) | Evaluated when |
|---|---|---|
| `C(F)` CVE severity | max CVSS base score / 10 over CVE references whose validation is `supported` or `confirmed` **and** that are enriched from NVD | at least one such reference exists |
| `M(F)` ATT&CK mapping | max tactic weight over supported/confirmed technique references | at least one such reference exists |
| `I(F)` correlated indicators | min(1, correlated indicators / 5); an indicator is correlated if it links findings in ≥ 2 workspaces or appears in another investigation the user can access | the findings carry at least one indicator |

Tactic weights (heuristic ordering by intrusion progress, tunable in `app/services/attack.py`):
reconnaissance 0.2, resource-development 0.2, discovery 0.35, initial-access 0.6,
defense-evasion 0.6, execution 0.65, persistence 0.65, collection 0.7, credential-access 0.75,
privilege-escalation 0.75, lateral-movement 0.8, command-and-control 0.85, exfiltration 0.95,
impact 1.0.

## Missing components

A component without data is **missing**, not zero. The platform reports:

* `score` — weighted sum renormalized over the evaluated components (`null` if none);
* `lower_bound` — missing components treated as 0;
* `upper_bound` — missing components treated as 1;
* `coverage` — total weight of the evaluated components.

Each component also lists its contributors (which CVE, technique or indicator, from which finding)
and the references it excluded and why (e.g. "not enriched from NVD", "validation is candidate").

## Interpretation

The score is a transparent prioritization aid for ordering investigations. It is not a calibrated
probability that an attack occurred, and an indicator is never labelled malicious because it
appears in several places. Equal weights are a documented baseline; tuning them requires labelled
investigation data that this project does not yet have.

Every computation is stored in `risk_assessments` (history is kept) with its inputs.
