# Cyber Monkey — implementation status

The running record of what exists, what works, what is unavailable and what remains. Nothing
listed as pending has been implemented, and no evaluation result has been measured.

## Stage 1 — Assessment of the starting point (2026-10-12)

**Repository.** `C:\Dinesh\AI_Projects\Onkey` was empty; no Cyber Monkey source code was found on
the development machine (only document versions: IEEE paper drafts, the 56-page report, decks).

**Existing prototype (not available here).** The 3rd-review PPT shows a teammate's prototype
(Vite frontend on `localhost:5173`, a Penetration Testing workspace with assessments, in-scope
targets and Nmap scans, a backend on `127.0.0.1:8000`). The project owner chose to start fresh.

**Architecture decision.**

| Source | Stack described |
|---|---|
| IEEE paper / project report | React, Node.js/Express, MongoDB, Ollama, JWT |
| 3rd-review PPT | React (+ Flutter apps), microservices, "PostgreSQL / MongoDB", Redis, Elasticsearch, Docker/Kubernetes, LLM/RAG |
| **This implementation** | **React + Vite + TypeScript + Tailwind; FastAPI + Pydantic; PostgreSQL + SQLAlchemy + Alembic; JWT + RBAC; Gemini/Ollama behind a provider interface; Docker Compose** |

Express/MongoDB are not mixed in. The provider interface keeps the paper's Ollama design available.
Flutter, Redis, Elasticsearch and Kubernetes are out of scope.

**Development machine.** Python 3.11–3.13, Node 24, uv, git. No Docker, PostgreSQL or security tool
binaries. PostgreSQL for development and tests runs through `pgserver` (real PostgreSQL 16). No
network scanning was performed from this machine.

## Stage progress

| Stage | Scope | Status |
|---|---|---|
| 1 | Repository and document assessment | Done |
| 2 | Foundation: FastAPI, PostgreSQL + migrations, auth, RBAC, audit logging, navigation | Done |
| 3 | Dashboard, investigations, evidence, tool registry and run engine, AI orchestrator and assistant | Done |
| 4 | First end-to-end workflow | Done — evidence upload → tool run → normalized findings → correlation → risk → report, verified in the browser against the live server |
| 5 | Normalization, IOC correlation, CVE enrichment (NVD), ATT&CK mapping, risk scoring | Done |
| 6 | Evidence-based reporting, review workflow, PDF export | Done |
| 7 | Remaining workspaces | Partial — see below |
| 8 | Tests, Docker, documentation, evaluation kit, demo seed | Done (Docker files written but not executed: Docker is not installed on the development machine) |

## Implemented features

* **Authentication**: Argon2id, password policy, JWT with revocation and per-user token versioning,
  lockout, login rate limiting, HttpOnly SameSite=Strict cookie with anti-CSRF header.
* **Authorization**: workspace (`view/operate/execute`) and platform permission codes, 7 default
  roles, custom roles, direct grants, ownership/membership checks, segregation of duties for report
  approval, audited denials.
* **Investigations**: references (`INV-YYYY-NNNN`), members (viewer/contributor), authorized-scope
  register with authorization references and expiry, notes, combined timeline, close/reopen.
* **Evidence**: streamed upload with per-kind limits, MD5/SHA-1/SHA-256, content sniffing per kind,
  content-addressed read-only storage, derived tool output, custody history, integrity
  verification, download (never for malware samples).
* **Tool registry and run engine**: strict argument schemas, permission and scope checks (at
  request, approval and execution), approval gating, deadlines, honest `unavailable` status,
  raw output preserved as evidence, background execution, recovery after restart, notifications.
* **Tools**: `*_findings_import` for all six workspaces (documented `cybermonkey-findings/v1`
  format), `forensics_evidence_profile`, `malware_file_profile`.
* **Threat Intelligence Engine**: IOC normalization (IPv4/IPv6/domain/URL/email/hashes, internal
  flagging), cross-workspace and visibility-respecting cross-investigation correlation, CVE
  enrichment from NVD (verified live: CVE-2021-41773 → CVSS 9.8), ATT&CK catalogue (built-in subset
  or full STIX via `scripts/fetch_attack.py`), reference validation workflow.
* **Risk scoring**: Eq. (2) with explicit missing components, bounds, coverage, contributors and
  exclusions; history retained.
* **Reports**: structured content from the database, LLM or template narrative, citation checking,
  limitations, analyst notes, draft → review → approve/changes workflow, versions, PDF export with
  DRAFT watermark.
* **AI Orchestrator**: rule-based or LLM routing, multi-step plans, per-step permission checks,
  approval stop and automatic continuation, evidence-based explanations with citation checks,
  capabilities listing, conversation history, rate limiting.
* **UI**: dashboard, AI assistant, six workspace pages, investigations (10 tabs), threat
  intelligence, reports, audit logs, settings (profile, users, roles & permission matrix,
  integrations), notifications, error boundary, responsive layout.
* **Demo data**: `python -m app.cli seed-demo --owner <email>` builds a labelled demo investigation
  from bundled samples (documentation address ranges, example domains).

## Unavailable / not implemented

* **Live security-tool adapters** (network scanning, packet-capture analysis, IDS engines, sandbox
  submission, OSINT lookups, SIEM connectors, disk/memory-image parsers) are not implemented.
  Results from those tools, run by the team in an authorized lab, enter the platform through the
  structured findings import. The integration status page lists only implemented integrations.
* **LLM**: no provider is configured on the development machine (`AI_PROVIDER=none`); routing and
  prose use the deterministic, labelled fallback. Gemini and Ollama paths are covered by tests with
  fake providers only.
* **Docker Compose** has not been executed (no Docker on the development machine).
* SHAP/LIME are not used: there is no predictive model whose predictions they could explain.

## Tests

* Backend: 75 tests (pytest) against real PostgreSQL — auth, lockout, revocation, CSRF, RBAC and
  administration, ownership isolation, scope logic, evidence storage and type rules, tool
  permissions/scope/schema enforcement, findings import, triage, IOC normalization, correlation,
  risk arithmetic and missing data, NVD parsing, dashboard visibility, reports and citation checks,
  review workflow, PDF export, orchestrator routing/approval/continuation/LLM-proposal validation,
  demo seed.
* Frontend: 7 tests (vitest) — API client, error formatting, badges, permission-aware navigation.
* Manual browser verification of every page against the live development server.

## Evaluation

Kit in `docs/EVALUATION.md` and `docs/evaluation/`. All results are **pending**.

## Remaining work

1. Implement live adapters for the team's lab tools, one at a time, each with scope checks,
   confirmation and tests (or keep using the import format).
2. Configure Gemini or Ollama and record the model with every evaluation run.
3. Run `docker compose up --build` on a machine with Docker and fix anything it reveals.
4. Collect an independent routing request set and run the evaluation protocol.
5. Production hardening: shared rate-limit store and job queue for multiple instances, MFA/SSO,
   HTTPS termination and `COOKIE_SECURE=true`.
