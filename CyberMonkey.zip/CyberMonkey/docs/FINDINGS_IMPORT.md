# Integrations

## Structured findings import (`cybermonkey-findings/v1`)

Results produced by your own, authorized tooling (lab scanners, IDS, sandboxes, forensic suites,
SIEM queries, OSINT collection) are brought into Cyber Monkey as JSON in this format. Each
workspace has an import tool that accepts one evidence kind:

| Workspace | Tool | Evidence kind to upload |
|---|---|---|
| SOC Monitoring | `soc_findings_import` | `log` |
| Penetration Testing | `pentest_findings_import` | `scan_report` |
| OSINT Investigation | `osint_findings_import` | `osint_record` |
| Malware Analysis | `malware_findings_import` | `sandbox_report` |
| Digital Forensics | `forensics_findings_import` | `forensic_report` |
| Network Monitoring | `network_findings_import` | `ids_alerts` |

```json
{
  "format": "cybermonkey-findings/v1",
  "source_tool": "name and version of the tool that produced the results",
  "generated_at": "2026-10-01T10:00:00Z",
  "findings": [
    {
      "id": "stable id from the source tool (optional, used for de-duplication)",
      "type": "vulnerability | open_service | alert | artifact | ...",
      "title": "Short title",
      "description": "What the tool observed",
      "severity": "info | low | medium | high | critical",
      "confidence": "low | medium | high",
      "asset": "host:port/proto, file path, account, ...",
      "observed_at": "2026-10-01T09:58:12Z",
      "indicators": [{"type": "ipv4|ipv6|domain|url|email|md5|sha1|sha256", "value": "...", "context": "..."}],
      "cve": ["CVE-2021-41773"],
      "attack": ["T1190"],
      "remediation": ["Guidance text"],
      "details": {"any": "tool-specific structured data"}
    }
  ]
}
```

Processing rules:

* Entries that fail validation are skipped and listed in the run summary (`rejected_entries`).
* Invalid indicators, malformed CVE IDs and ATT&CK IDs not in the catalogue are dropped and counted
  (`dropped_values`); nothing is guessed or invented.
* Each finding keeps `origin = import`, `details.reported_by` (the source tool) and an evidence
  reference `findings[N]` pointing at its entry in the uploaded file.
* CVE/ATT&CK references named in the file are marked `supported` with the basis
  "Named by <source_tool> in the imported report"; analysts can confirm or reject them.
* Re-importing the same observations is idempotent (fingerprint de-duplication).

Example files: `backend/app/data/demo/*.json` (demonstration data).

## Evidence profile tools

* `forensics_evidence_profile` — any evidence kind: re-hashes the stored file, compares with the
  registered SHA-256 (a mismatch produces a high-severity integrity finding), records size,
  detected type, byte entropy and MD5/SHA-1/SHA-256 as indicators.
* `malware_file_profile` — malware samples only: the same static profile. Samples are never
  executed and cannot be downloaded through the web application.

## NVD (CVE enrichment)

`POST /api/v1/threat-intelligence/enrich-cves` (or the assistant's "enrich" step) fetches CVE
details from the NVD CVE API 2.0 in the background: description, CVSS base score/severity/vector
(v4.0 → v3.1 → v3.0 → v2 preference) and references. Without `NVD_API_KEY` the public limit allows
about one request every six seconds. Lookups are disabled when `OUTBOUND_NETWORK_ENABLED=false`.

## MITRE ATT&CK

A built-in subset of commonly referenced Enterprise techniques ships with the backend. Download the
full Enterprise STIX bundle with:

```bash
python scripts/fetch_attack.py
```

Restart the backend afterwards; the full catalogue then takes precedence.

## Not implemented

Live adapters for external security tools are not part of this implementation. The integration
status page lists only what is implemented.
