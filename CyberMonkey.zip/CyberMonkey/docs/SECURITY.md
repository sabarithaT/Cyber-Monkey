# Security model

## Authentication

* Argon2id password hashing (argon2-cffi defaults), automatic rehash on login when parameters change.
* Password policy: ≥ 12 characters and three of lowercase/uppercase/digit/symbol.
* JWT access tokens (HS256, `JWT_SECRET` required in production) with `jti`, issuer and expiry;
  logout revokes the token; a per-user `token_version` invalidates all sessions on password change,
  role change, permission change or deactivation.
* Generic failure message for unknown accounts, bad passwords and locked accounts; constant-time
  dummy hash for unknown accounts; lockout after `LOGIN_MAX_FAILURES` failures; per-IP and
  per-email rate limits.
* The browser receives an HttpOnly, `SameSite=Strict` cookie scoped to `/api`. Cookie-authenticated
  state-changing requests must carry `X-CM-Client: web` (CSRF defence; CORS allows only configured
  origins). API clients can use `Authorization: Bearer`.

## Authorization

* Every endpoint checks permission codes on the server; the UI hiding an item is never the control.
* Investigation data requires ownership, membership or `investigations:manage_all`; inaccessible
  investigations are reported as not found.
* Report approval requires `reports:review` and, by default, a different person from the generator.
* Authorization denials are audit-logged in an independent transaction.

## Tool execution

* Only registered tools can run; arguments are validated against strict schemas (unknown fields rejected).
* Scope validation: evidence must belong to the investigation and be of an accepted kind. Each
  investigation also keeps an authorized-scope register (IP, CIDR capped at /16, hostname, with the
  authorization reference and expiry) and a target-coverage check for tools that act on network
  targets; no such tool ships in this version. Scope is re-validated at approval and at execution time.
* Tools flagged as consequential wait in `pending_approval` until a person confirms; decisions are audited.
* Each run has a time limit; outcomes are recorded, including `unavailable` when an integration is
  not configured (nothing is simulated).

## Evidence handling

* Uploads are streamed with per-kind size limits, hashed (MD5/SHA-1/SHA-256), content-sniffed and
  rejected when the content does not match the declared kind.
* Stored under content-addressed names, outside the web root, marked read-only. Filenames are
  sanitized for display only.
* Original evidence is never modified; tool output is stored as separate derived evidence.
* Custody events record registration, metadata views, analysis, downloads and integrity checks.
* Malware samples are never executed and cannot be downloaded through the web application.

## Untrusted content and the LLM

* Uploaded files, tool output and LLM responses are treated as untrusted data.
* The router sees tool schemas and evidence metadata only; file contents are never sent to it.
* Prompts mark data sections and instruct the model to ignore instructions inside them; regardless
  of the model's output, permissions, schema and scope checks run in code.
* Generated prose is checked for citations of finding IDs that do not exist.

## Secrets and logging

* Secrets come only from environment variables (`SecretStr`), never from the database or the UI.
* Audit details are recursively redacted for keys containing password, token, secret, api_key,
  authorization, cookie or credential.
* Outbound HTTP goes through an allowlisted HTTPS client with timeouts and a response-size cap;
  `OUTBOUND_NETWORK_ENABLED=false` makes the backend fully offline.

## HTTP hardening

`X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy: no-referrer`,
`Cache-Control: no-store` on API responses, a restrictive CSP on API and UI, CORS limited to
configured origins.

## Known limitations

* Rate limiting and the run queue are in-process (single backend instance).
* No multi-factor authentication or SSO.
* The platform cannot verify that an engagement is legally authorized; it records who asserted the
  authorization and requires confirmation before consequential actions.
