# API

Interactive documentation (OpenAPI/Swagger) is served by the backend at `/api/docs`, ReDoc at
`/api/redoc` and the schema at `/api/openapi.json`. All endpoints are under `/api/v1`.

**Conventions**

* Errors: `{"error": {"code": "...", "message": "...", "details": ...}}` (e.g. `not_authenticated`,
  `permission_denied`, `not_found`, `validation_failed`, `out_of_scope`, `conflict`, `rate_limited`).
* Lists: `{"items": [...], "total": n, "page": p, "page_size": s}` with `?page=&page_size=` (≤ 100).
* Authentication: `Authorization: Bearer <token>` or the session cookie plus `X-CM-Client: web`.

| Area | Endpoints |
|---|---|
| Auth | `POST /auth/login`, `POST /auth/logout`, `GET /auth/me`, `POST /auth/change-password` |
| Users & roles | `GET/POST /users`, `GET/PATCH /users/{id}`, `PUT /users/{id}/roles`, `PUT /users/{id}/permissions`, `POST /users/{id}/reset-password`, `GET /permissions`, `GET/POST /roles`, `PATCH/DELETE /roles/{id}` |
| Dashboard | `GET /dashboard/summary` |
| Investigations | `GET/POST /investigations`, `GET/PATCH /investigations/{id}`, `POST/DELETE /investigations/{id}/members[/{user}]`, `POST/DELETE /investigations/{id}/scope[/{target}]`, `GET/POST /investigations/{id}/notes`, `GET /investigations/{id}/timeline` |
| Evidence | `POST/GET /investigations/{id}/evidence`, `GET /evidence/{id}`, `POST /evidence/{id}/verify`, `GET /evidence/{id}/download` |
| Tools & runs | `GET /tools`, `POST /tool-runs` (alias `POST /scans`), `GET /tool-runs`, `GET /tool-runs/{id}` (alias `GET /scans/{id}`), `POST /tool-runs/{id}/approve`, `POST /tool-runs/{id}/reject` |
| Findings | `GET /findings`, `GET/PATCH /findings/{id}`, `PATCH /findings/{id}/references/{ref}` |
| Threat intelligence | `GET /threat-intelligence/iocs`, `GET /threat-intelligence/iocs/{id}`, `GET /threat-intelligence/correlations`, `GET /threat-intelligence/references`, `GET /threat-intelligence/attack/techniques`, `POST /threat-intelligence/enrich-cves`, `POST/GET /threat-intelligence/risk/{investigation}` |
| Reports | `POST/GET /reports`, `GET/PATCH /reports/{id}`, `POST /reports/{id}/regenerate`, `POST /reports/{id}/submit`, `POST /reports/{id}/approve`, `POST /reports/{id}/request-changes`, `GET /reports/{id}/pdf` |
| AI assistant | `GET /assistant/status`, `POST /assistant/chat`, `GET /assistant/conversations`, `GET/DELETE /assistant/conversations/{id}` |
| Audit & system | `GET /audit-logs`, `GET /notifications`, `GET/PATCH /integrations[/{key}]`, `GET /health` |

## Example: request a tool run

```bash
curl -s -X POST http://localhost:8000/api/v1/tool-runs \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"investigation_id": "<uuid>", "tool": "forensics_evidence_profile", "arguments": {"evidence_id": "<uuid>"}}'
```

The response is the run record (`status` is `queued`, `pending_approval` or `unavailable`); poll
`GET /tool-runs/{id}` until it is `succeeded`, `failed`, `timed_out` or `rejected`.

## Example: assistant request

```bash
curl -s -X POST http://localhost:8000/api/v1/assistant/chat \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"message": "Summarize the most critical findings and generate a report", "investigation_id": "<uuid>"}'
```

`assistant_message.orchestration` contains the intent (workspace, task, router), the plan with each
step's permissions, approval requirement, status, run ID and result, the explanation with its
citation check, evidence references, notices and errors.
