# AI providers

The orchestrator and report generator call a provider-independent interface
(`app/ai/provider.py`: `generate_text`, `generate_json`). Select a provider with `AI_PROVIDER`.

| `AI_PROVIDER` | Behaviour |
|---|---|
| `none` (default) | Deterministic keyword routing; template-based explanations and report prose, labelled as such |
| `gemini` | Google Gemini REST API. Requires `GEMINI_API_KEY`; optional `GEMINI_MODEL` (default `gemini-2.5-flash`) |
| `ollama` | Local Ollama server at `OLLAMA_BASE_URL` with `OLLAMA_MODEL`. Prompts stay on your infrastructure |

## Gemini

```env
AI_PROVIDER=gemini
GEMINI_API_KEY=<your key>
GEMINI_MODEL=gemini-2.5-flash
```

Requests are sent with the key in the `x-goog-api-key` header. Structured outputs use Gemini's JSON
response schema. Note that prompts (request text, finding titles and descriptions) leave your
environment when Gemini is used.

## Ollama (matches the IEEE paper's local-LLM design)

```bash
ollama pull llama3.1:8b
```

```env
AI_PROVIDER=ollama
OLLAMA_BASE_URL=http://localhost:11434        # http://host.docker.internal:11434 from docker compose
OLLAMA_MODEL=llama3.1:8b
```

Structured outputs use Ollama's `format` JSON schema. Record the exact model tag and quantization
with every evaluation run.

## What the model can and cannot do

* It **proposes** a plan (actions, registered tools, arguments). Code validates every step:
  permissions, argument schema, investigation scope and approval rules.
* It never executes commands, SQL or network requests, never creates findings, and never sees
  evidence file contents (routing receives evidence metadata only).
* Explanations and report prose must cite finding IDs; citations are checked and problems are shown.
* If the provider fails, the system falls back to deterministic behaviour and says so.

LangChain and CrewAI are not used: a single validated tool-calling loop over a fixed registry did
not need an agent framework, and fewer moving parts keep the security checks auditable.
