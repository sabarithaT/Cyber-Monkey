# Cyber Monkey

**A role-based, AI-orchestrated platform for unified cybersecurity operations** (final-year
project, SNS College of Engineering). One web application brings six security workspaces
under one role-aware interface, backed by a shared Threat Intelligence Engine, an evidence-based
AI Report Generator and an AI Orchestrator that turns natural-language requests into validated,
permission-checked plans.

> Use Cyber Monkey only with data and systems you are authorized to handle. Consequential actions
> always require explicit confirmation, and every security-relevant action is audit-logged.

## What works today

| Area | Status |
|---|---|
| Authentication (Argon2id, JWT, revocation, lockout, HttpOnly cookie + CSRF header) | Implemented, tested |
| Role-based access control (permission codes, 7 default roles, custom roles, direct grants, ownership checks) | Implemented, tested |
| Investigations (members, authorized scope, notes, timeline) | Implemented, tested |
| Evidence storage (hashing, type validation, read-only originals, custody trail, integrity verification) | Implemented, tested |
| Tool registry and run engine (strict argument schemas, scope checks, approval gating, timeouts, raw-output preservation) | Implemented, tested |
| Tools: structured findings import (all six workspaces), evidence integrity profile (forensics), static file profile (malware) | Implemented, tested |
| Threat Intelligence Engine (IOC normalization, cross-workspace/investigation correlation, CVE enrichment from NVD, ATT&CK mapping) | Implemented, tested |
| Risk scoring `S = w_c·C(F) + w_m·M(F) + w_i·I(F)` with explicit handling of missing components | Implemented, tested |
| Reports (structured content, LLM or template narrative with citation checking, review workflow, PDF export) | Implemented, tested |
| AI Orchestrator and assistant (rule-based routing; Gemini/Ollama when configured; approval and continuation) | Implemented, tested |
| Dashboard, audit log viewer, notifications, settings, integrations status | Implemented |
| Docker Compose deployment | Written; not executed on the development machine (no Docker there) |

Not implemented: live connectors to external security tools (scanners, packet analyzers, IDS
engines, sandboxes, OSINT services, SIEMs). Results from such tools, run by your team in an
authorized environment, are brought in through the documented
[structured findings import](docs/FINDINGS_IMPORT.md). See [docs/STATUS.md](docs/STATUS.md) for the
full list of what is implemented, unavailable and remaining.

## Architecture in one picture

```
React + Vite + TS + Tailwind  ──/api──►  FastAPI (Pydantic, JWT, RBAC, audit)
                                          ├─ AI Orchestrator ── LLM provider (Gemini | Ollama | none)
                                          ├─ Tool registry ──► run engine (approval, scope, timeout)
                                          ├─ Threat Intelligence Engine (IOCs, correlation, NVD, ATT&CK, risk)
                                          ├─ Report generator (structured → narrative → PDF)
                                          └─ PostgreSQL (SQLAlchemy + Alembic) + controlled file storage
```

Details: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Quick start (one command, no Docker)

Requirements: **Python 3.12** and **Node.js 20+**. From the repository root:

```bash
python cybermonkey.py setup
```

This creates `backend/.venv`, installs the backend and frontend packages, starts an embedded
PostgreSQL 16 (no installer needed), writes `backend/.env` with a freshly generated secret, runs the
migrations and asks you for the administrator's email, name and password. Then:

```bash
python cybermonkey.py start
```

Open http://localhost:5173 and sign in with the administrator you just created. Press Ctrl+C to
stop. Run `python cybermonkey.py admin` to add another administrator, or add
`--demo-owner you@example.org` to `setup` for a labelled demo investigation. To use an existing
PostgreSQL server instead of the embedded one, pass
`--database-url postgresql+psycopg://user:password@host:5432/cybermonkey` to `setup`.

`backend/.env` holds your secrets and machine-specific settings: never share or commit it. When
sharing the project, share the repository without `backend/.env`, `backend/.venv`,
`frontend/node_modules`, `.devdb` and `storage` (all excluded by `.gitignore`).

## Quick start with Docker Compose

```bash
cp .env.example .env
```

Edit `.env`: set `POSTGRES_PASSWORD` and `JWT_SECRET` (generate one with
`python -c "import secrets; print(secrets.token_urlsafe(48))"`). Then:

```bash
docker compose up --build
```

```bash
docker compose exec backend python -m app.cli create-admin --email you@example.org --name "Your Name"
```

Open http://localhost:8080 and sign in. API documentation: http://localhost:8000/api/docs.

Optional demo data (clearly labelled, built from bundled sample files that use documentation
address ranges):

```bash
docker compose exec backend python -m app.cli seed-demo --owner you@example.org
```

## Local development (no Docker)

Requirements: Python 3.12, Node 20+ (tested with Node 24).

```bash
cd backend
python -m venv .venv
.venv/Scripts/python -m pip install -r requirements-dev.txt   # Windows; use .venv/bin/python on Linux/macOS
```

If you have no PostgreSQL server, start an embedded one (real PostgreSQL 16 via `pgserver`) and
copy the printed `DATABASE_URL` into `backend/.env`:

```bash
python scripts/dev_postgres.py --print
```

Create `backend/.env` from `.env.example` (set `ENVIRONMENT=development`, `DATABASE_URL`,
`JWT_SECRET`), then:

```bash
python -m app.cli init
python -m app.cli create-admin --email you@example.org --name "Your Name"
python -m uvicorn app.main:app --reload --port 8000
```

In another terminal:

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173 (the Vite dev server proxies `/api` to port 8000).

## Tests

```bash
cd backend
python -m pytest
```

Runs 75 tests against a real PostgreSQL (`TEST_DATABASE_URL` if set, otherwise an embedded
server is started automatically).

```bash
cd frontend
npm test
npm run typecheck
npm run build
```

## Configuration

All settings are environment variables; see [.env.example](.env.example). Secrets are read only
from the environment, never stored in the database or shown in the UI.

* AI providers: [docs/AI_PROVIDERS.md](docs/AI_PROVIDERS.md)
* Integrations (findings import, NVD, ATT&CK): [docs/FINDINGS_IMPORT.md](docs/FINDINGS_IMPORT.md)
* Risk scoring: [docs/RISK_SCORING.md](docs/RISK_SCORING.md)
* Security model: [docs/SECURITY.md](docs/SECURITY.md)
* API: [docs/API.md](docs/API.md) and the live OpenAPI docs at `/api/docs`
* Evaluation plan and kit: [docs/EVALUATION.md](docs/EVALUATION.md)

## Repository layout

```
backend/   FastAPI application (app/), Alembic migrations, tests, scripts
frontend/  React application (src/), nginx config for the container
docs/      Architecture, security, scoring, evaluation and status documentation
docker-compose.yml, .env.example
```
